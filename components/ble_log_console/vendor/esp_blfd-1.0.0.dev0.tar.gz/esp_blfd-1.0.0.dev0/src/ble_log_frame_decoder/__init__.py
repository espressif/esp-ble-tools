from typing import TYPE_CHECKING

from .core import (
    BleLogFrame,
    DecodeStats,
    Frame,
    FrameDecodeError,
    FrameDecoder,
    FrameFormat,
    FrameSink,
    FrameView,
    IncompleteFrameError,
)
from .internal import (
    BUFFER_UTIL_POOL_NAMES,
    FINAL_STAT,
    FLUSH,
    FRAME_CANDIDATE_POLICIES,
    INIT,
    INTERNAL_PAYLOAD_LENGTHS,
    INTERNAL_SOURCE_NAMES,
    PERIODIC,
    SNAPSHOT,
    SNAPSHOT_PAYLOAD_SIZE,
    SOURCE_CODE_STR_MAP,
    TASK_BINDING,
    TS_VALID,
    VERSION_INFO_PAYLOAD_LEN,
    BleLogSource,
    BleLogVersionInfo,
    CandidateValidator,
    EnhancedStat,
    FinalStat,
    FinalStatEntry,
    InternalLogBufferUtil,
    InternalLogEnhancedStat,
    InternalLogFinalStat,
    InternalLogInfo,
    InternalLogTimestamp,
    InternalSource,
    Snapshot,
    SourceStat,
    get_internal_source_type,
    get_source_name,
    is_snapshot,
    is_task_binding,
    is_valid_frame_candidate,
    is_valid_internal_candidate,
    parse_final_stat,
    parse_snapshot,
    parse_snapshot_version_info,
    parse_version_info_payload,
    task_names_from_binding,
)

if TYPE_CHECKING:
    from .analysis import (
        FirmwareCounters,
        FirmwareSnapshot,
        FirmwareSourceStats,
        ParseBatch,
        ParserSession,
        Record,
        SessionResult,
        SessionSnapshot,
    )


__all__ = [
    "FirmwareCounters",
    "FirmwareSnapshot",
    "FirmwareSourceStats",
    "ParseBatch",
    "ParserSession",
    "Record",
    "SessionResult",
    "SessionSnapshot",
    "BUFFER_UTIL_POOL_NAMES",
    "FINAL_STAT",
    "FLUSH",
    "FRAME_CANDIDATE_POLICIES",
    "INIT",
    "INTERNAL_PAYLOAD_LENGTHS",
    "INTERNAL_SOURCE_NAMES",
    "PERIODIC",
    "SNAPSHOT",
    "SNAPSHOT_PAYLOAD_SIZE",
    "SOURCE_CODE_STR_MAP",
    "TASK_BINDING",
    "TS_VALID",
    "VERSION_INFO_PAYLOAD_LEN",
    "BleLogFrame",
    "BleLogSource",
    "BleLogVersionInfo",
    "CandidateValidator",
    "DecodeStats",
    "EnhancedStat",
    "FinalStat",
    "FinalStatEntry",
    "Frame",
    "FrameDecodeError",
    "FrameDecoder",
    "FrameFormat",
    "FrameSink",
    "FrameView",
    "IncompleteFrameError",
    "InternalLogBufferUtil",
    "InternalLogEnhancedStat",
    "InternalLogFinalStat",
    "InternalLogInfo",
    "InternalLogTimestamp",
    "InternalSource",
    "Snapshot",
    "SourceStat",
    "get_internal_source_type",
    "get_source_name",
    "is_snapshot",
    "is_task_binding",
    "is_valid_frame_candidate",
    "is_valid_internal_candidate",
    "parse_final_stat",
    "parse_snapshot",
    "parse_snapshot_version_info",
    "parse_version_info_payload",
    "task_names_from_binding",
]

from .core import _release_extension

if _release_extension is not None:
    _release_extension.extend_namespace(globals())


_ANALYSIS_EXPORTS = (
    "FirmwareCounters",
    "FirmwareSnapshot",
    "FirmwareSourceStats",
    "ParseBatch",
    "ParserSession",
    "Record",
    "SessionResult",
    "SessionSnapshot",
)


def __getattr__(name):
    if name in _ANALYSIS_EXPORTS:
        from . import analysis

        value = getattr(analysis, name)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
