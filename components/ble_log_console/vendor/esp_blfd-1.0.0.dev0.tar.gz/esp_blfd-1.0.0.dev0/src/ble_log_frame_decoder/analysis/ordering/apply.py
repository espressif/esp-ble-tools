"""Compact report models for disk-backed frame ordering."""

from dataclasses import dataclass, field
from typing import Any

from ble_log_frame_decoder.analysis.core.source_codes import BleLogSource
from ble_log_frame_decoder.analysis.ordering.diagnostics import BoundaryObservation
from ble_log_frame_decoder.analysis.ordering.frame_model import LcTimerUnit
from ble_log_frame_decoder.analysis.ordering.metadata_ordering import (
    MetadataOrderingResult,
)


@dataclass
class InstanceOrderStats:
    """Per-instance summary for the instances report (ticket 08)."""

    index: int
    frames: int
    sources: list[str]
    transport_start: int
    transport_end: int
    sn: dict[str, Any]
    clock: dict[str, Any]
    clock_inferred_from_sn: list[str]
    transport_inverted_hard_edges: int
    tie_decisions: dict[str, Any]
    choice_distribution: dict[str, Any]
    ts_sync_anchors: int = 0
    ts_sync_rejected: int = 0


@dataclass
class OrderStats:
    """Compact post-ordering statistics for the report layer."""

    deduplicated_frames: int = 0
    frames: int = 0
    instance_count: int = 0
    boundaries: int = 0
    source_local_reassigned: int = 0
    warnings: list[str] = field(default_factory=list)
    elapsed_s: float = 0.0
    low_confidence_frames: int = 0
    aligned_confidence_frames: int = 0
    per_instance: list[InstanceOrderStats] = field(default_factory=list)
    boundary_events: list[BoundaryObservation] = field(default_factory=list)


def metadata_order_stats(
    result: MetadataOrderingResult,
    *,
    elapsed_s: float,
) -> OrderStats:
    """Build the existing compact report model from a disk-backed result."""
    source_sn = result.store.mmap_column("source_sn")
    source_sets = [set() for _ in result.instances]
    frames = 0
    low_confidence_frames = 0
    aligned_confidence_frames = 0
    for row_value in result.ordered_rows:
        row = int(row_value)
        source = BleLogSource(int(source_sn[row]) & 0xFF)
        frames += 1
        confidence = int(result.confidence_by_row[row])
        low_confidence_frames += confidence == 3
        aligned_confidence_frames += confidence == 2
        instance = int(result.instance_by_row[row])
        if 0 <= instance < len(source_sets):
            source_sets[instance].add(source.name)

    per_instance = []
    for segment, instance, sources in zip(
        result.detection.instances,
        result.instances,
        source_sets,
    ):
        diagnostics = instance.diagnostics
        per_instance.append(
            InstanceOrderStats(
                index=segment.index,
                frames=segment.frame_count,
                sources=sorted(sources),
                transport_start=segment.start_transport,
                transport_end=segment.end_transport,
                sn=diagnostics["sn"],
                clock=diagnostics["clock"],
                clock_inferred_from_sn=diagnostics["clock_inferred_from_sn"],
                transport_inverted_hard_edges=diagnostics[
                    "transport_inverted_hard_edges"
                ],
                tie_decisions=diagnostics["tie_decisions"],
                choice_distribution=diagnostics["choice_distribution"],
                ts_sync_anchors=diagnostics["ts_sync_anchors"],
                ts_sync_rejected=diagnostics["ts_sync_rejected"],
            )
        )
    return OrderStats(
        deduplicated_frames=result.deduplicated_rows,
        frames=frames,
        instance_count=len(result.instances),
        boundaries=len(result.detection.boundaries),
        source_local_reassigned=result.detection.source_local_reassigned,
        warnings=list(result.detection.warnings),
        elapsed_s=elapsed_s,
        low_confidence_frames=low_confidence_frames,
        aligned_confidence_frames=aligned_confidence_frames,
        per_instance=per_instance,
        boundary_events=list(result.detection.boundary_observations),
    )


def lc_timer_unit_for_chip(chip: str) -> LcTimerUnit:
    return LcTimerUnit.RTC_TICK if chip.upper() == "ESP32C2" else LcTimerUnit.US
