"""Owned records; no borrowed decoder views escape a feed call."""

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Record:
    kind: str
    source: int
    sn: int
    timestamp_us: int | None = None
    value: int | None = None
    text: str = ""
    raw: bytes = b""
    record_id: int = 0
    incomplete: bool = False
    reason: str = ""
