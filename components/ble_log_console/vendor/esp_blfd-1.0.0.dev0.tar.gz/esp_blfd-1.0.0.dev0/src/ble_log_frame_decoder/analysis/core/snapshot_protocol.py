"""Decode task binding names for parser output.

Moved to ``ble_log_frame_decoder.internal``; this module remains as the
import path used by the v2 parser.
"""

from ble_log_frame_decoder import task_names_from_binding

__all__ = ["task_names_from_binding"]
