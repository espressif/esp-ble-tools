"""Shared decoded BLE Log build, library, and chip version information.

Moved to ``ble_log_frame_decoder.internal``; this module remains as the
import path used by the v2 parser.
"""

from ble_log_frame_decoder import BleLogVersionInfo

__all__ = ["BleLogVersionInfo"]
