"""Bounded best-effort Host/HCI ordering; integrity always runs upstream."""

from dataclasses import dataclass

from ble_log_frame_decoder import FrameView


def unfold(raw, reference, bits):
    if reference is None:
        return raw
    period = 1 << bits
    return reference + (raw - reference + period // 2) % period - period // 2


@dataclass(slots=True)
class PendingFrame:
    source_code: int
    raw_sn: int
    payload: bytes
    received_at: float
    timestamp: int
    sequence: int
    index: int
    offset: int

    def view(self):
        return FrameView(
            self.source_code,
            self.raw_sn,
            self.offset,
            len(self.payload),
            memoryview(self.payload),
        )


class LiveOrdering:
    def __init__(
        self, *, max_wait=3.0, max_bytes=64 * 1024 * 1024, max_records=250_000
    ):
        if not 0 < max_wait <= 3 or max_bytes <= 0 or max_records <= 0:
            raise ValueError("live limits must be positive and max_wait <= 3 seconds")
        self.max_wait, self.max_bytes, self.max_records = (
            max_wait,
            max_bytes,
            max_records,
        )
        self.frames = []
        self.bytes = 0
        self._clock = None
        self._sn = {}
        self._index = 0
        self._identities = set()

    def observe_anchor(self, sn, timestamp, global_sn):
        clock = unfold(timestamp, self._clock, 32)
        self._clock = clock if self._clock is None else max(self._clock, clock)
        if global_sn:
            sequence = unfold(sn, self._sn.get(-1), 24)
            self._sn[-1] = max(sequence, self._sn.get(-1, sequence))

    def push(self, frame, now, global_sn):
        out = []
        if self.frames and (
            self.bytes + frame.payload_size > self.max_bytes
            or len(self.frames) >= self.max_records
        ):
            out = self.drain(global_sn)
        data = bytes(frame.payload_view)
        identity = (frame.source_code, frame.raw_sn, data)
        if identity in self._identities:
            return out
        timestamp = int.from_bytes(data[:4], "little")
        timestamp = unfold(timestamp, self._clock, 32)
        self._clock = timestamp if self._clock is None else max(self._clock, timestamp)
        source = -1 if global_sn else frame.source_code
        sequence = unfold(frame.raw_sn, self._sn.get(source), 24)
        self._sn[source] = max(sequence, self._sn.get(source, sequence))
        item = PendingFrame(
            frame.source_code,
            frame.raw_sn,
            data,
            now,
            timestamp,
            sequence,
            self._index,
            frame.payload_offset,
        )
        self._index += 1
        if len(data) > self.max_bytes:
            out.append(item)
            return out
        self.frames.append(item)
        self.bytes += len(data)
        self._identities.add(identity)
        return out

    def poll(self, now, global_sn):
        if self.frames and now - self.frames[0].received_at >= self.max_wait:
            return self.drain(global_sn)
        return []

    def drain(self, global_sn):
        # v8 shares SNs; older sources share system time but have independent SNs.
        key = (
            (lambda f: (f.sequence, f.index))
            if global_sn
            else (lambda f: (f.timestamp, f.source_code, f.sequence, f.index))
        )
        items = sorted(self.frames, key=key)
        self.frames = []
        self.bytes = 0
        self._identities.clear()
        return items

    def reset(self):
        self.frames.clear()
        self._identities.clear()
        self.bytes = 0
        self._clock = None
        self._sn.clear()
