from typing import Any

def linearize_instance(
    rows: Any,
    successor: Any,
    indegree: Any,
    priority_rows: Any,
    priority_position: Any,
    source_sn: Any,
    raw_clock: Any,
    flags: Any,
    domain_by_source: Any,
    lc_has_split: bool,
    lc_split_low: int,
    freertos_has_split: bool,
    freertos_split_low: int,
    anchor_lc: Any,
    anchor_os: Any,
    output_rows: Any,
    confidence: Any,
    time_scale: int = 1000,
) -> tuple[int, int, int, int, int]: ...
