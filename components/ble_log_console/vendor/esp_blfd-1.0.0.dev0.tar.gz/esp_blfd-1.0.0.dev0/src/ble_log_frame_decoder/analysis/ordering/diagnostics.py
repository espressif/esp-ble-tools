"""Public diagnostics for best-effort frame instance detection."""

import json
from array import array
from dataclasses import dataclass, field, fields, is_dataclass
from typing import Any

from ble_log_frame_decoder.analysis.ordering.frame_model import DetectorConfig


@dataclass(frozen=True)
class AnchorObservation:
    transport_index: int
    kind: str


@dataclass(frozen=True)
class BoundaryObservation:
    """One clustered reset observation, including deliberately suppressed ones."""

    start_transport: int
    end_transport: int
    reason: str
    boundary: int | None
    sources: list[str] = field(default_factory=list)
    clock_domains: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class SourceDiagnostic:
    instance: int
    source: str
    status: str
    duplicate_frames: int = 0
    large_gaps: int = 0


@dataclass
class InstanceSegment:
    """One logical instance; its frames need not be transport-contiguous."""

    index: int
    start_transport: int
    end_transport: int
    frame_count: int
    transport_indices: array = field(
        default_factory=lambda: array("I"), repr=False, metadata={"json": False}
    )


@dataclass
class InstanceDetectionResult:
    total_frames: int
    instances: list[InstanceSegment]
    boundaries: list[int]
    anchors: list[AnchorObservation] = field(default_factory=list)
    boundary_observations: list[BoundaryObservation] = field(default_factory=list)
    boundary_reason_counts: dict[str, int] = field(default_factory=dict)
    source_diagnostics: list[SourceDiagnostic] = field(default_factory=list)
    source_local_reassigned: int = 0
    unreliable_frames: int = 0
    warnings: list[str] = field(default_factory=list)
    parameters: DetectorConfig | dict[str, object] = field(default_factory=dict)


# Avoid dataclasses.asdict(): transport_indices may contain millions of entries and
# are an internal execution detail, not report data.
def _json_value(value: Any) -> Any:
    if is_dataclass(value) and not isinstance(value, type):
        return {
            item.name: _json_value(getattr(value, item.name))
            for item in fields(value)
            if item.metadata.get("json", True)
        }
    if isinstance(value, dict):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, array)):
        return [_json_value(item) for item in value]
    return value


def to_json(result: InstanceDetectionResult, indent: int = 2) -> str:
    """Serialize public diagnostics without internal frame-assignment arrays."""
    return json.dumps(_json_value(result), indent=indent, ensure_ascii=False)
