"""Parse context for collecting warnings and output file paths across decoders."""

from dataclasses import dataclass, field
from pathlib import Path

from ble_log_frame_decoder.analysis.core.version_info import BleLogVersionInfo
from ble_log_frame_decoder.checking import CheckResult


@dataclass
class DecoderWarning:
    """A single aggregated warning from a decoder."""

    source: str = ""
    """Log source name, e.g. 'LL_TASK', 'CUSTOM'."""

    category: str = ""
    """Warning category, e.g. 'short_payload', 'unknown_type', 'frame_loss'."""

    message: str = ""
    """Human-readable summary message."""

    count: int = 0
    """Number of occurrences of this warning."""


@dataclass
class ParseContext:
    """Mutable context passed through the parsing pipeline to collect results."""

    warnings: list[DecoderWarning] = field(default_factory=list)
    """Aggregated warnings from all decoders."""

    output_files: list[Path] = field(default_factory=list)
    """Paths of all output files that would be generated (dry-run mode).

    In dry-run mode, this collects paths without actual file creation.
    In normal mode, this tracks files that were actually written.
    """

    sync_report: list[str] = field(default_factory=list)
    """Lifecycle/interval synchronization section for the existing Markdown report."""

    dry_run: bool = False
    """If True, skip all file writes and only collect output paths."""

    ble_log_version: int | None = None
    """BLE Log v2 subversion parsed from internal records, if available."""

    protocol_summary: str | None = None
    """Selected layout and evidence for the disk report, separate from warnings."""

    encoded_buffer_has_length: bool | None = None
    """Explicit HEX_BUF layout override; None selects from protocol metadata."""

    version_info: BleLogVersionInfo | None = None
    """Latest build, library, and chip version record, if available."""

    task_names_by_instance: dict[int, dict[int, str]] = field(default_factory=dict)
    """v8 task names collected by INTERNAL before ENCODE decoding."""

    force_log_param: bool = False
    """If True, decode controller LL logs with legacy log_param_cfg.yml."""

    integrity: CheckResult | None = None
    """Owned raw-scan statistics; None for the delegated v1 path."""

    def add_warning(
        self, source: str, category: str, message: str, count: int = 1
    ) -> None:
        """Add an aggregated warning entry."""
        self.warnings.append(
            DecoderWarning(
                source=source, category=category, message=message, count=count
            )
        )

    def add_output_file(self, path: Path) -> None:
        """Register an output file path."""
        if path not in self.output_files:
            self.output_files.append(path)
