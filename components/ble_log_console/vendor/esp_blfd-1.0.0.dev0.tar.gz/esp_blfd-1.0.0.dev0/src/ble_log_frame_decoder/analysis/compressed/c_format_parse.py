import enum
import struct

TOTAL_REDUCE_NUM = 0


def parse_format_string(format_str):
    tokens = []
    i = 0
    n = len(format_str)

    while i < n:
        if format_str[i] == "%":
            start = i
            i += 1

            if i < n and format_str[i] == "%":
                tokens.append("%")
                i += 1
                continue

            flags = ""
            while i < n and format_str[i] in "-+ #0":
                flags += format_str[i]
                i += 1

            width = ""
            while i < n and format_str[i].isdigit():
                width += format_str[i]
                i += 1

            if i < n and format_str[i] == ".":
                i += 1
                while i < n and format_str[i].isdigit():
                    i += 1

            length = ""
            if i < n and format_str[i] in "zhl":
                length += format_str[i]
                i += 1
                if i < n and format_str[i] == "l" and length == "l":
                    length += "l"
                    i += 1

            if i < n and format_str[i] in "diuoxXfcsplL":
                conv_char = format_str[i]
                i += 1
                full_spec = format_str[start:i]
                tokens.append((start, i, full_spec, flags, width, length, conv_char))
            else:
                tokens.append(format_str[start:i])
        else:
            start = i
            while i < n and format_str[i] != "%":
                i += 1
            tokens.append(format_str[start:i])

    return tokens


def format_integer(num, conv_char, flags, width, length):
    base = 10
    uppercase = False
    prefix = ""

    if conv_char in "xX":
        base = 16
        uppercase = conv_char == "X"
    elif conv_char == "o":
        base = 8
    elif conv_char == "p":
        base = 16

    if base == 16:
        s = format(num, "X" if uppercase else "x")
    elif base == 8:
        s = format(num, "o")
    else:
        s = str(num)

    if "#" in flags and num != 0:
        if base == 16:
            prefix = "0X" if uppercase else "0x"
        elif base == 8:
            prefix = "0"

    if conv_char == "p":
        prefix = "0x"
        s = s.zfill(8)

    total_len = len(s) + len(prefix)
    if width:
        width_val = int(width)
        if width_val > total_len:
            pad_count = width_val - total_len
            if "0" in flags and "-" not in flags and conv_char != "p":
                if prefix:
                    s = prefix + s.zfill(pad_count + len(s) - len(prefix))
                    prefix = ""
                else:
                    s = s.zfill(width_val)
            else:
                pad = " " * pad_count
                if "-" in flags:
                    s = prefix + s + pad
                else:
                    s = pad + prefix + s
                    prefix = ""

    return prefix + s


class ARG_SIZE_TYPE(enum.IntEnum):
    U32 = 0
    STR = 1
    U64 = 2
    LZU32 = 3
    LZU64 = 4
    AZU32 = 5
    AZU64 = 6


def parse_args_bytes(byte_sequence, args_cnt, format_str):
    global TOTAL_REDUCE_NUM
    byte_sequence = bytes(byte_sequence)  # payload_view arrives as memoryview

    size_bytes_needed = (args_cnt + 1) // 2
    tokens = parse_format_string(format_str)
    args_cnt_in_fmt = len([tk for tk in tokens if isinstance(tk, tuple)])

    if len(byte_sequence) < size_bytes_needed:
        raise ValueError("Insufficient bytes for size list")

    if args_cnt_in_fmt != args_cnt:
        raise ValueError(
            f"Insufficient args count, excepted {args_cnt} actual {args_cnt_in_fmt}"
        )

    size_bytes = byte_sequence[:size_bytes_needed]
    arg_type = []

    for i in range(args_cnt):
        byte_idx = i // 2
        if i % 2 == 0:
            atp = (size_bytes[byte_idx] >> 4) & 0x0F
        else:
            atp = size_bytes[byte_idx] & 0x0F
        if atp not in ARG_SIZE_TYPE.__members__.values():
            raise ValueError(f"Unsupported arg type {atp}")
        arg_type.append(atp)

    data_start = size_bytes_needed
    args_data = []
    current_pos = data_start

    for atp in arg_type:
        if atp == ARG_SIZE_TYPE.U32:
            arg_bytes = byte_sequence[current_pos : current_pos + 4]
            args_data.append(arg_bytes)
            current_pos += 4
        elif atp == ARG_SIZE_TYPE.U64:
            arg_bytes = byte_sequence[current_pos : current_pos + 8]
            args_data.append(arg_bytes)
            current_pos += 8
        elif atp == ARG_SIZE_TYPE.LZU32:
            u32lz = int.from_bytes(
                byte_sequence[current_pos : current_pos + 1],
                byteorder="little",
                signed=False,
            )
            arg_bytes = (
                byte_sequence[current_pos + 1 : current_pos + 1 + 4 - u32lz]
                + b"\x00" * u32lz
            )
            args_data.append(arg_bytes)
            current_pos += 1 + 4 - u32lz
            TOTAL_REDUCE_NUM += u32lz - 1
        elif atp == ARG_SIZE_TYPE.LZU64:
            u64lz = int.from_bytes(
                byte_sequence[current_pos : current_pos + 1],
                byteorder="little",
                signed=False,
            )
            arg_bytes = (
                byte_sequence[current_pos + 1 : current_pos + 1 + 8 - u64lz]
                + b"\x00" * u64lz
            )
            args_data.append(arg_bytes)
            current_pos += 1 + 8 - u64lz
            TOTAL_REDUCE_NUM += u64lz - 1
        elif atp == ARG_SIZE_TYPE.AZU32:
            arg_bytes = b"\x00" * 4
            args_data.append(arg_bytes)
            TOTAL_REDUCE_NUM += 4
        elif atp == ARG_SIZE_TYPE.AZU64:
            arg_bytes = b"\x00" * 8
            args_data.append(arg_bytes)
            TOTAL_REDUCE_NUM += 8
        elif atp == ARG_SIZE_TYPE.STR:
            end_pos = current_pos + bytes(byte_sequence[current_pos:]).find(b"\x00")
            if end_pos < 0:
                raise ValueError("Invalid string data")
            arg_bytes = byte_sequence[current_pos : end_pos + 1]
            args_data.append(arg_bytes)
            current_pos = end_pos + 1
        else:
            raise ValueError(f"Unsupported arg type {atp}")

    output_parts = []
    arg_index = 0

    for token in tokens:
        if isinstance(token, tuple):
            _, _, full_spec, flags, width, length, conv_char = token
            if conv_char == "%":
                output_parts.append("%")
            else:
                if arg_index >= len(args_data):
                    raise ValueError(
                        f"Not enough arguments for format string {arg_index} {len(args_data)}"
                    )

                arg_bytes = args_data[arg_index]
                arg_index += 1

                if conv_char == "c":
                    s = chr(struct.unpack_from(">I", arg_bytes, 0)[0])
                    output_parts.append(s)

                elif conv_char == "p":
                    num = int.from_bytes(arg_bytes, byteorder="little", signed=False)
                    s = format_integer(num, conv_char, flags, width, length)
                    output_parts.append(s)

                elif conv_char == "f":
                    if len(arg_bytes) == 4:
                        val = struct.unpack("<f", arg_bytes)[0]
                    elif len(arg_bytes) == 8:
                        val = struct.unpack("<d", arg_bytes)[0]
                    else:
                        raise ValueError(
                            f"Unsupported float size: {len(arg_bytes)} bytes"
                        )
                    output_parts.append(str(val))

                elif conv_char == "s":
                    output_parts.append(
                        struct.unpack(f"<{len(arg_bytes) - 1}s", arg_bytes[:-1])[
                            0
                        ].decode("utf-8")
                    )
                elif conv_char in "diuoxX":
                    signed = conv_char in "di"

                    if length == "ll":
                        expected_size = 8
                    elif length == "l" or conv_char == "p" or length == "z":
                        expected_size = 4
                    else:
                        expected_size = len(arg_bytes)

                    if len(arg_bytes) < expected_size:
                        if signed:
                            sign_bit = (arg_bytes[-1] >> 7) & 0x01
                            extension = b"\xff" if sign_bit else b"\x00"
                        else:
                            extension = b"\x00"
                        arg_bytes = (
                            extension * (expected_size - len(arg_bytes)) + arg_bytes
                        )
                    elif len(arg_bytes) > expected_size:
                        arg_bytes = arg_bytes[:expected_size]

                    num = int.from_bytes(arg_bytes, byteorder="little", signed=signed)
                    s = format_integer(num, conv_char, flags, width, length)
                    output_parts.append(s)

                else:
                    raise ValueError(
                        f"Unsupported format specifier: {full_spec} {format_str}"
                    )
        else:
            output_parts.append(token)

    return "".join(output_parts)
