"""Capture-wide protocol evidence, independent of ordering success."""

from dataclasses import dataclass, field

from ble_log_frame_decoder.analysis.core.source_codes import BleLogSource
from ble_log_frame_decoder.checking.protocol import (
    is_snapshot,
    is_task_binding,
    is_valid_internal_candidate,
)


def encoded_has_task_id(payload: bytes | memoryview) -> bool | None:
    """Identify supported ENCODE prefixes; malformed prefixes give no evidence."""
    if len(payload) < 8 or payload[4] > 4:
        return None
    first = payload[5]
    # Firmware registry capacity is at most 32; 0xff means unknown task.
    task_id = first < 32 or first == 0xFF
    offset = 6 if task_id else 5
    if not task_id and first == 0xC2:
        offset += 1  # Legacy in-band TASK_SWITCH precedes the actual header.
    if len(payload) < offset + 3:
        return None
    header = payload[offset]
    if 0x40 <= header < 0x80:
        if len(payload) < offset + 3 + ((header & 0x3F) + 1) // 2:
            return None
    elif not (0x80 <= header < 0xC0 or header == 0xC1):
        return None
    return task_id


@dataclass(frozen=True)
class CaptureProtocol:
    version: int | None
    is_v8: bool
    basis: str

    @property
    def tl_version(self) -> int | None:
        # Legacy ENCODE identifies pre-v8, not which pre-v8 LL ID table to use.
        return 8 if self.is_v8 else self.version


@dataclass
class ProtocolEvidence:
    versions: set[int] = field(default_factory=set)
    v8: set[str] = field(default_factory=set)
    legacy: set[str] = field(default_factory=set)

    def observe(self, source: int, payload: bytes | memoryview) -> None:
        if source == BleLogSource.INTERNAL:
            if not is_valid_internal_candidate(payload):
                return
            if is_snapshot(payload):
                self.v8.add("SNAPSHOT")
                if payload[10] == 7 and payload[11] >= 6:
                    self.versions.add(payload[11])
            elif is_task_binding(payload):
                self.v8.add("TASK_BINDING")
            elif payload[4] in (0, 3, 4):
                self.versions.add(payload[5])
            elif payload[4] == 7:
                if payload[5] >= 6:
                    self.versions.add(payload[5])
            else:
                self.legacy.add("legacy INTERNAL")
        elif source == BleLogSource.ENCODE:
            has_task_id = encoded_has_task_id(payload)
            if has_task_id is not None:
                (self.v8 if has_task_id else self.legacy).add("ENCODE prefix")

    def resolve(self) -> CaptureProtocol:
        if len(self.versions) > 1:
            raise ValueError(f"Conflicting BLE Log versions: {sorted(self.versions)}")
        version = next(iter(self.versions), None)
        if version is not None and version > 8:
            raise ValueError(f"Unsupported BLE Log version: {version}")
        # Both layouts may advertise version 8; only record shapes prove v8.
        new = bool(self.v8)
        old = bool(self.legacy) or (version is not None and version < 8)
        if new and old:
            raise ValueError(
                "Conflicting BLE Log protocol evidence: "
                f"version={version}, v8={sorted(self.v8)}, legacy={sorted(self.legacy)}"
            )
        if old and self.legacy:
            basis = "inferred pre-v8 from " + ", ".join(sorted(self.legacy))
            if version is not None:
                basis = f"explicit version v{version}; " + basis
        elif version is not None:
            basis = f"explicit version v{version}"
        elif new or old:
            basis = "inferred from " + ", ".join(sorted(self.v8 | self.legacy))
        else:
            basis = "no identifying records; default v8"
        return CaptureProtocol(version, not old, basis)
