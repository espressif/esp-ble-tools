"""Selective semantic decoding; state belongs to one capture session."""

from ble_log_frame_decoder import (
    InternalLogInfo,
    is_snapshot,
    is_task_binding,
    parse_snapshot,
    parse_snapshot_version_info,
    parse_version_info_payload,
)

from .core.snapshot_protocol import task_names_from_binding
from .records import Record


class ContentDecoder:
    def __init__(
        self, capabilities, database=None, *, max_pending_bytes=64 * 1024 * 1024
    ):
        self.capabilities = capabilities
        self.database = database
        self.max_pending_bytes = max_pending_bytes
        self.version = None
        self.task_names = {}
        self._compressed = None

    def reset(self):
        records = self.finish()
        self.task_names.clear()
        self._compressed = None
        self.version = None
        return records

    def observe(self, payload):
        try:
            if is_snapshot(payload):
                self.version = parse_snapshot_version_info(
                    parse_snapshot(payload)
                ).version
            elif len(payload) >= 5 and payload[4] == 7:
                self.version = parse_version_info_payload(payload).version
            elif len(payload) >= 5 and payload[4] in (0, 3, 4):
                self.version = InternalLogInfo.from_payload(payload).version
            elif is_task_binding(payload) and self.version is None:
                self.version = 8
        except ValueError:
            return
        names = task_names_from_binding(payload)
        self.task_names.update(names)

    def feed(self, frame, timestamp=None):
        source, sn, payload = frame.source_code, frame.raw_sn, frame.payload_view
        reason = ""
        if source == 0:
            self.observe(payload)
            return []
        if source == 1 and "custom" in self.capabilities:
            if len(payload) >= 7 and payload[4:6] == b"\x00\x00" and payload[6] <= 4:
                return [
                    Record(
                        "custom",
                        source,
                        sn,
                        value=payload[6],
                        record_id=frame.payload_offset,
                        reason=reason,
                    )
                ]
            return []
        if (source == 5 and "host" in self.capabilities) or (
            source == 6 and "hci" in self.capabilities
        ):
            if len(payload) < (6 if source == 6 else 4):
                return [
                    Record(
                        "undecodable",
                        source,
                        sn,
                        raw=bytes(payload),
                        text=bytes(payload).hex(" "),
                        incomplete=True,
                        record_id=frame.payload_offset,
                        reason="short_payload",
                    )
                ]
            raw_ts = (
                int.from_bytes(payload[:4], "little")
                if timestamp is None
                else timestamp
            )
            ts = (
                None
                if self.version is None
                else raw_ts * (1 if self.version >= 8 else 1000)
            )
            if ts is None:
                reason = "unknown_clock_unit"
            if source == 5:
                text = bytes(payload[4:]).decode("utf-8", "replace")
                return [
                    Record(
                        "host",
                        source,
                        sn,
                        ts,
                        text=text,
                        raw=bytes(payload),
                        record_id=frame.payload_offset,
                        reason=reason,
                    )
                ]
            packet_type = payload[4] & 0x7F
            incoming = packet_type == 4 or (
                packet_type != 1 and bool(payload[4] & 0x80)
            )
            clock = (
                f"{ts} us" if ts is not None else f"raw clock={raw_ts} (unit unknown)"
            )
            text = f"{clock} {'RX' if incoming else 'TX'} HCI type={packet_type} {bytes(payload[5:]).hex(' ')}"
            return [
                Record(
                    "hci",
                    source,
                    sn,
                    ts,
                    value=packet_type,
                    text=text,
                    raw=bytes(payload),
                    record_id=frame.payload_offset,
                    reason=reason,
                )
            ]
        if source == 7 and "host" in self.capabilities:
            if len(payload) < 5 or payload[4] != 0:
                return []
            if not self.database:
                return [
                    Record(
                        "undecodable",
                        source,
                        sn,
                        raw=bytes(payload),
                        text=bytes(payload).hex(" "),
                        incomplete=True,
                        record_id=frame.payload_offset,
                        reason="missing_database",
                    )
                ]
            if self.version is None:
                return [
                    Record(
                        "undecodable",
                        source,
                        sn,
                        raw=bytes(payload),
                        text=bytes(payload).hex(" "),
                        incomplete=True,
                        record_id=frame.payload_offset,
                        reason="unknown_protocol",
                    )
                ]
            if self._compressed is None:
                from .compressed.streaming import CompressedDecoder

                self._compressed = CompressedDecoder(
                    self.database,
                    self.version,
                    self.task_names,
                    max_pending_bytes=self.max_pending_bytes,
                )
            return self._compressed.feed(frame, timestamp)
        return []

    def finish(self):
        return self._compressed.finish() if self._compressed else []

    def close(self):
        self._compressed = None
        self.task_names.clear()
