"""Shared esp-blfd configuration for all v2 frame scanning."""

from ble_log_frame_decoder import FrameDecoder, FrameFormat
from ble_log_frame_decoder.checking.protocol import FRAME_CANDIDATE_POLICIES


def create_frame_decoder(max_frame_size: int) -> FrameDecoder:
    """Create a v2 XOR32 decoder with the parser's payload candidate policy."""
    return FrameDecoder(
        FrameFormat.BLE_LOG_V2_XOR32,
        max_frame_size=max_frame_size,
        candidate_policies=FRAME_CANDIDATE_POLICIES,
    )
