"""Disk-backed complete-file ordering and Host/HCI exports.

Import this module only for offline work; lightweight sessions do not import NumPy.
"""

import json
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace

from ble_log_frame_decoder.checking import CheckResult

from .compressed.decompress import parse_compressed_logs
from .content import ContentDecoder
from .core.parse_context import ParseContext
from .core.snapshot_protocol import task_names_from_binding
from .core.source_codes import BleLogSource
from .hci_export import hci_log_handler
from .host import write_host_text
from .ordering.frame_metadata import prepare_frame_metadata
from .ordering.frame_model import LcTimerUnit
from .ordering.metadata_ordering import OrderedFrameSource, order_metadata_store


@contextmanager
def ordered_capture(
    path: str | Path, *, chunk_size=1024 * 1024, lc_timer_unit=LcTimerUnit.US
):
    """Yield an ordered source and full raw-scan integrity; views are borrowed.

    Payloads stay in the original mmap, metadata and permutations live on disk.
    Consume yielded views synchronously; copy only what must outlive iteration.
    """
    path = Path(path)
    scanned = prepare_frame_metadata(path, chunk_size=chunk_size)
    ordering = None
    try:
        ordering = order_metadata_store(
            scanned.store,
            path,
            scanned.scratch_dir / "ordering",
            lc_timer_unit=lc_timer_unit,
        )
        if path.stat().st_size == 0:
            yield None, scanned.store.integrity
        else:
            with OrderedFrameSource(path, ordering) as frames:
                yield frames, scanned.store.integrity
    finally:
        if ordering is not None:
            ordering.close()
        scanned.close()


@dataclass(frozen=True)
class ExportResult:
    integrity: CheckResult
    paths: tuple[Path, ...]
    warnings: tuple[str, ...]


def export_file(
    path: str | Path,
    output_dir: str | Path,
    *,
    database: str | Path | None = None,
    chunk_size=1024 * 1024,
    lc_timer_unit=LcTimerUnit.US,
) -> ExportResult:
    """Export Host, compressed logs, binary HCI BTSnoop, and full checker JSON.

    Call after closing the raw writer. External clock synchronization, if needed,
    belongs in the application and can use ordered_capture plus hci_log_handler.
    """
    path, output_dir = Path(path), Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    context = ParseContext()
    warnings = []
    with ordered_capture(path, chunk_size=chunk_size, lc_timer_unit=lc_timer_unit) as (
        frames,
        integrity,
    ):
        context.integrity = integrity
        if frames is not None:
            metadata = ContentDecoder(())
            identities = set()
            for frame, order in frames.iter_views_with_context(
                sources={BleLogSource.INTERNAL, BleLogSource.CUSTOM}
            ):
                payload = frame.payload_view
                if frame.source_code == 0:
                    metadata.observe(payload)
                    context.task_names_by_instance.setdefault(
                        order.instance_index, {}
                    ).update(task_names_from_binding(payload))
                elif len(payload) == 7 and payload[4:6] == b"\x00\x00":
                    identities.add(payload[6])
            context.ble_log_version = metadata.version
            ssc = (
                f"SSC{next(iter(identities)) + 1}"
                if len(identities) == 1
                else "SSC_UNKNOWN"
            )
            prefix = output_dir / f"{path.stem}_{ssc}"
            write_host_text(
                frames.iter_views(sources={BleLogSource.HOST}),
                output_dir / f"{path.stem}_host_{ssc}.log",
                context=context,
            )
            if (
                database is not None
                and not (Path(database) / "BLE_HOST_logs.json").is_file()
            ):
                warnings.append(
                    "BLE_HOST_logs.json not found; compressed Host payloads remain in the bin."
                )
            if database is not None:
                parse_compressed_logs(
                    frames.iter_views_with_context(sources={BleLogSource.ENCODE}),
                    str(database),
                    str(prefix),
                    context=context,
                    has_task_id=frames.result.uses_global_sn,
                )
            elif any(True for _ in frames.iter_views(sources={BleLogSource.ENCODE})):
                warnings.append(
                    "Compressed log database not configured; original payloads remain in the bin."
                )
            hci_log_handler(
                frames.iter_views_with_context(sources={BleLogSource.HCI}),
                SimpleNamespace(inited=False),
                output_dir / f"{path.stem}_hci_btsnoop_{ssc}.log",
                context=context,
            )
    assert integrity is not None
    warnings.extend(w.message for w in context.warnings)
    report = output_dir / f"{path.stem}.checker.json"
    report.write_text(
        json.dumps(integrity.to_dict(), indent=2) + "\n", encoding="utf-8"
    )
    return ExportResult(integrity, (*context.output_files, report), tuple(warnings))
