from libc.stdint cimport int32_t, int64_t, uint8_t, uint32_t, uint64_t
from libc.stdlib cimport free, realloc

import cython


cdef uint32_t UINT32_MAX_VALUE = 0xFFFFFFFF
cdef int64_t INT64_MAX_VALUE = 0x7FFFFFFFFFFFFFFF
cdef int64_t INT64_MIN_VALUE = -INT64_MAX_VALUE - 1
cdef int64_t ANCHOR_FAIL = INT64_MIN_VALUE
cdef int64_t INTERPOLATE_OVERFLOW = INT64_MIN_VALUE + 1
cdef uint64_t CLOCK_PERIOD = 1 << 32

cdef uint8_t CONFIDENCE_HIGH = 0
cdef uint8_t CONFIDENCE_MEDIUM = 1
cdef uint8_t CONFIDENCE_ALIGNED = 2
cdef uint8_t CONFIDENCE_LOW = 3
cdef uint8_t RELIABLE_SN_FLAG = 1 << 1


cdef struct UIntHeap:
    uint32_t* data
    Py_ssize_t size
    Py_ssize_t capacity


cdef inline void heap_init(UIntHeap* heap) noexcept:
    heap.data = NULL
    heap.size = 0
    heap.capacity = 0


cdef inline void heap_free(UIntHeap* heap) noexcept:
    free(heap.data)
    heap.data = NULL
    heap.size = 0
    heap.capacity = 0


cdef void heap_push(UIntHeap* heap, uint32_t value) except *:
    cdef Py_ssize_t index
    cdef Py_ssize_t parent
    cdef Py_ssize_t capacity
    cdef void* resized

    if heap.size == heap.capacity:
        capacity = 8 if heap.capacity == 0 else heap.capacity * 2
        resized = realloc(heap.data, capacity * cython.sizeof(uint32_t))
        if resized == NULL:
            raise MemoryError()
        heap.data = <uint32_t*>resized
        heap.capacity = capacity

    index = heap.size
    heap.size += 1
    while index:
        parent = (index - 1) >> 1
        if heap.data[parent] <= value:
            break
        heap.data[index] = heap.data[parent]
        index = parent
    heap.data[index] = value


cdef inline uint32_t heap_pop(UIntHeap* heap) noexcept:
    cdef uint32_t root = heap.data[0]
    cdef uint32_t value
    cdef Py_ssize_t index = 0
    cdef Py_ssize_t child

    heap.size -= 1
    if heap.size == 0:
        return root
    value = heap.data[heap.size]
    while True:
        child = index * 2 + 1
        if child >= heap.size:
            break
        if child + 1 < heap.size and heap.data[child + 1] < heap.data[child]:
            child += 1
        if heap.data[child] >= value:
            break
        heap.data[index] = heap.data[child]
        index = child
    heap.data[index] = value
    return root


cdef inline int64_t heap_first(UIntHeap* heap) noexcept:
    return heap.data[0] if heap.size else -1


cdef inline int64_t heap_second(UIntHeap* heap) noexcept:
    if heap.size < 2:
        return -1
    if heap.size == 2:
        return heap.data[1]
    return heap.data[1] if heap.data[1] < heap.data[2] else heap.data[2]


cdef inline uint64_t unwrap_clock(
    uint32_t raw,
    bint has_split,
    uint32_t split_low,
) noexcept:
    if has_split and raw <= split_low:
        return <uint64_t>raw + CLOCK_PERIOD
    return raw


@cython.cdivision(True)
cdef int64_t interpolate_os_ms(
    int64_t clock,
    int64_t lc_left,
    int64_t lc_right,
    int64_t os_left,
    int64_t os_right,
):
    cdef int64_t lc_delta = lc_right - lc_left
    cdef int64_t os_delta = os_right - os_left
    cdef int64_t clock_delta = clock - lc_left
    cdef int64_t numerator
    cdef int64_t quotient
    cdef int64_t remainder

    if lc_delta <= 0 or os_delta < 0:
        return ANCHOR_FAIL
    if (
        (clock_delta > 0 and os_delta > INT64_MAX_VALUE // clock_delta)
        or (
            clock_delta < 0
            and os_delta > 0
            and clock_delta < INT64_MIN_VALUE // os_delta
        )
    ):
        return INTERPOLATE_OVERFLOW

    numerator = clock_delta * os_delta
    quotient = numerator / lc_delta
    remainder = numerator % lc_delta
    if numerator < 0 and remainder:
        quotient -= 1
    if (
        (quotient > 0 and os_left > INT64_MAX_VALUE - quotient)
        or (quotient < 0 and os_left < INT64_MIN_VALUE - quotient)
    ):
        return INTERPOLATE_OVERFLOW
    return os_left + quotient


cdef int map_lc_common_us(
    int64_t clock,
    const int64_t[::1] anchor_lc,
    const int64_t[::1] anchor_os,
    int64_t* common_us,
    bint* outside,
    int time_scale,
) except -1:
    cdef Py_ssize_t count = anchor_lc.shape[0]
    cdef Py_ssize_t lo = 0
    cdef Py_ssize_t hi = count
    cdef Py_ssize_t index
    cdef Py_ssize_t left
    cdef Py_ssize_t right
    cdef int64_t os_ms

    if count < 2:
        return 0
    outside[0] = clock < anchor_lc[0] or clock > anchor_lc[count - 1]
    while lo < hi:
        index = lo + ((hi - lo) >> 1)
        if anchor_lc[index] < clock:
            lo = index + 1
        else:
            hi = index
    if lo == 0:
        left = 0
        right = 1
    elif lo >= count:
        left = count - 2
        right = count - 1
    else:
        left = lo - 1
        right = lo

    os_ms = interpolate_os_ms(
        clock,
        anchor_lc[left],
        anchor_lc[right],
        anchor_os[left],
        anchor_os[right],
    )
    if os_ms == INTERPOLATE_OVERFLOW:
        return 2
    if os_ms == ANCHOR_FAIL:
        return 0
    if os_ms > INT64_MAX_VALUE // time_scale or os_ms < INT64_MIN_VALUE // time_scale:
        return 2
    common_us[0] = os_ms * time_scale
    return 1


cdef object map_lc_common_object(
    int64_t clock,
    const int64_t[::1] anchor_lc,
    const int64_t[::1] anchor_os,
    int time_scale,
):
    cdef Py_ssize_t count = anchor_lc.shape[0]
    cdef Py_ssize_t lo = 0
    cdef Py_ssize_t hi = count
    cdef Py_ssize_t index
    cdef Py_ssize_t left
    cdef Py_ssize_t right

    while lo < hi:
        index = lo + ((hi - lo) >> 1)
        if anchor_lc[index] < clock:
            lo = index + 1
        else:
            hi = index
    if lo == 0:
        left = 0
        right = 1
    elif lo >= count:
        left = count - 2
        right = count - 1
    else:
        left = lo - 1
        right = lo
    return (
        <object>anchor_os[left]
        + (<object>clock - <object>anchor_lc[left])
        * (<object>anchor_os[right] - <object>anchor_os[left])
        // (<object>anchor_lc[right] - <object>anchor_lc[left])
    ) * time_scale


cdef inline void add_ready(
    uint32_t row,
    UIntHeap* no_clock,
    UIntHeap* lc,
    UIntHeap* freertos,
    const uint32_t[::1] priority_position,
    const uint32_t[::1] source_sn,
    const uint8_t[::1] domain_by_source,
) except *:
    cdef uint32_t position = priority_position[row]
    cdef uint8_t source
    if position == UINT32_MAX_VALUE:
        heap_push(no_clock, row)
        return
    source = <uint8_t>(source_sn[row] & 0xFF)
    if domain_by_source[source] == 0:
        heap_push(lc, position)
    else:
        heap_push(freertos, position)


@cython.boundscheck(False)
@cython.wraparound(False)
def linearize_instance(
    const uint32_t[::1] rows not None,
    const int32_t[::1] successor not None,
    uint8_t[::1] indegree not None,
    const uint32_t[::1] priority_rows not None,
    const uint32_t[::1] priority_position not None,
    const uint32_t[::1] source_sn not None,
    const uint32_t[::1] raw_clock not None,
    const uint8_t[::1] flags not None,
    const uint8_t[::1] domain_by_source not None,
    bint lc_has_split,
    uint32_t lc_split_low,
    bint freertos_has_split,
    uint32_t freertos_split_low,
    const int64_t[::1] anchor_lc not None,
    const int64_t[::1] anchor_os not None,
    uint32_t[::1] output_rows not None,
    uint8_t[::1] confidence not None,
    int time_scale=1000,
):
    """Linearize one instance and return numeric choice counters."""
    cdef Py_ssize_t total = source_sn.shape[0]
    cdef Py_ssize_t k
    cdef Py_ssize_t output_cursor = 0
    cdef Py_ssize_t ready_count = 0
    cdef uint32_t row
    cdef uint32_t chosen
    cdef uint32_t other
    cdef uint32_t popped
    cdef int32_t next_row
    cdef int chosen_kind
    cdef int transport_kind
    cdef int candidate_count
    cdef int64_t no_clock_candidate
    cdef int64_t lc_position
    cdef int64_t freertos_position
    cdef int64_t lc_candidate
    cdef int64_t freertos_candidate
    cdef int64_t transport_candidate
    cdef int64_t second
    cdef uint8_t level
    cdef uint64_t lc_clock
    cdef uint64_t freertos_clock
    cdef uint32_t lc_cached_row = UINT32_MAX_VALUE
    cdef uint32_t freertos_cached_row = UINT32_MAX_VALUE
    cdef int64_t lc_cached_common = ANCHOR_FAIL
    cdef int64_t freertos_cached_common = ANCHOR_FAIL
    cdef object lc_cached_object = None
    cdef int map_status
    cdef bint lc_cached_object_mode = False
    cdef bint common_valid
    cdef bint lc_before_freertos
    cdef bint lc_cached_outside = False
    cdef bint freertos_cached_outside = False
    cdef bint anchor_usable = anchor_lc.shape[0] >= 2
    cdef int64_t tie_decisions = 0
    cdef int64_t sn_forced_choices = 0
    cdef int64_t transport_choices = 0
    cdef int64_t clock_choices = 0
    cdef int64_t aligned_choices = 0
    cdef UIntHeap no_clock_ready
    cdef UIntHeap lc_ready
    cdef UIntHeap freertos_ready

    if successor.shape[0] != total or indegree.shape[0] != total:
        raise ValueError("graph columns must match source rows")
    if priority_position.shape[0] != total:
        raise ValueError("priority positions must match source rows")
    if raw_clock.shape[0] != total or flags.shape[0] != total:
        raise ValueError("frame columns must have equal lengths")
    if confidence.shape[0] != total:
        raise ValueError("confidence must match source rows")
    if output_rows.shape[0] != rows.shape[0]:
        raise ValueError("output rows must match instance rows")
    if anchor_lc.shape[0] != anchor_os.shape[0]:
        raise ValueError("anchor columns must have equal lengths")
    if domain_by_source.shape[0] < 256:
        raise ValueError("domain lookup must contain 256 entries")

    heap_init(&no_clock_ready)
    heap_init(&lc_ready)
    heap_init(&freertos_ready)
    try:
        for k in range(rows.shape[0]):
            row = rows[k]
            if indegree[row] == 0:
                add_ready(
                    row,
                    &no_clock_ready,
                    &lc_ready,
                    &freertos_ready,
                    priority_position,
                    source_sn,
                    domain_by_source,
                )
                ready_count += 1

        while ready_count:
            if ready_count == 1:
                if no_clock_ready.size:
                    chosen = no_clock_ready.data[0]
                    chosen_kind = 0
                elif lc_ready.size:
                    chosen = priority_rows[lc_ready.data[0]]
                    chosen_kind = 1
                else:
                    chosen = priority_rows[freertos_ready.data[0]]
                    chosen_kind = 2
                level = CONFIDENCE_HIGH
                sn_forced_choices += 1
            else:
                no_clock_candidate = heap_first(&no_clock_ready)
                lc_position = heap_first(&lc_ready)
                lc_candidate = (
                    priority_rows[lc_position] if lc_position >= 0 else -1
                )
                freertos_position = heap_first(&freertos_ready)
                freertos_candidate = (
                    priority_rows[freertos_position]
                    if freertos_position >= 0
                    else -1
                )
                candidate_count = (
                    (1 if no_clock_candidate >= 0 else 0)
                    + (1 if lc_candidate >= 0 else 0)
                    + (1 if freertos_candidate >= 0 else 0)
                )
                transport_candidate = no_clock_candidate
                transport_kind = 0
                if lc_candidate >= 0 and (
                    transport_candidate < 0 or lc_candidate < transport_candidate
                ):
                    transport_candidate = lc_candidate
                    transport_kind = 1
                if freertos_candidate >= 0 and (
                    transport_candidate < 0
                    or freertos_candidate < transport_candidate
                ):
                    transport_candidate = freertos_candidate
                    transport_kind = 2
                if transport_candidate < 0:
                    raise AssertionError("ready set lost every candidate")

                chosen = UINT32_MAX_VALUE
                chosen_kind = -1
                level = CONFIDENCE_LOW
                if (
                    anchor_usable
                    and no_clock_candidate >= 0
                    and no_clock_candidate == transport_candidate
                ):
                    chosen = <uint32_t>no_clock_candidate
                    chosen_kind = 0
                    transport_choices += 1
                    tie_decisions += 1
                elif (
                    anchor_usable
                    and lc_candidate >= 0
                    and freertos_candidate >= 0
                ):
                    if lc_cached_row != <uint32_t>lc_candidate:
                        lc_clock = unwrap_clock(
                            raw_clock[lc_candidate],
                            lc_has_split,
                            lc_split_low,
                        )
                        if lc_clock > <uint64_t>INT64_MAX_VALUE:
                            raise OverflowError("LC clock is outside int64")
                        map_status = map_lc_common_us(
                            <int64_t>lc_clock,
                            anchor_lc,
                            anchor_os,
                            &lc_cached_common,
                            &lc_cached_outside,
                            time_scale,
                        )
                        if map_status == 0:
                            lc_cached_common = ANCHOR_FAIL
                            lc_cached_object_mode = False
                            lc_cached_object = None
                        elif map_status == 2:
                            lc_cached_object = map_lc_common_object(
                                <int64_t>lc_clock,
                                anchor_lc,
                                anchor_os,
                                time_scale,
                            )
                            lc_cached_object_mode = True
                        else:
                            lc_cached_object_mode = False
                            lc_cached_object = None
                        lc_cached_row = <uint32_t>lc_candidate
                    if freertos_cached_row != <uint32_t>freertos_candidate:
                        freertos_clock = unwrap_clock(
                            raw_clock[freertos_candidate],
                            freertos_has_split,
                            freertos_split_low,
                        )
                        if freertos_clock > <uint64_t>(INT64_MAX_VALUE // time_scale):
                            raise OverflowError("FreeRTOS clock is outside int64")
                        freertos_cached_common = <int64_t>freertos_clock * time_scale
                        freertos_cached_outside = (
                            freertos_clock < <uint64_t>anchor_os[0]
                            or freertos_clock
                            > <uint64_t>anchor_os[anchor_os.shape[0] - 1]
                        )
                        freertos_cached_row = <uint32_t>freertos_candidate
                    common_valid = False
                    lc_before_freertos = False
                    if freertos_cached_common != ANCHOR_FAIL:
                        if lc_cached_object_mode:
                            common_valid = (
                                lc_cached_object != freertos_cached_common
                            )
                            if common_valid:
                                lc_before_freertos = (
                                    lc_cached_object < freertos_cached_common
                                )
                        elif lc_cached_common != ANCHOR_FAIL:
                            common_valid = (
                                lc_cached_common != freertos_cached_common
                            )
                            if common_valid:
                                lc_before_freertos = (
                                    lc_cached_common < freertos_cached_common
                                )
                    if common_valid:
                        if lc_before_freertos:
                            chosen = <uint32_t>lc_candidate
                            chosen_kind = 1
                        else:
                            chosen = <uint32_t>freertos_candidate
                            chosen_kind = 2
                        if lc_cached_outside or freertos_cached_outside:
                            level = CONFIDENCE_MEDIUM
                            clock_choices += 1
                        else:
                            level = CONFIDENCE_ALIGNED
                            aligned_choices += 1

                if chosen_kind < 0:
                    chosen = <uint32_t>transport_candidate
                    chosen_kind = transport_kind
                    if candidate_count == 1 and priority_position[chosen] != UINT32_MAX_VALUE:
                        if chosen_kind == 1:
                            second = heap_second(&lc_ready)
                        else:
                            second = heap_second(&freertos_ready)
                        if second >= 0:
                            other = priority_rows[second]
                        if second >= 0 and raw_clock[other] == raw_clock[chosen]:
                            transport_choices += 1
                            tie_decisions += 1
                        else:
                            level = CONFIDENCE_MEDIUM
                            clock_choices += 1
                    else:
                        transport_choices += 1
                        tie_decisions += 1

            if not (flags[chosen] & RELIABLE_SN_FLAG):
                level = CONFIDENCE_LOW
            confidence[chosen] = level
            output_rows[output_cursor] = chosen
            output_cursor += 1

            if chosen_kind == 0:
                popped = heap_pop(&no_clock_ready)
                if popped != chosen:
                    raise AssertionError("invalid no-clock ready head")
            elif chosen_kind == 1:
                popped = heap_pop(&lc_ready)
                if priority_rows[popped] != chosen:
                    raise AssertionError("invalid LC ready head")
            else:
                popped = heap_pop(&freertos_ready)
                if priority_rows[popped] != chosen:
                    raise AssertionError("invalid FreeRTOS ready head")
            ready_count -= 1

            next_row = successor[chosen]
            if next_row >= 0:
                if indegree[next_row] != 1:
                    raise AssertionError("invalid hard SN indegree")
                indegree[next_row] = 0
                add_ready(
                    <uint32_t>next_row,
                    &no_clock_ready,
                    &lc_ready,
                    &freertos_ready,
                    priority_position,
                    source_sn,
                    domain_by_source,
                )
                ready_count += 1

        if no_clock_ready.size or lc_ready.size or freertos_ready.size:
            raise AssertionError("instance left stale ready frames")
        if output_cursor != rows.shape[0]:
            raise AssertionError("hard SN constraints contain a cycle")
        return (
            tie_decisions,
            sn_forced_choices,
            transport_choices,
            clock_choices,
            aligned_choices,
        )
    finally:
        heap_free(&no_clock_ready)
        heap_free(&lc_ready)
        heap_free(&freertos_ready)
