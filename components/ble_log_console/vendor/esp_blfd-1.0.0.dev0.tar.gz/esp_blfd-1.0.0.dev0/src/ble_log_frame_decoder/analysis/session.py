"""One decoder, arrival-order checker, and selectively enabled content parsing."""

import time
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Self

from ble_log_frame_decoder import DecodeStats, FrameDecoder, FrameFormat, FrameView
from ble_log_frame_decoder.checking import CheckResult, LogChecker
from ble_log_frame_decoder.checking.protocol import FRAME_CANDIDATE_POLICIES

from .content import ContentDecoder
from .firmware import FirmwareSnapshot, FirmwareStats
from .live import LiveOrdering
from .records import Record


@dataclass(frozen=True, slots=True)
class ParseBatch:
    records: tuple[Record, ...] = ()
    frames_decoded: int = 0


@dataclass(frozen=True, slots=True)
class SessionSnapshot:
    status: str
    scan: DecodeStats
    integrity: CheckResult | None = None
    pending_records: int = 0
    pending_bytes: int = 0
    firmware: FirmwareSnapshot | None = None


@dataclass(frozen=True, slots=True)
class SessionResult:
    scan: DecodeStats
    integrity: CheckResult | None
    records: tuple[Record, ...] = ()
    firmware: FirmwareSnapshot | None = None


class ParserSession:
    """A session owns its decoder and checker. frame_sink borrows views synchronously.

    snapshot reports progress, not an EOF verdict. Only finish seals integrity.
    """

    def __init__(
        self,
        input_path: str | Path | None = None,
        *,
        check: bool = True,
        firmware_stats: bool = False,
        decode: Iterable[str] = (),
        ordering: str = "arrival",
        decoder: FrameDecoder | None = None,
        frame_sink: Callable[[FrameView], None] | None = None,
        database: str | Path | None = None,
        clock: Callable[[], float] = time.monotonic,
        max_wait: float = 3.0,
        max_pending_bytes: int = 64 * 1024 * 1024,
        max_pending_records: int = 250_000,
    ) -> None:
        self.decode = frozenset(decode)
        if self.decode - {"custom", "host", "hci"}:
            raise ValueError("unsupported decode capability")
        if ordering not in {"arrival", "live"}:
            raise ValueError("unsupported ordering")
        self._selected = (
            ({1} if "custom" in self.decode else set())
            | ({5, 7} if "host" in self.decode else set())
            | ({6} if "hci" in self.decode else set())
        )
        self._clock = clock
        self._now = clock()
        self._content = (
            ContentDecoder(self.decode, database, max_pending_bytes=max_pending_bytes)
            if self.decode
            else None
        )
        self._live = (
            LiveOrdering(
                max_wait=max_wait,
                max_bytes=max_pending_bytes,
                max_records=max_pending_records,
            )
            if ordering == "live"
            else None
        )
        self.decoder = (
            decoder
            if decoder is not None
            else FrameDecoder(
                FrameFormat.BLE_LOG_V2_XOR32,
                max_frame_size=4106,
                candidate_policies=FRAME_CANDIDATE_POLICIES,
            )
        )
        if self.decoder.format not in (
            FrameFormat.BLE_LOG_V2_XOR32,
            FrameFormat.BLE_LOG_V2_SUM32,
        ):
            raise ValueError("ParserSession supports only explicit v2 formats")
        self._checker = LogChecker(input_path) if check else None
        self._firmware = FirmwareStats() if firmware_stats else None
        self._sink = frame_sink
        self._closed = False
        self._result = None
        self._records = []

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def _require_open(self):
        if self._closed or self._result is not None:
            raise RuntimeError("ParserSession is finished or closed")

    def _consume(self, frame):
        if self._checker is not None:
            self._checker.feed(frame)
        if self._firmware is not None:
            self._firmware.feed(frame)
        if self._sink is not None:
            self._sink(frame)
        if self._content is None:
            return
        if frame.source_code == 0:
            payload = frame.payload_view
            reset = (len(payload) == 169 and payload[4] == 8 and payload[5] & 1) or (
                len(payload) == 6 and payload[4] == 0
            )
            if reset:
                self._drain()
                self._records.extend(self._content.reset())
                if self._live:
                    self._live.reset()
            self._content.observe(payload)
            if self._live and len(payload) >= 5:
                snapshot = len(payload) == 169 and payload[4] == 8
                if snapshot or (not self._global_sn and payload[4] in (0, 1, 3, 4)):
                    self._live.observe_anchor(
                        frame.raw_sn,
                        int.from_bytes(payload[:4], "little"),
                        self._global_sn,
                    )
            return
        if frame.source_code not in self._selected:
            return
        if self._live:
            self._emit(self._live.push(frame, self._now, self._global_sn))
        else:
            self._records.extend(self._content.feed(frame))

    @property
    def _global_sn(self):
        return (
            self._content is not None
            and self._content.version is not None
            and self._content.version >= 8
        )

    def _emit(self, items):
        if self._content is None:
            return
        for item in items:
            self._records.extend(self._content.feed(item.view(), item.timestamp))

    def _drain(self):
        if self._live and self._content:
            self._emit(self._live.drain(self._global_sn))

    def feed(self, chunk: bytes) -> ParseBatch:
        self._require_open()
        self._now = self._clock()
        before = self.decoder.stats.frames_decoded
        self._records = []
        try:
            if self.decoder.format is FrameFormat.BLE_LOG_V2_XOR32:
                self.decoder.feed_into(
                    chunk,
                    sink=(
                        self._checker.feed
                        if self._checker is not None
                        and self._content is None
                        and self._firmware is None
                        and self._sink is None
                        else self._consume
                    ),
                )
            else:
                for f in self.decoder.feed(chunk):
                    self._consume(
                        FrameView(
                            f.source_code,
                            f.sequence_number,
                            f.offset + 6,
                            len(f.payload),
                            memoryview(f.payload),
                        )
                    )
            if self._live:
                self._emit(self._live.poll(self._now, self._global_sn))
            return ParseBatch(
                tuple(self._records), self.decoder.stats.frames_decoded - before
            )
        except BaseException:
            self.close()
            raise
        finally:
            self._records = []

    def poll(self) -> ParseBatch:
        self._require_open()
        self._records = []
        self._now = self._clock()
        try:
            if self._live:
                self._emit(self._live.poll(self._now, self._global_sn))
            result = ParseBatch(tuple(self._records))
            return result
        except BaseException:
            self.close()
            raise
        finally:
            self._records = []

    def snapshot(self) -> SessionSnapshot:
        return SessionSnapshot(
            "finished" if self._result else "closed" if self._closed else "running",
            self.decoder.stats,
            self._result.integrity if self._result else None,
            len(self._live.frames) if self._live else 0,
            self._live.bytes if self._live else 0,
            self._firmware.snapshot() if self._firmware else None,
        )

    def finish(self) -> SessionResult:
        if self._result is not None:
            return self._result
        self._require_open()
        try:
            scan = self.decoder.finish()
            integrity = (
                self._checker.finish(scan) if self._checker is not None else None
            )
            self._records = []
            self._drain()
            if self._content:
                self._records.extend(self._content.finish())
            self._result = SessionResult(
                scan,
                integrity,
                tuple(self._records),
                self._firmware.snapshot() if self._firmware else None,
            )
            return self._result
        finally:
            self.close()

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._checker is not None:
            self._checker.close()
        if self._live:
            self._live.reset()
        if self._content:
            self._content.close()
        self._records = []
