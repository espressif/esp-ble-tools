"""Raw HOST text export; compressed Host uses compressed.decompress."""

from pathlib import Path


def write_host_text(frames, path: Path, *, context=None):
    output = None
    try:
        for item in frames:
            frame = item[0] if isinstance(item, tuple) else item
            if len(frame.payload_view) <= 4:
                continue
            text = bytes(frame.payload_view[4:]).decode("utf-8", "replace")
            if output is None:
                if context is not None:
                    context.add_output_file(path)
                if context is not None and context.dry_run:
                    output = False
                else:
                    output = path.open("w", encoding="utf-8", newline="")
            if output:
                output.write(text)
    finally:
        if output:
            output.close()
