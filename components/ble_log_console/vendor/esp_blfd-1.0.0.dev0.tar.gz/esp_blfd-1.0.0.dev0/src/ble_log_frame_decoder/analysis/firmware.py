"""Bounded firmware counter accounting; no capture-quality policy or EOF verdict."""

from dataclasses import dataclass, field
from typing import NamedTuple

from ble_log_frame_decoder import FrameView
from ble_log_frame_decoder.internal import (
    FLUSH,
    INIT,
    InternalLogEnhancedStat,
    InternalLogInfo,
    parse_final_stat,
    parse_snapshot,
)


class FirmwareCounters(NamedTuple):
    written_frame_cnt: int = 0
    lost_frame_cnt: int = 0
    written_bytes_cnt: int = 0
    lost_bytes_cnt: int | None = 0


def _add(a: FirmwareCounters, b: FirmwareCounters) -> FirmwareCounters:
    return FirmwareCounters(
        a.written_frame_cnt + b.written_frame_cnt,
        a.lost_frame_cnt + b.lost_frame_cnt,
        a.written_bytes_cnt + b.written_bytes_cnt,
        None
        if a.lost_bytes_cnt is None or b.lost_bytes_cnt is None
        else a.lost_bytes_cnt + b.lost_bytes_cnt,
    )


def _delta(current: FirmwareCounters, previous: FirmwareCounters) -> FirmwareCounters:
    return FirmwareCounters(
        current.written_frame_cnt - previous.written_frame_cnt,
        current.lost_frame_cnt - previous.lost_frame_cnt,
        current.written_bytes_cnt - previous.written_bytes_cnt,
        None
        if current.lost_bytes_cnt is None or previous.lost_bytes_cnt is None
        else current.lost_bytes_cnt - previous.lost_bytes_cnt,
    )


@dataclass(frozen=True, slots=True)
class FirmwareSourceStats:
    source: int
    latest: FirmwareCounters | None
    observed: FirmwareCounters
    kind: str | None
    timestamp: int | None
    partial: bool


@dataclass(frozen=True, slots=True)
class FirmwareSnapshot:
    sources: tuple[FirmwareSourceStats, ...] = ()
    epoch: int = 0
    counter_resets: int = 0
    ignored_reports: int = 0
    invalid_reports: int = 0


@dataclass(slots=True)
class _Source:
    latest: FirmwareCounters | None = None
    previous: FirmwareCounters | None = None
    committed: FirmwareCounters = field(default_factory=FirmwareCounters)
    pending: FirmwareCounters = field(default_factory=FirmwareCounters)
    kind: str | None = None
    timestamp: int | None = None
    partial: bool = False
    discontinuous: bool = False


def _older(timestamp: int, previous: int) -> bool:
    return (timestamp - previous) % (1 << 32) >= (1 << 31)


class FirmwareStats:
    """One session's arrival-order samples. Never retains borrowed frame views."""

    def __init__(self) -> None:
        self._sources: dict[int, _Source] = {}
        self._epoch = 0
        self._zero_baseline = False
        self._segment_known = False
        self._init: tuple[int, bytes] | None = None
        self._final: bytes | None = None
        self._anchor: tuple[int, int, bytes] | None = None
        self._timestamp: int | None = None
        self._flush: tuple[int, bytes] | None = None
        self._resets = 0
        self._ignored = 0
        self._invalid = 0

    def _start(self, identity: tuple[int, bytes], timestamp: int) -> bool:
        if identity == self._init:
            self._ignored += 1
            return False
        self._init = identity
        self._epoch += 1
        self._zero_baseline = self._segment_known = True
        self._final = self._anchor = self._flush = None
        self._timestamp = timestamp
        for state in self._sources.values():
            state.committed = _add(state.committed, state.pending)
            state.pending = FirmwareCounters()
            state.latest = state.previous = None
            state.kind = state.timestamp = None
            state.discontinuous = False
        return True

    def _sample(
        self,
        source: int,
        counters: FirmwareCounters,
        timestamp: int,
        kind: str,
        *,
        initial: bool = False,
    ) -> None:
        if self._timestamp is not None and _older(timestamp, self._timestamp):
            self._ignored += 1
            return
        state = self._sources.setdefault(source, _Source())
        previous = state.previous
        if previous is None:
            if self._zero_baseline and not initial:
                previous = FirmwareCounters()
            else:
                previous = counters
                state.partial |= not initial or any(
                    v for v in counters if v is not None
                )
        delta = _delta(counters, previous)
        if any(value < 0 for value in delta if value is not None):
            if timestamp == state.timestamp:
                self._ignored += 1
                return
            # A decrease can be reset, wrap, or torn sampling; never invent a wrap.
            self._resets += 1
            state.partial = state.discontinuous = True
        else:
            state.pending = _add(state.pending, delta)
        state.latest = state.previous = counters
        state.timestamp, state.kind = timestamp, kind
        self._timestamp = timestamp

    def _rebaseline(self) -> None:
        self._zero_baseline = False
        for state in self._sources.values():
            state.previous = None

    def feed(self, frame: FrameView) -> None:
        if frame.source_code != 0 or frame.payload_size < 5:
            return
        payload = frame.payload_view
        subtype = payload[4]
        try:
            if subtype == 0:
                info = InternalLogInfo.from_payload(payload)
                if info.version:
                    self._start((frame.raw_sn, bytes(payload)), info.log_os_ts)
            elif subtype == 2:
                report = InternalLogEnhancedStat.from_payload(payload)
                values = report.enhanced_stat
                source = int(values.log_source)
                if not 0 <= source <= 8:
                    raise ValueError("invalid ENH_STAT source")
                self._sample(
                    source,
                    FirmwareCounters(
                        values.written_frame_cnt,
                        values.lost_frame_cnt,
                        values.written_bytes_cnt,
                        values.lost_bytes_cnt,
                    ),
                    report.log_os_ts,
                    "enh_stat",
                )
            elif subtype == 4:
                timestamp = InternalLogInfo.from_payload(payload).log_os_ts
                identity = frame.raw_sn, bytes(payload)
                if identity == self._flush or self._is_old(timestamp):
                    self._ignored += 1
                else:
                    self._flush = identity
                    self._timestamp = timestamp
                    self._rebaseline()
            elif subtype == 6:
                self._finish_segment(payload)
            elif subtype == 8:
                self._snapshot(frame)
        except ValueError:
            self._invalid += 1

    def _is_old(self, timestamp: int) -> bool:
        return self._timestamp is not None and _older(timestamp, self._timestamp)

    def _finish_segment(self, payload: memoryview) -> None:
        report = parse_final_stat(payload)
        identity = bytes(payload)
        if identity == self._final or self._is_old(report.timestamp):
            self._ignored += 1
            return
        for source, values in report.stats.items():
            state = self._sources.setdefault(source, _Source())
            counters = FirmwareCounters(**values)
            if any(
                value < 0
                for value in _delta(counters, state.pending)
                if value is not None
            ):
                state.discontinuous = True
                self._resets += 1
            known = self._segment_known and not state.discontinuous
            # Terminal totals replace this segment's ENH deltas, never add both.
            state.committed = _add(
                state.committed, counters if known else state.pending
            )
            state.partial |= not known
            state.pending = FirmwareCounters()
            state.latest, state.previous = counters, None
            state.kind, state.timestamp = "final_stat", report.timestamp
            state.discontinuous = False
        self._final = identity
        self._timestamp = report.timestamp
        self._zero_baseline = self._segment_known = True

    def _snapshot(self, frame: FrameView) -> None:
        payload = frame.payload_view
        report = parse_snapshot(payload)
        identity = bytes(payload)
        initial = bool(report.reason_flags & INIT)
        if initial:
            if not self._start((frame.raw_sn, identity), report.timestamp):
                return
        elif self._is_old(report.timestamp):
            self._ignored += 1
            return
        elif self._anchor is not None:
            sn, anchor, previous = self._anchor
            distance = (report.anchor_count - anchor) % (1 << 24)
            sn_distance = (frame.raw_sn - sn) % (1 << 24)
            if (
                identity == previous
                or not 0 < distance < (1 << 23)
                or not 0 < sn_distance < (1 << 23)
            ):
                self._ignored += 1
                return
            if distance != 1:
                # Missing anchors may hide FLUSH, even with increasing counters.
                self._rebaseline()
        for source, values in enumerate(report.stats, 1):
            self._sample(
                source,
                FirmwareCounters(
                    values.written_frame_cnt,
                    values.lost_frame_cnt,
                    values.written_bytes_cnt,
                    None,
                ),
                report.timestamp,
                "snapshot",
                initial=initial,
            )
        self._anchor = frame.raw_sn, report.anchor_count, identity
        if report.reason_flags & FLUSH:
            # FLUSH is sampled before reset completion; the next sample is a baseline.
            self._rebaseline()

    def snapshot(self) -> FirmwareSnapshot:
        return FirmwareSnapshot(
            tuple(
                FirmwareSourceStats(
                    source,
                    state.latest,
                    _add(state.committed, state.pending),
                    state.kind,
                    state.timestamp,
                    state.partial,
                )
                for source, state in sorted(self._sources.items())
            ),
            self._epoch,
            self._resets,
            self._ignored,
            self._invalid,
        )
