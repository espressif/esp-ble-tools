"""Anchor-constrained ordering for the final v8 Global-SN protocol."""

from __future__ import annotations

import bisect
import heapq
import os
from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Final

import numpy as np

from ble_log_frame_decoder.analysis.core.source_codes import BleLogSource
from ble_log_frame_decoder.analysis.ordering.diagnostics import (
    AnchorObservation,
    BoundaryObservation,
    InstanceDetectionResult,
    InstanceSegment,
    SourceDiagnostic,
)
from ble_log_frame_decoder.analysis.ordering.frame_metadata import (
    FrameMetadataFlag,
    FrameMetadataStore,
)
from ble_log_frame_decoder.analysis.ordering.frame_model import (
    SOURCE_CLOCK_MAP,
    ClockDomain,
    DetectorConfig,
)
from ble_log_frame_decoder.analysis.ordering.metadata_ordering import (
    MetadataInstanceOrdering,
    MetadataOrderingResult,
)
from ble_log_frame_decoder.analysis.ordering.storage import (
    close_memmap,
    create_memmap,
    iter_merged_records,
    sort_record_runs,
)
from ble_log_frame_decoder.checking.protocol import (
    INIT,
    PERIODIC,
    TS_VALID,
    parse_snapshot,
)

_SN_PERIOD: Final[int] = 1 << 24
_CLOCK_PERIOD: Final[int] = 1 << 32
_UINT32_MAX: Final[int] = (1 << 32) - 1
_UINT64_MAX: Final[int] = (1 << 64) - 1
_PENDING_PERIODS: Final[int] = 3
_CHUNK_ROWS: Final[int] = 1_000_000

_HIGH: Final[int] = 0
_MEDIUM: Final[int] = 1
_ALIGNED: Final[int] = 2
_LOW: Final[int] = 3

_ORDER_DTYPE = np.dtype(
    [
        ("instance", "<u4"),
        ("position", "<u8"),
        ("kind", "u1"),
        ("secondary", "<u8"),
        ("row", "<u4"),
    ],
    align=False,
)


@dataclass(slots=True)
class _SnapshotRecord:
    row: int
    raw_sn: int
    anchor_count: int
    reason_flags: int
    esp_ts: int
    lc_ts: int
    payload: bytes
    sn: int = 0
    esp: int = 0
    weak_after: bool = False


def _read_snapshots(
    store: FrameMetadataStore, capture_path: Path
) -> list[_SnapshotRecord]:
    source_sn = store.mmap_column("source_sn")
    offsets = store.mmap_column("payload_offset")
    sizes = store.mmap_column("payload_size")
    flags = store.mmap_column("flags")
    records: list[_SnapshotRecord] = []
    with capture_path.open("rb") as capture:
        for row_value in np.flatnonzero(flags & int(FrameMetadataFlag.SNAPSHOT)):
            row = int(row_value)
            payload = os.pread(capture.fileno(), int(sizes[row]), int(offsets[row]))
            snapshot = parse_snapshot(payload)
            records.append(
                _SnapshotRecord(
                    row=row,
                    raw_sn=int(source_sn[row]) >> 8,
                    anchor_count=snapshot.anchor_count,
                    reason_flags=snapshot.reason_flags,
                    esp_ts=snapshot.esp_ts,
                    lc_ts=snapshot.lc_ts,
                    payload=payload,
                )
            )
    return records


def _detect_lifecycles(
    store: FrameMetadataStore,
    workspace: Path,
    snapshots: list[_SnapshotRecord],
    cfg: DetectorConfig,
) -> tuple[InstanceDetectionResult, np.ndarray]:
    resets: list[int] = []
    init_anchors: list[AnchorObservation] = []
    observations: list[BoundaryObservation] = []
    warnings: list[str] = []
    previous_init: tuple[int, bytes] | None = None
    previous: _SnapshotRecord | None = None
    seen: set[tuple[int, bytes]] = set()

    def forward(left: int, right: int, period: int) -> bool:
        return 0 < (right - left) % period < period // 2

    following_records: list[_SnapshotRecord | None] = [None] * len(snapshots)
    next_init_rows = [store.row_count] * len(snapshots)
    for i in range(len(snapshots) - 2, -1, -1):
        current, following = snapshots[i], snapshots[i + 1]
        following_records[i] = (
            following_records[i + 1]
            if (current.raw_sn, current.payload)
            == (following.raw_sn, following.payload)
            else following
        )
        next_init_rows[i] = (
            following.row if following.reason_flags & INIT else next_init_rows[i + 1]
        )

    for index, snapshot in enumerate(snapshots):
        identity = snapshot.raw_sn, snapshot.payload
        following = following_records[index]
        reason = None
        if snapshot.reason_flags & INIT:
            if identity == previous_init:
                # An identical INIT can be replay or another boot with the same samples.
                continuous = previous is not None and (
                    (
                        previous.row + 1 == snapshot.row
                        and identity == (previous.raw_sn, previous.payload)
                    )
                    or (
                        following is not None
                        and not previous.reason_flags & INIT
                        and not following.reason_flags & INIT
                        and forward(
                            previous.anchor_count, following.anchor_count, _SN_PERIOD
                        )
                        and forward(previous.raw_sn, following.raw_sn, _SN_PERIOD)
                        and forward(previous.esp_ts, following.esp_ts, _CLOCK_PERIOD)
                    )
                )
                if continuous:
                    continue
                confirmed = (
                    previous is not None
                    and following is not None
                    and not following.reason_flags & INIT
                    and following.anchor_count <= previous.anchor_count
                    and following.raw_sn <= previous.raw_sn
                )
                reason = "init_anchor" if confirmed else "ambiguous_init"
            else:
                reason = "init_anchor"
            previous_init = identity
            init_anchors.append(AnchorObservation(snapshot.row, "init_done"))
        elif identity in seen:
            # Replayed snapshots must not change the progression used to assess INIT.
            continue
        if reason is not None:
            seen.clear()
            if snapshot.row:
                resets.append(snapshot.row)
                observations.append(
                    BoundaryObservation(
                        snapshot.row,
                        snapshot.row,
                        reason,
                        snapshot.row,
                    )
                )
            if reason == "ambiguous_init":
                end = next_init_rows[index]
                observations.append(
                    BoundaryObservation(snapshot.row, end, "uncertain_boundary", None)
                )
                warnings.append(
                    f"Identical INIT at transport {snapshot.row}: restart versus replay is ambiguous."
                )
        seen.add(identity)
        previous = snapshot

    total = store.row_count
    assignment = create_memmap(workspace / "instance_by_row.u32", "<u4", total, fill=0)
    boundaries = np.asarray(resets, dtype="<u4")
    for start in range(0, total, _CHUNK_ROWS):
        end = min(start + _CHUNK_ROWS, total)
        assignment[start:end] = np.searchsorted(
            boundaries, np.arange(start, end, dtype="<u4"), side="right"
        )

    starts = [0, *resets]
    ends = [*resets, total]
    segments = [
        InstanceSegment(
            index=i, start_transport=start, end_transport=end, frame_count=end - start
        )
        for i, (start, end) in enumerate(zip(starts, ends, strict=True))
    ]
    detection = InstanceDetectionResult(
        total_frames=total,
        instances=segments,
        boundaries=resets,
        anchors=init_anchors,
        boundary_observations=observations,
        boundary_reason_counts=dict(
            Counter(o.reason for o in observations if o.boundary is not None)
        ),
        warnings=warnings,
        parameters=cfg,
    )
    return detection, assignment


def _unique_anchors(
    snapshots: list[_SnapshotRecord], assignment: np.ndarray
) -> tuple[dict[int, list[_SnapshotRecord]], dict[int, int]]:
    anchors: dict[int, list[_SnapshotRecord]] = defaultdict(list)
    duplicate_of: dict[int, int] = {}
    seen: dict[int, dict[tuple[int, bytes], int]] = defaultdict(dict)
    for snapshot in snapshots:
        instance = int(assignment[snapshot.row])
        identity = snapshot.raw_sn, snapshot.payload
        original = seen[instance].get(identity)
        if original is not None:
            duplicate_of[snapshot.row] = original
            continue
        seen[instance][identity] = snapshot.row
        anchors[instance].append(snapshot)
    return anchors, duplicate_of


def _unwrap_anchors(anchors: list[_SnapshotRecord], diagnostics: Counter[str]) -> None:
    if not anchors:
        return
    first = anchors[0]
    # Keep one ring of headroom for a partial capture before its first anchor;
    # the instance is shifted back to its smallest non-negative representation.
    first.sn = first.raw_sn + _SN_PERIOD
    first.esp = first.esp_ts
    previous_count = first.anchor_count
    previous = first
    for anchor in anchors[1:]:
        count_delta = (anchor.anchor_count - previous_count) % _SN_PERIOD
        sn_delta = (anchor.raw_sn - previous.raw_sn) % _SN_PERIOD
        if count_delta == 0:
            diagnostics["anchor_conflicts"] += 1
            count_delta = 1
            previous.weak_after = True
        if sn_delta == 0:
            diagnostics["ambiguous_intervals"] += 1
            sn_delta = _SN_PERIOD
            previous.weak_after = True
        diagnostics["anchor_attempt_gaps"] += count_delta - 1
        anchor.sn = previous.sn + sn_delta
        anchor.esp = previous.esp + (anchor.esp_ts - previous.esp_ts) % _CLOCK_PERIOD
        previous_count = anchor.anchor_count
        previous = anchor


def _lift_near(raw: int, target: int, period: int) -> int:
    return raw + ((target - raw + period // 2) // period) * period


def _window_sn(raw: int, lower: int, upper: int) -> int | None:
    """The only lift of raw into the inclusive receive window, if it exists."""
    value = raw + ((lower - raw + _SN_PERIOD - 1) // _SN_PERIOD) * _SN_PERIOD
    if value > upper or value + _SN_PERIOD <= upper:
        return None
    return value


def _circular_time_order(rows: np.ndarray, raw_clock: np.ndarray) -> np.ndarray:
    if len(rows) < 2:
        return rows
    order = np.lexsort((rows, raw_clock[rows]))
    ordered = rows[order]
    values = raw_clock[ordered].astype("<u8", copy=False)
    gaps = values[1:] - values[:-1]
    if len(gaps) and int(gaps.max()) > _CLOCK_PERIOD // 2:
        cut = int(gaps.argmax()) + 1
        ordered = np.concatenate((ordered[cut:], ordered[:cut]))
    return ordered


def _fallback_time_order(
    rows: np.ndarray,
    source_sn: np.ndarray,
    raw_clock: np.ndarray,
    flags: np.ndarray,
) -> list[int]:
    streams: list[np.ndarray] = []
    sources = source_sn[rows] & 0xFF
    present = flags[rows] & int(FrameMetadataFlag.CLOCK_PRESENT) != 0
    for domain in (ClockDomain.FREERTOS, ClockDomain.LC):
        selected = np.asarray(
            [
                int(row)
                for row, source, has_clock in zip(rows, sources, present, strict=True)
                if has_clock and SOURCE_CLOCK_MAP[BleLogSource(int(source))] is domain
            ],
            dtype="<u4",
        )
        if len(selected):
            streams.append(_circular_time_order(selected, raw_clock))
    missing = rows[~present]
    if len(missing):
        streams.append(missing)

    heap: list[tuple[int, int, int]] = []
    for stream, values in enumerate(streams):
        heapq.heappush(heap, (int(values[0]), stream, 0))
    result: list[int] = []
    while heap:
        _, stream, index = heapq.heappop(heap)
        values = streams[stream]
        result.append(int(values[index]))
        index += 1
        if index < len(values):
            heapq.heappush(heap, (int(values[index]), stream, index))
    return result


def _unwrap_binding_rows(
    rows: list[int], source_sn: np.ndarray, unwrapped_sn: np.ndarray
) -> None:
    reference: int | None = None
    for row in rows:
        raw = int(source_sn[row]) >> 8
        value = (
            raw + _SN_PERIOD
            if reference is None
            else _lift_near(raw, reference, _SN_PERIOD)
        )
        unwrapped_sn[row] = value
        reference = value if reference is None else max(reference, value)


def _sort_and_deduplicate(
    store: FrameMetadataStore,
    capture_path: Path,
    workspace: Path,
    records: np.ndarray,
    assignment: np.ndarray,
    unwrapped_sn: np.ndarray,
    flags: np.ndarray,
    diagnostics: list[Counter[str]],
) -> tuple[np.ndarray, int]:
    source_sn = store.mmap_column("source_sn")
    sizes = store.mmap_column("payload_size")
    checksums = store.mmap_column("payload_crc32")
    order = ("instance", "position", "kind", "secondary", "row")
    runs = sort_record_runs(records, order)
    iterator = (
        iter(records) if len(runs) <= 1 else iter_merged_records(records, runs, order)
    )
    offsets = store.mmap_column("payload_offset")
    ordered = create_memmap(workspace / "order.u32", "<u4", store.row_count)
    deduplicated = 0
    current: tuple[int, int, int] | None = None
    representatives: dict[tuple[int, int, int], list[int]] = {}
    output = 0
    with capture_path.open("rb") as capture:
        for record in iterator:
            row = int(record["row"])
            if int(unwrapped_sn[row]) != _UINT32_MAX:
                stream = int(
                    bool(int(flags[row]) & int(FrameMetadataFlag.TASK_BINDING))
                )
                key = int(assignment[row]), stream, int(unwrapped_sn[row])
                if key != current:
                    current = key
                    representatives = {}
                identity = (
                    int(source_sn[row]) & 0xFF,
                    int(sizes[row]),
                    int(checksums[row]),
                )
                candidates = representatives.get(identity, [])
                if candidates:
                    payload = os.pread(
                        capture.fileno(), int(sizes[row]), int(offsets[row])
                    )
                    if any(
                        payload
                        == os.pread(
                            capture.fileno(), int(sizes[old]), int(offsets[old])
                        )
                        for old in candidates
                    ):
                        diagnostics[key[0]]["duplicate_frames"] += 1
                        deduplicated += 1
                        continue
                if representatives:
                    diagnostics[key[0]]["conflicts"] += 1
                representatives.setdefault(identity, []).append(row)
            ordered[output] = row
            output += 1
    close = getattr(iterator, "close", None)
    if close is not None:
        close()
    close_memmap(records)
    (workspace / "snapshot_order_records.bin").unlink()
    return ordered[:output], deduplicated


def _clock_diagnostics(
    ordered_rows: np.ndarray,
    assignment: np.ndarray,
    source_sn: np.ndarray,
    raw_clock: np.ndarray,
    flags: np.ndarray,
    instance_count: int,
    uncertain: np.ndarray,
    snapshots: list[_SnapshotRecord],
) -> tuple[list[dict[str, str]], dict[int, int], dict[int, int]]:
    previous: dict[tuple[int, ClockDomain], int] = {}
    wraps: Counter[tuple[int, ClockDomain]] = Counter()
    before_wrap_min: dict[tuple[int, ClockDomain], int] = {}
    low_max: dict[tuple[int, ClockDomain], int] = {}
    snapshot_lc = {s.row: s.lc_ts for s in snapshots if s.reason_flags & TS_VALID}
    for row_value in ordered_rows:
        row = int(row_value)
        if uncertain[row] or not int(flags[row]) & int(FrameMetadataFlag.CLOCK_PRESENT):
            continue
        source = BleLogSource(int(source_sn[row]) & 0xFF)
        if int(flags[row]) & int(FrameMetadataFlag.TASK_BINDING):
            continue
        samples = [(SOURCE_CLOCK_MAP[source], int(raw_clock[row]))]
        if row in snapshot_lc:
            samples.append((ClockDomain.LC, snapshot_lc[row]))
        for domain, raw in samples:
            key = int(assignment[row]), domain
            old = previous.get(key)
            if old is not None and old - raw > _CLOCK_PERIOD // 2:
                wraps[key] += 1
            if wraps[key]:
                low_max[key] = max(low_max.get(key, 0), raw)
            else:
                before_wrap_min[key] = min(before_wrap_min.get(key, raw), raw)
            previous[key] = raw

    result: list[dict[str, str]] = []
    splits: dict[int, int] = {}
    lc_splits: dict[int, int] = {}
    for instance in range(instance_count):
        item: dict[str, str] = {}
        for domain, name in ((ClockDomain.FREERTOS, "esp"), (ClockDomain.LC, "lc")):
            key = instance, domain
            count = wraps[key]
            # A raw-value threshold cannot distinguish overlapping clock cycles.
            ambiguous = count > 1 or (
                count == 1 and low_max[key] >= before_wrap_min[key]
            )
            item[name] = (
                "ambiguous"
                if ambiguous
                else "unwrap_proven"
                if count
                else "single_cycle_default"
            )
            if item[name] == "unwrap_proven":
                target = splits if domain is ClockDomain.FREERTOS else lc_splits
                target[instance] = low_max[key]
        result.append(item)
    return result, splits, lc_splits


def order_snapshot_metadata(
    store: FrameMetadataStore,
    capture_path: Path,
    workspace: Path,
    *,
    cfg: DetectorConfig,
    retain_unwrapped_sn: bool,
) -> MetadataOrderingResult:
    """Order one final-v8 capture without the older per-source DAG."""
    source_sn = store.mmap_column("source_sn")
    raw_clock = store.mmap_column("raw_clock")
    flags = store.mmap_column("flags")
    snapshots = _read_snapshots(store, capture_path)
    detection, assignment = _detect_lifecycles(store, workspace, snapshots, cfg)
    anchors_by_instance, duplicate_anchor_of = _unique_anchors(snapshots, assignment)

    total = store.row_count
    confidence = create_memmap(workspace / "confidence.u8", "u1", total, fill=_LOW)
    unwrapped = create_memmap(
        workspace / "unwrapped_sn.u32", "<u4", total, fill=_UINT32_MAX
    )
    records = create_memmap(
        workspace / "snapshot_order_records.bin", _ORDER_DTYPE, total
    )
    records["instance"] = assignment
    records["position"] = _UINT64_MAX
    records["kind"] = 2  # 0: unresolved receive position; 1: binding; 2: Global SN.
    for start in range(0, total, _CHUNK_ROWS):
        end = min(start + _CHUNK_ROWS, total)
        records["secondary"][start:end] = records["row"][start:end] = np.arange(
            start, end, dtype="<u4"
        )
    uncertain = np.zeros(total, dtype=bool)
    for observation in detection.boundary_observations:
        if observation.boundary is None:
            uncertain[observation.start_transport : observation.end_transport] = True
    counters = [Counter() for _ in detection.instances]
    anchor_rows: dict[int, _SnapshotRecord] = {}

    for instance, anchors in anchors_by_instance.items():
        _unwrap_anchors(anchors, counters[instance])
        anchor_rows.update((anchor.row, anchor) for anchor in anchors)
        counters[instance]["anchors"] = len(anchors)
        counters[instance]["ts_sync_anchors"] = sum(
            bool(anchor.reason_flags & TS_VALID and anchor.lc_ts) for anchor in anchors
        )
    for row, original in duplicate_anchor_of.items():
        anchor_rows[row] = anchor_rows[original]

    for instance, segment in enumerate(detection.instances):
        rows = records["row"][segment.start_transport : segment.end_transport]
        anchors = anchors_by_instance.get(instance, [])
        binding_rows = [
            int(row)
            for row in rows
            if int(flags[row]) & int(FrameMetadataFlag.TASK_BINDING)
        ]
        _unwrap_binding_rows(binding_rows, source_sn, unwrapped)

        if not anchors:
            fallback = _fallback_time_order(rows, source_sn, raw_clock, flags)
            for rank, row in enumerate(fallback):
                records[row]["position"] = rank
            counters[instance]["unanchored_frames"] = len(rows)
            counters[instance]["ambiguous_frames"] = len(rows)
            detection.warnings.append(
                f"Instance {instance} has no snapshot anchor; ordered clocks within each domain and used transport order across domains."
            )
            continue

        anchor_sns = [anchor.sn for anchor in anchors]
        anchor_esps = [anchor.esp for anchor in anchors]
        recent: deque[_SnapshotRecord] = deque(maxlen=_PENDING_PERIODS + 1)
        next_anchor = 0
        for row_value in rows:
            row = int(row_value)
            while next_anchor < len(anchors) and anchors[next_anchor].row < row:
                anchor = anchors[next_anchor]
                if anchor.reason_flags & PERIODIC:
                    recent.append(anchor)
                next_anchor += 1

            # Match checker's three-period deadline. Duplicate anchors and FLUSH
            # never age this window. Capture head/tail use a nearest half-ring.
            lower = (
                recent[0].sn + 1
                if len(recent) == recent.maxlen
                else anchors[0].sn
                if anchors[0].reason_flags & INIT
                else anchors[0].sn - _SN_PERIOD // 2 + 1
            )
            # One snapshot can already own an SN while its dedicated transport
            # trails this core frame. The *second* subsequent snapshot is the
            # upper bound: it cannot be allocated until that transport recycles.
            upper = (
                anchors[next_anchor + 1].sn
                if next_anchor + 1 < len(anchors)
                else anchors[-1].sn + _SN_PERIOD // 2 - 1
            )
            # Unresolved frames keep their receive order before the next anchor,
            # and never acquire a guessed SN that could cause false deduplication.
            fallback = (
                anchors[next_anchor].sn if next_anchor < len(anchors) else _UINT64_MAX
            )
            if uncertain[row]:
                unwrapped[row] = _UINT32_MAX
                records[row]["position"] = fallback
                records[row]["kind"] = 0
                confidence[row] = _LOW
                counters[instance]["ambiguous_frames"] += 1
                continue
            if row in anchor_rows:
                unwrapped[row] = anchor_rows[row].sn
                records[row]["position"] = anchor_rows[row].sn
                confidence[row] = _HIGH
                continue
            if int(flags[row]) & int(FrameMetadataFlag.TASK_BINDING):
                raw = int(raw_clock[row])
                reference = anchors[max(next_anchor - 1, 0)].esp
                expanded = _lift_near(raw, reference, _CLOCK_PERIOD)
                target = bisect.bisect_left(anchor_esps, expanded)
                if target < len(anchors):
                    records[row]["position"] = anchors[target].sn
                records[row]["kind"] = 1
                records[row]["secondary"] = int(unwrapped[row])
                confidence[row] = _ALIGNED
                continue

            absolute = _window_sn(int(source_sn[row]) >> 8, lower, upper)
            interval = (
                bisect.bisect_right(anchor_sns, absolute) - 1
                if absolute is not None
                else -1
            )
            weak = interval >= 0 and anchors[min(interval, len(anchors) - 1)].weak_after
            if absolute is None or not 0 <= absolute < _UINT32_MAX or weak:
                counters[instance]["ambiguous_frames"] += 1
                records[row]["position"] = fallback
                records[row]["kind"] = 0
                continue
            unwrapped[row] = absolute
            records[row]["position"] = absolute
            covered = len(anchors) > 1 and anchors[0].sn <= absolute <= anchors[-1].sn
            confidence[row] = _HIGH if covered else _MEDIUM
            choice = "double_anchored" if covered else "unanchored"
            counters[instance][f"{choice}_frames"] += 1

        minimum_sn = _UINT32_MAX
        for start in range(0, len(rows), _CHUNK_ROWS):
            chunk = rows[start : start + _CHUNK_ROWS]
            core_mask = (flags[chunk] & int(FrameMetadataFlag.TASK_BINDING) == 0) & (
                unwrapped[chunk] != _UINT32_MAX
            )
            assigned_core = chunk[core_mask]
            if len(assigned_core):
                minimum_sn = min(minimum_sn, int(unwrapped[assigned_core].min()))
        if _SN_PERIOD <= minimum_sn < _UINT32_MAX:
            for start in range(0, len(rows), _CHUNK_ROWS):
                chunk = rows[start : start + _CHUNK_ROWS]
                core_mask = (
                    flags[chunk] & int(FrameMetadataFlag.TASK_BINDING) == 0
                ) & (unwrapped[chunk] != _UINT32_MAX)
                unwrapped[chunk[core_mask]] -= _SN_PERIOD
                positioned = chunk[records["position"][chunk] != _UINT64_MAX]
                records["position"][positioned] -= _SN_PERIOD

    ordered_rows, deduplicated = _sort_and_deduplicate(
        store,
        capture_path,
        workspace,
        records,
        assignment,
        unwrapped,
        flags,
        counters,
    )

    clock_status, esp_splits, lc_splits = _clock_diagnostics(
        ordered_rows,
        assignment,
        source_sn,
        raw_clock,
        flags,
        len(detection.instances),
        uncertain,
        snapshots,
    )
    diagnostics: list[dict[str, Any]] = []
    for instance, values in enumerate(counters):
        sn = {
            "mode": "global_anchor",
            "anchors": values["anchors"],
            "anchor_attempt_gaps": values["anchor_attempt_gaps"],
            "double_anchored_frames": values["double_anchored_frames"],
            "unanchored_frames": values["unanchored_frames"],
            "time_resolved_frames": values["time_resolved_frames"],
            "ambiguous_frames": values["ambiguous_frames"],
            "duplicate_frames": values["duplicate_frames"],
            "conflicts": values["conflicts"],
            "anchor_conflicts": values["anchor_conflicts"],
            "ambiguous_intervals": values["ambiguous_intervals"],
        }
        if (
            values["ambiguous_frames"]
            or values["anchor_conflicts"]
            or values["ambiguous_intervals"]
        ):
            detection.warnings.append(
                f"Instance {instance} has ambiguous or out-of-window SNs; unresolved frames retain receive order without an assigned SN."
            )
        if values["conflicts"]:
            detection.warnings.append(
                f"Instance {instance} has {values['conflicts']} SN content conflicts; all distinct frames are retained."
            )
        diagnostics.append(
            {
                "sn": sn,
                "clock": clock_status[instance],
                "clock_inferred_from_sn": [],
                "transport_inverted_hard_edges": 0,
                "tie_decisions": {
                    "time_resolved": values["time_resolved_frames"],
                    "transport": values["ambiguous_frames"],
                },
                "choice_distribution": {
                    key: count
                    for key, count in (
                        ("sn_forced", values["double_anchored_frames"]),
                        ("aligned", values["time_resolved_frames"]),
                        ("transport", values["ambiguous_frames"]),
                    )
                    if count
                },
                "ts_sync_anchors": values["ts_sync_anchors"],
                "ts_sync_rejected": 0,
            }
        )

    detection.source_diagnostics = [
        SourceDiagnostic(instance=i, source="GLOBAL", status="anchor")
        for i in range(len(detection.instances))
    ]
    if not retain_unwrapped_sn:
        close_memmap(unwrapped)
        (workspace / "unwrapped_sn.u32").unlink()
        unwrapped = np.empty(0, dtype="<u4")

    return MetadataOrderingResult(
        store=store,
        detection=detection,
        ordered_rows=ordered_rows,
        instance_by_row=assignment,
        confidence_by_row=confidence,
        unwrapped_sn_by_row=unwrapped,
        instances=[MetadataInstanceOrdering(diagnostics=item) for item in diagnostics],
        deduplicated_rows=deduplicated,
        uses_global_sn=True,
        esp_time_instances=set(range(len(detection.instances))),
        esp_clock_splits=esp_splits,
        lc_clock_splits=lc_splits,
    )
