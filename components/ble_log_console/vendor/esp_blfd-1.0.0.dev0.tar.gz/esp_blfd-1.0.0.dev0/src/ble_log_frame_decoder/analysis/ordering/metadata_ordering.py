"""Disk-backed best-effort ordering over a sealed FrameMetadataStore."""

from __future__ import annotations

import bisect
import mmap
import os
from array import array
from collections import Counter, defaultdict
from collections.abc import Generator, Iterator
from dataclasses import dataclass, field
from enum import StrEnum
from itertools import chain, groupby
from pathlib import Path
from typing import Any, Final, Self

import numpy as np

from ble_log_frame_decoder import FrameView
from ble_log_frame_decoder.analysis.core.protocol import CaptureProtocol
from ble_log_frame_decoder.analysis.core.source_codes import BleLogSource
from ble_log_frame_decoder.analysis.ordering._linearize_native import linearize_instance
from ble_log_frame_decoder.analysis.ordering.diagnostics import (
    AnchorObservation,
    BoundaryObservation,
    InstanceDetectionResult,
    InstanceSegment,
    SourceDiagnostic,
)
from ble_log_frame_decoder.analysis.ordering.frame_metadata import (
    FrameMetadataFlag,
    FrameMetadataStore,
)
from ble_log_frame_decoder.analysis.ordering.frame_model import (
    SOURCE_CLOCK_MAP,
    AnchorInfo,
    AnchorMap,
    ClockDomain,
    DetectorConfig,
    LcTimerUnit,
    build_anchor_map,
    normalize_raw_clock,
)
from ble_log_frame_decoder.analysis.ordering.storage import (
    close_memmap as _close_memmap,
    create_memmap as _create_memmap,
    iter_merged_records as _iter_merged_records,
    sort_record_runs as _sort_record_runs,
)

_UINT32_MAX: Final[int] = (1 << 32) - 1
_SN_PERIOD: Final[int] = 1 << 24
_CLOCK_PERIOD: Final[int] = 1 << 32
_SOURCE_BY_VALUE = {source.value: source for source in BleLogSource}
_CLOCK_DOMAIN_BY_SOURCE = np.full(256, 255, dtype="u1")
for _source, _domain in SOURCE_CLOCK_MAP.items():
    _CLOCK_DOMAIN_BY_SOURCE[_source.value] = 0 if _domain is ClockDomain.LC else 1


class _ClockEpochStatus(StrEnum):
    UNWRAP_PROVEN = "unwrap_proven"
    SINGLE_CYCLE_DEFAULT = "single_cycle_default"
    AMBIGUOUS = "ambiguous"
    UNSUPPORTED = "unsupported"
    UNOBSERVABLE = "unobservable"


@dataclass(frozen=True, slots=True)
class _EvidencePoint:
    transport_index: int
    source: BleLogSource
    kind: str
    domain: ClockDomain | None = None
    sn_reset: bool = False
    clock_reset: bool = False
    anchor_kind: str | None = None


@dataclass(slots=True)
class _DetectedInstances:
    result: InstanceDetectionResult
    assignment: np.ndarray


@dataclass(slots=True)
class MetadataInstanceOrdering:
    diagnostics: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class MetadataOrderingResult:
    """Disk-backed ordering result whose row IDs address FrameMetadataStore."""

    store: FrameMetadataStore
    detection: InstanceDetectionResult
    ordered_rows: np.ndarray
    instance_by_row: np.ndarray
    confidence_by_row: np.ndarray
    unwrapped_sn_by_row: np.ndarray
    instances: list[MetadataInstanceOrdering]
    deduplicated_rows: int
    uses_global_sn: bool
    esp_time_instances: set[int] = field(default_factory=set)
    esp_clock_splits: dict[int, int] = field(default_factory=dict)
    lc_clock_splits: dict[int, int] = field(default_factory=dict)

    def close(self) -> None:
        for mapped in (
            self.ordered_rows,
            self.instance_by_row,
            self.confidence_by_row,
            self.unwrapped_sn_by_row,
        ):
            _close_memmap(mapped)


@dataclass(frozen=True, slots=True)
class FrameOrderContext:
    transport_index: int
    instance_index: int
    timestamp_us: int | None = None


class OrderedFrameSource:
    """Reconstruct borrowed FrameViews from an ordering result and capture mmap."""

    def __init__(
        self,
        capture_path: Path,
        result: MetadataOrderingResult,
    ) -> None:
        self.capture_path = capture_path
        self.result = result
        self._file: Any | None = None
        self._mmap: mmap.mmap | None = None
        self._view: memoryview | None = None

    def __enter__(self) -> Self:
        self._file = self.capture_path.open("rb")
        self._mmap = mmap.mmap(
            self._file.fileno(),
            length=0,
            access=mmap.ACCESS_READ,
        )
        self._view = memoryview(self._mmap)
        return self

    def __exit__(self, *exc: object) -> None:
        try:
            if self._view is not None:
                self._view.release()
                self._view = None
            if self._mmap is not None:
                try:
                    self._mmap.close()
                except BufferError:
                    # A retained borrowed view must not mask the consumer's exception.
                    if not exc or exc[0] is None:
                        raise
                else:
                    self._mmap = None
        finally:
            if self._file is not None:
                self._file.close()
                self._file = None

    def iter_views(
        self,
        *,
        sources: set[BleLogSource] | None = None,
        rows: np.ndarray | None = None,
    ) -> Generator[FrameView, None, None]:
        if self._view is None:
            raise RuntimeError("OrderedFrameSource must be entered before use")
        source_sn = self.result.store.mmap_column("source_sn")
        payload_offset = self.result.store.mmap_column("payload_offset")
        payload_size = self.result.store.mmap_column("payload_size")
        selected = {source.value for source in sources} if sources is not None else None
        for row_value in self.result.ordered_rows if rows is None else rows:
            row = int(row_value)
            packed = int(source_sn[row])
            source_code = packed & 0xFF
            if selected is not None and source_code not in selected:
                continue
            offset = int(payload_offset[row])
            size = int(payload_size[row])
            payload_view = self._view[offset : offset + size]
            try:
                yield FrameView(
                    source_code=source_code,
                    raw_sn=packed >> 8,
                    payload_offset=offset,
                    payload_size=size,
                    payload_view=payload_view,
                )
            finally:
                payload_view.release()

    def iter_views_with_context(
        self,
        *,
        sources: set[BleLogSource] | None = None,
        rows: np.ndarray | None = None,
    ) -> Generator[tuple[FrameView, FrameOrderContext], None, None]:
        if self._view is None:
            raise RuntimeError("OrderedFrameSource must be entered before use")
        source_sn = self.result.store.mmap_column("source_sn")
        payload_offset = self.result.store.mmap_column("payload_offset")
        payload_size = self.result.store.mmap_column("payload_size")
        selected = {source.value for source in sources} if sources is not None else None
        for row_value in self.result.ordered_rows if rows is None else rows:
            row = int(row_value)
            packed = int(source_sn[row])
            source_code = packed & 0xFF
            if selected is not None and source_code not in selected:
                continue
            offset = int(payload_offset[row])
            size = int(payload_size[row])
            payload_view = self._view[offset : offset + size]
            try:
                instance = int(self.result.instance_by_row[row])
                timestamp_us = None
                if (
                    instance in self.result.esp_time_instances
                    and source_code not in {2, 3, 4}
                    and size >= 4
                ):
                    timestamp_us = int.from_bytes(payload_view[:4], "little")
                    split = self.result.esp_clock_splits.get(instance)
                    if split is not None and timestamp_us <= split:
                        timestamp_us += _CLOCK_PERIOD
                yield (
                    FrameView(
                        source_code=source_code,
                        raw_sn=packed >> 8,
                        payload_offset=offset,
                        payload_size=size,
                        payload_view=payload_view,
                    ),
                    FrameOrderContext(
                        transport_index=row,
                        instance_index=instance,
                        timestamp_us=timestamp_us,
                    ),
                )
            finally:
                payload_view.release()


def _is_sn_reset(previous: int, current: int, cfg: DetectorConfig) -> bool:
    return current < previous and current <= cfg.max_forward_sn_gap


def _is_clock_reset(
    previous: int | None,
    current: int | None,
    domain: ClockDomain,
    cfg: DetectorConfig,
) -> bool:
    if previous is None or current is None:
        return False
    low = cfg.lc_t_low_us if domain is ClockDomain.LC else cfg.os_t_low_us
    return previous - current > cfg.min_reset_clock_drop_us and current <= low


def _detect_per_source_instances(
    store: FrameMetadataStore,
    workspace: Path,
    *,
    lc_timer_unit: LcTimerUnit,
    cfg: DetectorConfig,
) -> _DetectedInstances:
    """Infer older v2 boundaries from INIT, FLUSH and per-source counters."""
    source_sn = store.mmap_column("source_sn")
    raw_clock = store.mmap_column("raw_clock")
    flags = store.mmap_column("flags")
    total = store.row_count
    assignment = _create_memmap(
        workspace / "instance_by_row.u32",
        "<u4",
        total,
        fill=_UINT32_MAX,
    )
    if not total:
        return _DetectedInstances(
            InstanceDetectionResult(
                total_frames=0,
                instances=[],
                boundaries=[],
                parameters=cfg,
            ),
            assignment,
        )

    # ponytail: reset evidence is sparse in valid captures; spill fixed records
    # only if a pathological capture proves this list can become a hot footprint.
    points: list[_EvidencePoint] = []
    anchors: list[AnchorObservation] = []
    init_positions: list[int] = []
    candidates_by_source: dict[BleLogSource, list[tuple[int, int, int]]] = defaultdict(
        list
    )
    previous_by_source: dict[BleLogSource, tuple[int, int | None]] = {}
    unreliable_count = 0
    for row in range(total):
        packed = int(source_sn[row])
        source_value = packed & 0xFF
        source = _SOURCE_BY_VALUE[source_value]
        raw_sn = packed >> 8
        frame_flags = int(flags[row])

        anchor_kind: str | None = None
        if frame_flags & int(FrameMetadataFlag.INIT_DONE):
            anchor_kind = "init_done"
            init_positions.append(row)
        elif frame_flags & int(FrameMetadataFlag.FLUSH):
            anchor_kind = "flush"
        if anchor_kind is not None:
            anchors.append(AnchorObservation(row, anchor_kind))
            points.append(
                _EvidencePoint(
                    transport_index=row,
                    source=BleLogSource.INTERNAL,
                    kind=anchor_kind,
                    anchor_kind=anchor_kind,
                )
            )

        domain = SOURCE_CLOCK_MAP[source]
        reliable = bool(frame_flags & int(FrameMetadataFlag.RELIABLE_SN))
        clock = (
            normalize_raw_clock(source, int(raw_clock[row]), lc_timer_unit)
            if frame_flags & int(FrameMetadataFlag.CLOCK_PRESENT)
            else None
        )
        if reliable:
            previous = previous_by_source.get(source)
            if previous is not None:
                sn_reset = _is_sn_reset(previous[0], raw_sn, cfg)
                clock_reset = _is_clock_reset(previous[1], clock, domain, cfg)
                if sn_reset or clock_reset:
                    points.append(
                        _EvidencePoint(
                            transport_index=row,
                            source=source,
                            kind="counter",
                            domain=domain,
                            sn_reset=sn_reset,
                            clock_reset=clock_reset,
                        )
                    )
                is_init = anchor_kind == "init_done"
                if is_init or sn_reset or clock_reset:
                    strength = 0 if is_init else 1 if sn_reset else 2
                    candidates_by_source[source].append((row, raw_sn, strength))
            previous_by_source[source] = (raw_sn, clock)
        else:
            unreliable_count += 1

    groups: list[list[_EvidencePoint]] = []
    current: list[_EvidencePoint] = []
    for point in points:
        if (
            current
            and point.transport_index - current[0].transport_index
            > cfg.consensus_window
        ):
            groups.append(current)
            current = []
        current.append(point)
    if current:
        groups.append(current)

    chosen: dict[int, str] = {}
    observations: list[BoundaryObservation] = []

    def add_boundary(position: int, reason: str) -> None:
        if 0 < position < total:
            chosen.setdefault(position, reason)

    for group in groups:
        group_anchors = [point for point in group if point.anchor_kind is not None]
        counters = [point for point in group if point.kind == "counter"]
        sources = {point.source for point in counters}
        domains = {
            point.domain
            for point in counters
            if point.clock_reset and point.domain is not None
        }
        init_anchors = [
            point for point in group_anchors if point.anchor_kind == "init_done"
        ]
        flush_anchors = [
            point for point in group_anchors if point.anchor_kind == "flush"
        ]
        boundary: int | None = None
        reason = "suppressed"
        if init_anchors:
            boundary = min(point.transport_index for point in init_anchors)
            reason = "init_anchor"
            for point in init_anchors:
                add_boundary(point.transport_index, reason)
            for point in flush_anchors:
                if not any(
                    0 <= init - point.transport_index <= cfg.consensus_window
                    for init in init_positions
                ):
                    add_boundary(point.transport_index + 1, "flush_anchor")
        elif flush_anchors:
            independent = [
                point
                for point in flush_anchors
                if not any(
                    0 <= init - point.transport_index <= cfg.consensus_window
                    for init in init_positions
                )
            ]
            if independent:
                boundary = min(point.transport_index + 1 for point in independent)
                reason = "flush_anchor"
                for point in independent:
                    add_boundary(point.transport_index + 1, reason)
            else:
                reason = "flush_before_nearby_init"
        elif len(domains) >= 2 and len(sources) >= 2:
            boundary = min(
                point.transport_index for point in counters if point.clock_reset
            )
            reason = "cross_domain_clock_reset"
            add_boundary(boundary, reason)
        elif domains == {ClockDomain.LC} and not any(
            point.sn_reset for point in counters
        ):
            reason = "single_domain_clock_wrap"
        elif counters:
            reason = "single_domain_or_partial_reset"
        observations.append(
            BoundaryObservation(
                start_transport=group[0].transport_index,
                end_transport=group[-1].transport_index,
                reason=reason,
                boundary=boundary,
                sources=sorted(source.name for source in sources),
                clock_domains=sorted(domain.value for domain in domains),
            )
        )

    resets = sorted(chosen)
    cuts_by_source: dict[BleLogSource, list[int]] = {}
    for source in SOURCE_CLOCK_MAP:
        candidates = candidates_by_source.get(source, [])
        cuts: list[int] = []
        lower_bound = -1
        for index, reset in enumerate(resets):
            upper_bound = resets[index + 1] if index + 1 < len(resets) else total
            nearby = [
                candidate
                for candidate in candidates
                if lower_bound < candidate[0] < upper_bound
                and abs(candidate[0] - reset) <= cfg.consensus_window
            ]
            cut = (
                min(
                    nearby,
                    key=lambda item: (
                        item[2],
                        abs(item[0] - reset),
                        item[1],
                        item[0],
                    ),
                )[0]
                if nearby
                else reset
            )
            cuts.append(cut)
            lower_bound = cut
        cuts_by_source[source] = cuts

    return _assign_instances(
        store,
        assignment,
        cfg,
        resets,
        cuts_by_source,
        anchors,
        observations,
        unreliable_count=unreliable_count,
    )


def _assign_instances(
    store: FrameMetadataStore,
    assignment: np.ndarray,
    cfg: DetectorConfig,
    resets: list[int],
    cuts_by_source: dict[BleLogSource, list[int]],
    anchors: list[AnchorObservation],
    observations: list[BoundaryObservation],
    *,
    unreliable_count: int = 0,
) -> _DetectedInstances:
    source_sn = store.mmap_column("source_sn")
    flags = store.mmap_column("flags")
    total = store.row_count
    instance_count = len(resets) + 1
    counts = [0] * instance_count
    starts = [total] * instance_count
    ends = [0] * instance_count
    local_reassigned = 0
    for row in range(total):
        source_value = int(source_sn[row]) & 0xFF
        source = _SOURCE_BY_VALUE[source_value]
        instance = bisect.bisect_right(cuts_by_source[source], row)
        assignment[row] = instance
        counts[instance] += 1
        starts[instance] = min(starts[instance], row)
        ends[instance] = max(ends[instance], row + 1)
        if instance != bisect.bisect_right(resets, row):
            local_reassigned += 1

    segments = [
        InstanceSegment(
            index=index,
            start_transport=(
                starts[index] if counts[index] else resets[index - 1] if index else 0
            ),
            end_transport=(
                ends[index] if counts[index] else resets[index - 1] if index else 0
            ),
            frame_count=counts[index],
        )
        for index in range(instance_count)
    ]
    warnings: list[str] = []
    if unreliable_count:
        warnings.append(
            f"{unreliable_count} frame(s) have malformed or unknown payload "
            "layouts; retained without hard SN edges"
        )
    has_internal_evidence = bool(
        np.any(
            ((source_sn & 0xFF) == BleLogSource.INTERNAL)
            & (flags & int(FrameMetadataFlag.RELIABLE_SN) != 0)
        )
    )
    if not has_internal_evidence:
        warnings.append(
            "No valid INTERNAL records; pre-v8 lifecycle boundaries use best-effort evidence."
        )
    result = InstanceDetectionResult(
        total_frames=total,
        instances=segments,
        boundaries=resets,
        anchors=anchors,
        boundary_observations=observations,
        boundary_reason_counts=dict(
            Counter(observation.reason for observation in observations)
        ),
        source_local_reassigned=local_reassigned,
        unreliable_frames=unreliable_count,
        warnings=warnings,
        parameters=cfg,
    )
    return _DetectedInstances(result, assignment)


_SN_RECORD_DTYPE = np.dtype(
    [
        ("instance", "<u4"),
        ("source_key", "<u4"),
        ("payload_size", "<u2"),
        ("payload_crc32", "<u4"),
        ("row", "<u4"),
    ],
    align=False,
)


@dataclass(slots=True)
class _SnGraph:
    survivor: np.ndarray
    successor: np.ndarray
    indegree: np.ndarray
    unwrapped_sn: np.ndarray
    diagnostics: list[dict[str, int]]
    deduplicated_rows: int


def _commit_source_edges(
    values: array[int] | np.ndarray,
    first_rows: array[int] | np.ndarray,
    counts: array[int] | np.ndarray | None,
    successor: np.ndarray,
    indegree: np.ndarray,
    unwrapped_sn: np.ndarray,
    cfg: DetectorConfig,
    diagnostics: Counter[str],
) -> tuple[str, int, int]:
    if not len(values):
        diagnostics["unobservable_sources"] += 1
        return "unobservable", 0, 0

    value_array = np.asarray(values, dtype="<u4")
    row_array = np.asarray(first_rows, dtype="<u4")
    count_array = np.asarray(counts, dtype="<u4") if counts is not None else None
    gaps = np.empty(len(value_array), dtype="<u4")
    if len(value_array) == 1:
        gaps[0] = _SN_PERIOD
    else:
        gaps[:-1] = value_array[1:] - value_array[:-1]
        gaps[-1] = (int(value_array[0]) - int(value_array[-1])) % _SN_PERIOD

    if count_array is None:
        duplicate_mask = None
        duplicate_values = 0
        duplicate_frames = 0
        reported_duplicate_frames = 0
    else:
        duplicate_mask = count_array > 1
        duplicate_values = int(np.count_nonzero(duplicate_mask))
        duplicate_frames = int(np.sum(count_array[duplicate_mask] - 1, dtype=np.uint64))
        reported_duplicate_frames = int(
            np.sum(count_array[duplicate_mask], dtype=np.uint64)
        )
    large_gap_mask = gaps > cfg.max_forward_sn_gap
    large_gaps = int(np.count_nonzero(large_gap_mask))
    diagnostics["large_gaps"] += large_gaps
    diagnostics["duplicate_values"] += duplicate_values
    diagnostics["duplicate_frames"] += reported_duplicate_frames
    if duplicate_frames:
        status = "ambiguous_multiwrap" if large_gaps == 0 else "degraded_duplicate"
    else:
        status = "hard" if large_gaps <= 1 else "degraded_gap"

    breaks = large_gaps
    if duplicate_mask is not None:
        breaks += int(
            np.count_nonzero(
                (gaps[:-1] <= cfg.max_forward_sn_gap)
                & (duplicate_mask[:-1] | duplicate_mask[1:])
            )
        )
        if gaps[-1] <= cfg.max_forward_sn_gap and (
            duplicate_mask[-1] or duplicate_mask[0]
        ):
            breaks += 1
    if breaks == 0:
        diagnostics["full_ring_sources"] += 1
        return (
            "ambiguous_multiwrap" if duplicate_frames else "ambiguous_ring",
            duplicate_frames,
            large_gaps,
        )

    if duplicate_values == 0 and large_gaps == 1:
        gap_index = int(np.flatnonzero(large_gap_mask)[0])
        unwrapped_sn[row_array] = value_array
        if gap_index < len(value_array) - 1:
            unwrapped_sn[row_array[: gap_index + 1]] += _SN_PERIOD

    edge_mask = gaps[:-1] <= cfg.max_forward_sn_gap
    if duplicate_mask is not None:
        edge_mask &= ~duplicate_mask[:-1] & ~duplicate_mask[1:]
    left_rows = row_array[:-1][edge_mask]
    right_rows = row_array[1:][edge_mask]
    if np.any(successor[left_rows] != -1) or np.any(indegree[right_rows] != 0):
        raise AssertionError("invalid hard SN endpoint multiplicity")
    successor[left_rows] = right_rows
    indegree[right_rows] = 1
    hard_edges = len(left_rows)

    wrap_edge = gaps[-1] <= cfg.max_forward_sn_gap
    if duplicate_mask is not None:
        wrap_edge = bool(wrap_edge and not duplicate_mask[-1] and not duplicate_mask[0])
    if wrap_edge:
        left = int(row_array[-1])
        right = int(row_array[0])
        if int(successor[left]) != -1 or int(indegree[right]) != 0:
            raise AssertionError("invalid hard SN endpoint multiplicity")
        successor[left] = right
        indegree[right] = 1
        hard_edges += 1
    diagnostics["hard_edges"] += hard_edges
    return status, duplicate_frames, large_gaps


def _build_sn_graph(
    store: FrameMetadataStore,
    capture_path: Path,
    workspace: Path,
    detected: _DetectedInstances,
    *,
    cfg: DetectorConfig,
) -> _SnGraph:
    total = store.row_count
    source_sn = store.mmap_column("source_sn")
    payload_offset = store.mmap_column("payload_offset")
    payload_size = store.mmap_column("payload_size")
    payload_crc32 = store.mmap_column("payload_crc32")
    flags = store.mmap_column("flags")
    assignment = detected.assignment

    survivor = _create_memmap(
        workspace / "survivor.u8",
        "u1",
        total,
        fill=1,
    )
    successor = _create_memmap(
        workspace / "successor.i32",
        "<i4",
        total,
        fill=-1,
    )
    indegree = _create_memmap(
        workspace / "indegree.u8",
        "u1",
        total,
        fill=0,
    )
    unwrapped_sn = _create_memmap(
        workspace / "unwrapped_sn.u32",
        "<u4",
        total,
        fill=_UINT32_MAX,
    )

    records_path = workspace / "sn_records.bin"
    records = _create_memmap(
        records_path,
        _SN_RECORD_DTYPE,
        total,
    )
    chunk_rows = 1_000_000
    for start in range(0, total, chunk_rows):
        end = min(start + chunk_rows, total)
        packed = np.asarray(source_sn[start:end])
        rows = np.arange(start, end, dtype="<u4")
        target = records[start:end]
        target["instance"] = assignment[start:end]
        target["source_key"] = ((packed & 0xFF) << 24) | (packed >> 8)
        target["payload_size"] = payload_size[start:end]
        target["payload_crc32"] = payload_crc32[start:end]
        target["row"] = rows
    sort_order = (
        "instance",
        "source_key",
        "payload_size",
        "payload_crc32",
        "row",
    )
    runs = _sort_record_runs(records, sort_order)

    instance_count = len(detected.result.instances)
    diagnostics = [Counter() for _ in range(instance_count)]
    source_diagnostics: list[SourceDiagnostic] = []
    deduplicated_rows = 0

    def commit_source(
        instance: int,
        source_value: int,
        values: array[int] | np.ndarray,
        first_rows: array[int] | np.ndarray,
        counts: array[int] | np.ndarray | None,
    ) -> None:
        status, duplicates, large_gaps = _commit_source_edges(
            values,
            first_rows,
            counts,
            successor,
            indegree,
            unwrapped_sn,
            cfg,
            diagnostics[instance],
        )
        source_diagnostics.append(
            SourceDiagnostic(
                instance=instance,
                source=_SOURCE_BY_VALUE[source_value].name,
                status=status,
                duplicate_frames=duplicates,
                large_gaps=large_gaps,
            )
        )

    if not len(records):
        _close_memmap(records)
        records_path.unlink()
        return _SnGraph(
            survivor=survivor,
            successor=successor,
            indegree=indegree,
            unwrapped_sn=unwrapped_sn,
            diagnostics=[dict(values) for values in diagnostics],
            deduplicated_rows=0,
        )

    reliable_flag = int(FrameMetadataFlag.RELIABLE_SN)
    with capture_path.open("rb") as capture_file:

        def consume_source_group(
            instance: int,
            source_value: int,
            source_group,
        ) -> None:
            nonlocal deduplicated_rows
            values = array("I")
            first_rows = array("I")
            counts = array("I")
            raw_groups = groupby(
                source_group,
                key=lambda record: int(record["source_key"]) & 0xFFFFFF,
            )
            for raw_sn, raw_group in raw_groups:
                reliable_count = 0
                first_reliable = _UINT32_MAX
                equal_groups = groupby(
                    raw_group,
                    key=lambda record: (
                        int(record["payload_size"]),
                        int(record["payload_crc32"]),
                    ),
                )
                for _, equal_group in equal_groups:
                    first_record = next(equal_group)
                    second_record = next(equal_group, None)
                    if second_record is None:
                        row = int(first_record["row"])
                        if int(flags[row]) & reliable_flag:
                            reliable_count += 1
                            first_reliable = min(first_reliable, row)
                        continue
                    # ponytail: equal-size CRC32 collisions are normally one
                    # payload; spill representatives only for adversarial data.
                    representatives: list[tuple[int, bytes]] = []
                    for record in chain(
                        (first_record, second_record),
                        equal_group,
                    ):
                        row = int(record["row"])
                        candidate_payload = os.pread(
                            capture_file.fileno(),
                            int(payload_size[row]),
                            int(payload_offset[row]),
                        )
                        identity = (int(source_sn[row]) & 0xFF, candidate_payload)
                        if identity in representatives:
                            survivor[row] = 0
                            deduplicated_rows += 1
                            continue
                        representatives.append(identity)
                        if int(flags[row]) & reliable_flag:
                            reliable_count += 1
                            first_reliable = min(first_reliable, row)

                if reliable_count:
                    values.append(raw_sn)
                    first_rows.append(first_reliable)
                    counts.append(reliable_count)
            commit_source(instance, source_value, values, first_rows, counts)

        if len(runs) == 1:
            record_instances = records["instance"]
            record_sources = records["source_key"] >> 24
            boundaries = (
                np.flatnonzero(
                    (record_instances[1:] != record_instances[:-1])
                    | (record_sources[1:] != record_sources[:-1])
                )
                + 1
            )
            del record_sources
            start = 0
            for end_value in chain(boundaries, (len(records),)):
                end = int(end_value)
                source_records = records[start:end]
                instance = int(source_records[0]["instance"])
                source_value = int(source_records[0]["source_key"]) >> 24
                raw_sns = source_records["source_key"] & 0xFFFFFF
                repeated = bool(
                    len(raw_sns) > 1 and np.any(raw_sns[1:] == raw_sns[:-1])
                )
                if repeated:
                    consume_source_group(
                        instance,
                        source_value,
                        iter(source_records),
                    )
                else:
                    row_values = source_records["row"]
                    reliable = (flags[row_values] & reliable_flag) != 0
                    if np.all(reliable):
                        commit_source(
                            instance,
                            source_value,
                            raw_sns,
                            row_values,
                            None,
                        )
                    else:
                        commit_source(
                            instance,
                            source_value,
                            raw_sns[reliable],
                            row_values[reliable],
                            None,
                        )
                start = end
        else:
            sorted_records = _iter_merged_records(records, runs, sort_order)
            try:
                source_groups = groupby(
                    sorted_records,
                    key=lambda record: (
                        int(record["instance"]),
                        int(record["source_key"]) >> 24,
                    ),
                )
                for (instance, source_value), source_group in source_groups:
                    consume_source_group(instance, source_value, source_group)
            finally:
                sorted_records.close()

    _close_memmap(records)
    records_path.unlink()
    detected.result.source_diagnostics = source_diagnostics
    ambiguous = sum(
        diagnostic.status not in {"hard", "unobservable"}
        for diagnostic in source_diagnostics
    )
    if ambiguous:
        detected.result.warnings.append(
            f"{ambiguous} source/instance stream(s) are degraded or ambiguous; "
            "all frames retained with soft fallback ordering"
        )
    return _SnGraph(
        survivor=survivor,
        successor=successor,
        indegree=indegree,
        unwrapped_sn=unwrapped_sn,
        diagnostics=[dict(values) for values in diagnostics],
        deduplicated_rows=deduplicated_rows,
    )


_CLOCK_RECORD_DTYPE = np.dtype(
    [
        ("raw_clock", "<u4"),
        ("row", "<u4"),
    ],
    align=False,
)


@dataclass(frozen=True, slots=True)
class _ClockPlan:
    status: _ClockEpochStatus
    split_low: int | None = None

    @property
    def usable(self) -> bool:
        return self.status in {
            _ClockEpochStatus.UNWRAP_PROVEN,
            _ClockEpochStatus.SINGLE_CYCLE_DEFAULT,
        }

    def unwrap(self, raw_clock: int) -> int | None:
        if not self.usable:
            return None
        if self.split_low is not None and raw_clock <= self.split_low:
            return raw_clock + _CLOCK_PERIOD
        return raw_clock


@dataclass(slots=True)
class _ClockOrdering:
    plans: dict[tuple[int, ClockDomain], _ClockPlan]
    inferred: dict[int, list[str]]
    anchor_maps: dict[int, AnchorMap]
    priority_rows: np.ndarray
    priority_position: np.ndarray
    instance_rows: np.ndarray
    instance_ranges: list[tuple[int, int]]


def _domain_from_code(value: int) -> ClockDomain:
    return ClockDomain.LC if value == 0 else ClockDomain.FREERTOS


def _clock_plan_for_group(
    raw_values: np.ndarray,
    *,
    min_clock_observations: int,
) -> tuple[_ClockPlan, int | None]:
    if len(raw_values) == 0:
        return _ClockPlan(_ClockEpochStatus.UNOBSERVABLE), None

    unique_count = 1
    first = int(raw_values[0])
    previous = first
    largest_gap = -1
    largest_gap_left: int | None = None
    for raw_value in raw_values[1:]:
        raw = int(raw_value)
        if raw == previous:
            continue
        gap = raw - previous
        if gap > largest_gap:
            largest_gap = gap
            largest_gap_left = previous
        unique_count += 1
        previous = raw
    span = previous - first

    if unique_count < min_clock_observations:
        status = _ClockEpochStatus.UNSUPPORTED
    elif span < _CLOCK_PERIOD // 2:
        status = _ClockEpochStatus.SINGLE_CYCLE_DEFAULT
    else:
        status = _ClockEpochStatus.AMBIGUOUS
    return _ClockPlan(status), largest_gap_left


_CONFIDENCE_LOW = 3


def _linearize_metadata(
    store: FrameMetadataStore,
    workspace: Path,
    graph: _SnGraph,
    clocks: _ClockOrdering,
    *,
    host_clock_scale: int,
    host_clock_name: str,
) -> tuple[np.ndarray, np.ndarray, list[MetadataInstanceOrdering]]:
    total = store.row_count
    source_sn = store.mmap_column("source_sn")
    raw_clock = store.mmap_column("raw_clock")
    flags = store.mmap_column("flags")
    confidence = _create_memmap(
        workspace / "confidence.u8",
        "u1",
        total,
        fill=_CONFIDENCE_LOW,
    )
    output_count = len(clocks.instance_rows)
    ordered_rows = _create_memmap(
        workspace / "order.u32",
        "<u4",
        output_count,
    )
    output_cursor = 0
    instances: list[MetadataInstanceOrdering] = []
    reliable_flag = int(FrameMetadataFlag.RELIABLE_SN)

    for instance, (start, end) in enumerate(clocks.instance_ranges):
        rows = clocks.instance_rows[start:end]
        anchor_map = clocks.anchor_maps.get(instance)
        anchors = anchor_map.anchors if anchor_map is not None else ()
        anchor_lc = np.fromiter(
            (anchor.lc_ts for anchor in anchors),
            dtype="<i8",
            count=len(anchors),
        )
        anchor_os = np.fromiter(
            (anchor.os_ts_ms for anchor in anchors),
            dtype="<i8",
            count=len(anchors),
        )
        lc_plan = clocks.plans.get((instance, ClockDomain.LC))
        freertos_plan = clocks.plans.get((instance, ClockDomain.FREERTOS))
        lc_split = lc_plan.split_low if lc_plan is not None else None
        freertos_split = freertos_plan.split_low if freertos_plan is not None else None
        (
            tie_decisions,
            sn_forced_choices,
            transport_choices,
            clock_choices,
            aligned_choices,
        ) = linearize_instance(
            rows,
            graph.successor,
            graph.indegree,
            clocks.priority_rows,
            clocks.priority_position,
            source_sn,
            raw_clock,
            flags,
            _CLOCK_DOMAIN_BY_SOURCE,
            lc_split is not None,
            lc_split if lc_split is not None else 0,
            freertos_split is not None,
            freertos_split if freertos_split is not None else 0,
            anchor_lc,
            anchor_os,
            ordered_rows[output_cursor : output_cursor + len(rows)],
            confidence,
            host_clock_scale,
        )
        output_cursor += len(rows)

        clock_diagnostics = {
            (
                host_clock_name if domain is ClockDomain.FREERTOS else domain.value
            ): plan.status.value
            for (candidate_instance, domain), plan in clocks.plans.items()
            if candidate_instance == instance
        }
        unreliable_frames = 0
        inverted_edges = 0
        for chunk_start in range(0, len(rows), 1_000_000):
            chunk = rows[chunk_start : chunk_start + 1_000_000]
            unreliable_frames += int(
                np.count_nonzero((flags[chunk] & reliable_flag) == 0)
            )
            successors = graph.successor[chunk]
            valid = successors >= 0
            inverted_edges += int(np.count_nonzero(chunk[valid] > successors[valid]))
        sn_diagnostics = {
            "unreliable_frames": unreliable_frames,
            "large_gaps": 0,
            "duplicate_values": 0,
            "duplicate_frames": 0,
            "hard_edges": 0,
            "unobservable_sources": 0,
            **graph.diagnostics[instance],
        }
        distribution = {
            name: count
            for name, count in (
                ("sn_forced", sn_forced_choices),
                ("transport", transport_choices),
                ("clock", clock_choices),
                ("aligned", aligned_choices),
            )
            if count
        }
        instances.append(
            MetadataInstanceOrdering(
                diagnostics={
                    "sn": sn_diagnostics,
                    "clock": clock_diagnostics,
                    "clock_inferred_from_sn": clocks.inferred.get(instance, []),
                    "transport_inverted_hard_edges": inverted_edges,
                    "tie_decisions": tie_decisions,
                    "choice_distribution": distribution,
                    "ts_sync_anchors": (len(anchor_map.anchors) if anchor_map else 0),
                    "ts_sync_rejected": (anchor_map.rejected if anchor_map else 0),
                },
            )
        )
    if output_cursor != output_count:
        raise AssertionError("frame conservation failed")
    return ordered_rows, confidence, instances


def _clock_wrap_counts(
    edge_rows: np.ndarray,
    right_rows: np.ndarray,
    source_sn: np.ndarray,
    raw_clock: np.ndarray,
    assignment: np.ndarray,
) -> Counter[tuple[int, ClockDomain, int]]:
    wrap_counts: Counter[tuple[int, ClockDomain, int]] = Counter()
    edge_sources = source_sn[edge_rows] & 0xFF
    same_source = (
        _CLOCK_DOMAIN_BY_SOURCE[edge_sources]
        == _CLOCK_DOMAIN_BY_SOURCE[source_sn[right_rows] & 0xFF]
    )
    wraps = same_source & (
        raw_clock[edge_rows].astype("<u8", copy=False)
        > raw_clock[right_rows].astype("<u8", copy=False) + _CLOCK_PERIOD // 2
    )
    for row_value, source_value_raw in zip(
        edge_rows[wraps],
        edge_sources[wraps],
        strict=True,
    ):
        row = int(row_value)
        source_value = int(source_value_raw)
        domain = _domain_from_code(int(_CLOCK_DOMAIN_BY_SOURCE[source_value]))
        wrap_counts[(int(assignment[row]), domain, source_value)] += 1

    return wrap_counts


def _per_source_clock_evidence(
    graph: _SnGraph,
    source_sn: np.ndarray,
    raw_clock: np.ndarray,
    assignment: np.ndarray,
) -> Counter[tuple[int, ClockDomain]]:
    edge_rows = np.flatnonzero(graph.successor >= 0)
    counts = _clock_wrap_counts(
        edge_rows,
        graph.successor[edge_rows],
        source_sn,
        raw_clock,
        assignment,
    )
    wraps: Counter[tuple[int, ClockDomain]] = Counter()
    for (instance, domain, _), count in counts.items():
        wraps[instance, domain] = max(wraps[instance, domain], count)
    return wraps


def _build_clock_ordering(
    store: FrameMetadataStore,
    workspace: Path,
    detected: _DetectedInstances,
    graph: _SnGraph,
    *,
    lc_timer_unit: LcTimerUnit,
    cfg: DetectorConfig,
    min_clock_observations: int,
) -> _ClockOrdering:
    total = store.row_count
    source_sn = store.mmap_column("source_sn")
    raw_clock = store.mmap_column("raw_clock")
    flags = store.mmap_column("flags")
    assignment = detected.assignment

    instance_count = len(detected.result.instances)
    clock_group_counts = np.zeros(instance_count * 2, dtype="<i8")
    required_flags = int(FrameMetadataFlag.RELIABLE_SN) | int(
        FrameMetadataFlag.CLOCK_PRESENT
    )
    for start in range(0, total, 1_000_000):
        end = min(start + 1_000_000, total)
        packed = np.asarray(source_sn[start:end])
        sources = packed & 0xFF
        frame_flags = np.asarray(flags[start:end])
        mask = (np.asarray(graph.survivor[start:end]) != 0) & (
            frame_flags & required_flags == required_flags
        )
        group_keys = (
            assignment[start:end][mask].astype("<i8", copy=False) * 2
            + _CLOCK_DOMAIN_BY_SOURCE[sources[mask]]
        )
        clock_group_counts += np.bincount(
            group_keys,
            minlength=len(clock_group_counts),
        )

    clock_group_offsets = np.empty(len(clock_group_counts) + 1, dtype="<i8")
    clock_group_offsets[0] = 0
    np.cumsum(clock_group_counts, out=clock_group_offsets[1:])
    clock_count = int(clock_group_offsets[-1])

    clock_path = workspace / "clock_records.bin"
    clock_records = _create_memmap(
        clock_path,
        _CLOCK_RECORD_DTYPE,
        clock_count,
    )
    cursors = clock_group_offsets[:-1].copy()
    for start in range(0, total, 1_000_000):
        end = min(start + 1_000_000, total)
        packed = np.asarray(source_sn[start:end])
        sources = packed & 0xFF
        frame_flags = np.asarray(flags[start:end])
        mask = (np.asarray(graph.survivor[start:end]) != 0) & (
            frame_flags & required_flags == required_flags
        )
        rows = np.nonzero(mask)[0].astype("<u4", copy=False) + start
        group_keys = (
            assignment[rows].astype("<i8", copy=False) * 2
            + _CLOCK_DOMAIN_BY_SOURCE[sources[mask]]
        )
        for group_key_value in np.unique(group_keys):
            group_key = int(group_key_value)
            selected_rows = rows[group_keys == group_key_value]
            cursor = int(cursors[group_key])
            target = clock_records[cursor : cursor + len(selected_rows)]
            target["raw_clock"] = raw_clock[selected_rows]
            target["row"] = selected_rows
            cursors[group_key] += len(selected_rows)
    if not np.array_equal(cursors, clock_group_offsets[1:]):
        raise AssertionError("clock-frame count changed while grouping records")

    clock_sort_order = ("raw_clock", "row")
    group_runs: list[tuple[int, int, list[tuple[int, int]]]] = []
    for group_key, count_value in enumerate(clock_group_counts):
        if not count_value:
            continue
        start = int(clock_group_offsets[group_key])
        end = int(clock_group_offsets[group_key + 1])
        group = clock_records[start:end]
        runs = _sort_record_runs(group, clock_sort_order)
        group_runs.append((start, end, runs))
        del group

    if any(len(runs) > 1 for _, _, runs in group_runs):
        sorted_clock_path = workspace / "clock_records_sorted.bin"
        sorted_clock_records = _create_memmap(
            sorted_clock_path,
            _CLOCK_RECORD_DTYPE,
            len(clock_records),
        )
        for start, end, runs in group_runs:
            source_group = clock_records[start:end]
            target_group = sorted_clock_records[start:end]
            if len(runs) == 1:
                target_group[:] = source_group
            else:
                merged = _iter_merged_records(
                    source_group,
                    runs,
                    clock_sort_order,
                )
                try:
                    for index, record in enumerate(merged):
                        target_group[index] = record
                finally:
                    merged.close()
            del source_group, target_group
        _close_memmap(clock_records)
        clock_path.unlink()
        clock_records = sorted_clock_records
        clock_path = sorted_clock_path

    plans: dict[tuple[int, ClockDomain], _ClockPlan] = {}
    largest_gap_left: dict[tuple[int, ClockDomain], int | None] = {}
    clock_ranges: dict[tuple[int, ClockDomain], tuple[int, int]] = {}
    for group_key, count_value in enumerate(clock_group_counts):
        if not count_value:
            continue
        instance, domain_code = divmod(group_key, 2)
        domain = _domain_from_code(domain_code)
        position = int(clock_group_offsets[group_key])
        end = int(clock_group_offsets[group_key + 1])
        plan, gap_left = _clock_plan_for_group(
            clock_records["raw_clock"][position:end],
            min_clock_observations=min_clock_observations,
        )
        plans[(instance, domain)] = plan
        largest_gap_left[(instance, domain)] = gap_left
        clock_ranges[(instance, domain)] = (position, end)

    wrap_counts = _per_source_clock_evidence(
        graph,
        source_sn,
        raw_clock,
        assignment,
    )

    inferred: dict[int, list[str]] = defaultdict(list)
    for key, plan in list(plans.items()):
        instance, domain = key
        if plan.status is not _ClockEpochStatus.AMBIGUOUS:
            continue
        split = largest_gap_left[key]
        wrap_count = wrap_counts[key]
        if wrap_count != 1 or split is None:
            continue
        valid = True
        for row in range(total):
            if int(assignment[row]) != instance:
                continue
            source_value = int(source_sn[row]) & 0xFF
            source = _SOURCE_BY_VALUE[source_value]
            if SOURCE_CLOCK_MAP[source] is not domain:
                continue
            right = int(graph.successor[row])
            if right < 0:
                continue
            if (
                SOURCE_CLOCK_MAP[_SOURCE_BY_VALUE[int(source_sn[right]) & 0xFF]]
                is not domain
            ):
                continue
            left_raw = int(raw_clock[row])
            right_raw = int(raw_clock[right])
            if left_raw - right_raw > _CLOCK_PERIOD // 2 and not (
                right_raw <= split < left_raw
            ):
                valid = False
                break
        if not valid:
            continue
        plans[key] = _ClockPlan(_ClockEpochStatus.UNWRAP_PROVEN, split)
        inferred[instance].append(domain.value)

    instance_count = len(detected.result.instances)
    internal_counts = np.zeros(instance_count, dtype="<i8")
    instance_counts = np.zeros(instance_count, dtype="<i8")
    observed_plan_keys: set[int] = set()
    for start in range(0, total, 1_000_000):
        end = min(start + 1_000_000, total)
        sources = source_sn[start:end] & 0xFF
        live = graph.survivor[start:end] != 0
        assigned = assignment[start:end]
        internal_counts += np.bincount(
            assigned[live & (sources == BleLogSource.INTERNAL.value)],
            minlength=instance_count,
        )
        instance_counts += np.bincount(
            assigned[live],
            minlength=instance_count,
        )
        reliable = live & (flags[start:end] & int(FrameMetadataFlag.RELIABLE_SN) != 0)
        packed_keys = (
            assigned[reliable].astype("<u8", copy=False) * 2
            + _CLOCK_DOMAIN_BY_SOURCE[sources[reliable]]
        )
        observed_plan_keys.update(np.unique(packed_keys).tolist())

    for packed_key in observed_plan_keys:
        instance, domain_code = divmod(packed_key, 2)
        key = (instance, _domain_from_code(domain_code))
        plans.setdefault(
            key,
            _ClockPlan(_ClockEpochStatus.UNOBSERVABLE),
        )

    anchors_by_instance: dict[int, list[AnchorInfo]] = defaultdict(list)
    rejected_by_instance: Counter[int] = Counter()
    max_distance = (
        cfg.ts_sync_max_lc_distance_us * 32768 // 1_000_000
        if lc_timer_unit is LcTimerUnit.RTC_TICK
        else cfg.ts_sync_max_lc_distance_us
    )
    for anchor_row, raw_lc, os_ts in store.mmap_anchors():
        row = int(anchor_row)
        if not graph.survivor[row]:
            continue
        instance = int(assignment[row])
        if internal_counts[instance] < 2:
            continue
        plan = plans.get((instance, ClockDomain.LC))
        clock_range = clock_ranges.get((instance, ClockDomain.LC))
        if plan is None or not plan.usable or clock_range is None:
            rejected_by_instance[instance] += 1
            continue
        start, end = clock_range
        values = clock_records["raw_clock"][start:end]
        insertion = int(np.searchsorted(values, int(raw_lc), side="left"))
        candidate_positions = {0, len(values) - 1}
        if insertion > 0:
            candidate_positions.add(insertion - 1)
        if insertion < len(values):
            candidate_positions.add(insertion)

        best: tuple[int, int, int] | None = None
        for local_position in candidate_positions:
            candidate_raw = int(values[local_position])
            first_for_raw = int(np.searchsorted(values, candidate_raw, side="left"))
            neighbour_row = int(clock_records[start + first_for_raw]["row"])
            neighbour_clock = plan.unwrap(candidate_raw)
            if neighbour_clock is None:
                continue
            epoch = (
                neighbour_clock - int(raw_lc) + _CLOCK_PERIOD // 2
            ) // _CLOCK_PERIOD
            expanded = int(raw_lc) + epoch * _CLOCK_PERIOD
            candidate = (abs(expanded - neighbour_clock), neighbour_row, epoch)
            if best is None or candidate < best:
                best = candidate
        if best is None or best[0] > max_distance:
            rejected_by_instance[instance] += 1
            continue
        anchors_by_instance[instance].append(
            AnchorInfo(
                lc_ts=int(raw_lc) + best[2] * _CLOCK_PERIOD,
                os_ts_ms=int(os_ts),
            )
        )

    anchor_maps: dict[int, AnchorMap] = {}
    for instance in anchors_by_instance.keys() | rejected_by_instance.keys():
        anchor_map = build_anchor_map(anchors_by_instance[instance])
        anchor_map.rejected += rejected_by_instance[instance]
        anchor_maps[instance] = anchor_map

    instance_offsets = [0]
    for count in instance_counts:
        instance_offsets.append(instance_offsets[-1] + int(count))
    instance_rows = _create_memmap(
        workspace / "instance_rows.u32",
        "<u4",
        instance_offsets[-1],
    )
    cursors = instance_offsets[:-1].copy()
    for start in range(0, total, 1_000_000):
        end = min(start + 1_000_000, total)
        live = graph.survivor[start:end] != 0
        rows = np.flatnonzero(live).astype("<u4", copy=False) + start
        row_instances = assignment[rows]
        for instance_value in np.unique(row_instances):
            instance = int(instance_value)
            selected = rows[row_instances == instance_value]
            target = cursors[instance]
            instance_rows[target : target + len(selected)] = selected
            cursors[instance] += len(selected)
    instance_ranges = [
        (instance_offsets[index], instance_offsets[index + 1])
        for index in range(len(instance_counts))
    ]

    priority_count = sum(
        plan.usable and (end - start)
        for key, (start, end) in clock_ranges.items()
        if (plan := plans.get(key)) is not None
    )
    priority_position = _create_memmap(
        workspace / "priority_position.u32",
        "<u4",
        total,
        fill=_UINT32_MAX,
    )
    compact_priority = _create_memmap(
        workspace / "priority_rows.u32",
        "<u4",
        int(priority_count),
    )
    cursor = 0
    for key, (start, end) in clock_ranges.items():
        plan = plans[key]
        if not plan.usable:
            continue
        raw_values = clock_records["raw_clock"][start:end]
        rows = clock_records["row"][start:end]
        split = (
            int(np.searchsorted(raw_values, plan.split_low, side="right"))
            if plan.split_low is not None
            else 0
        )
        for values in (rows[split:], rows[:split]):
            count = len(values)
            compact_priority[cursor : cursor + count] = values
            cursor += count
    if cursor != priority_count:
        raise AssertionError("priority-frame count changed while ordering clocks")
    priority_position[compact_priority] = np.arange(priority_count, dtype="<u4")
    _close_memmap(clock_records)
    clock_path.unlink()
    return _ClockOrdering(
        plans=plans,
        inferred=dict(inferred),
        anchor_maps=anchor_maps,
        priority_rows=compact_priority,
        priority_position=priority_position,
        instance_rows=instance_rows,
        instance_ranges=instance_ranges,
    )


def order_metadata_store(
    store: FrameMetadataStore,
    capture_path: Path,
    workspace: Path,
    *,
    protocol: CaptureProtocol | None = None,
    lc_timer_unit: LcTimerUnit,
    cfg: DetectorConfig | None = None,
    min_clock_observations: int = 8,
    retain_unwrapped_sn: bool = False,
) -> MetadataOrderingResult:
    """Order a sealed store using the caller's selected capture protocol."""
    if not store.sealed:
        raise RuntimeError("FrameMetadataStore must be sealed before ordering")
    protocol = protocol or store.protocol_evidence.resolve()
    cfg = cfg or DetectorConfig()
    workspace.mkdir(parents=True, exist_ok=False)

    if protocol.is_v8:
        from ble_log_frame_decoder.analysis.ordering.snapshot_ordering import (
            order_snapshot_metadata,
        )

        return order_snapshot_metadata(
            store,
            capture_path,
            workspace,
            cfg=cfg,
            retain_unwrapped_sn=retain_unwrapped_sn,
        )
    detected = _detect_per_source_instances(
        store, workspace, lc_timer_unit=lc_timer_unit, cfg=cfg
    )
    graph = _build_sn_graph(
        store,
        capture_path,
        workspace,
        detected,
        cfg=cfg,
    )
    if not retain_unwrapped_sn:
        _close_memmap(graph.unwrapped_sn)
        (workspace / "unwrapped_sn.u32").unlink()
        graph.unwrapped_sn = np.empty(0, dtype="<u4")
    clocks = _build_clock_ordering(
        store,
        workspace,
        detected,
        graph,
        lc_timer_unit=lc_timer_unit,
        cfg=cfg,
        min_clock_observations=min_clock_observations,
    )
    ordered_rows, confidence, instances = _linearize_metadata(
        store,
        workspace,
        graph,
        clocks,
        host_clock_scale=1000,
        host_clock_name="freertos",
    )

    for mapped, name in (
        (graph.survivor, "survivor.u8"),
        (graph.successor, "successor.i32"),
        (graph.indegree, "indegree.u8"),
        (clocks.priority_rows, "priority_rows.u32"),
        (clocks.priority_position, "priority_position.u32"),
        (clocks.instance_rows, "instance_rows.u32"),
    ):
        _close_memmap(mapped)
        (workspace / name).unlink()

    result = MetadataOrderingResult(
        store=store,
        detection=detected.result,
        ordered_rows=ordered_rows,
        instance_by_row=detected.assignment,
        confidence_by_row=confidence,
        unwrapped_sn_by_row=graph.unwrapped_sn,
        instances=instances,
        deduplicated_rows=graph.deduplicated_rows,
        uses_global_sn=False,
    )
    return result
