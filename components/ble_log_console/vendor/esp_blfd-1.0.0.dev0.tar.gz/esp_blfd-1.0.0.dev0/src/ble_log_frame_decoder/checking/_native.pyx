# cython: language_level=3, overflowcheck=True
"""Native snapshot windows; protocol decisions and public results remain Python."""

from libc.stdint cimport int64_t, uint64_t
from libcpp.unordered_map cimport unordered_map
from libcpp.vector cimport vector
from libcpp.algorithm cimport sort
from cython.operator cimport dereference as deref

from .checker import LogChecker as PythonLogChecker
from .results import IntervalResult, Received, _detail

cdef struct Record:
    int source
    Py_ssize_t size


cdef class _Frames:
    cdef unordered_map[int64_t, Record] records
    # Dict insertion order is significant for the first unanchored SN.
    cdef vector[int64_t] order

    def __len__(self):
        return self.records.size()

    def __contains__(self, int64_t sn):
        return self.records.count(sn) != 0

    def __getitem__(self, int64_t sn):
        cdef unordered_map[int64_t, Record].iterator it = self.records.find(sn)
        if it == self.records.end():
            raise KeyError(sn)
        return deref(it).second.source, deref(it).second.size

    def __setitem__(self, int64_t sn, value):
        cdef Record record
        record.source, record.size = value
        if not 0 <= record.source <= 8 or record.size < 0:
            raise ValueError("Invalid window record")
        if not self.records.count(sn):
            self.order.push_back(sn)
        self.records[sn] = record

    def __iter__(self):
        cdef int64_t sn
        for sn in self.order:
            yield sn

    def items(self):
        cdef int64_t sn
        cdef Record record
        for sn in self.order:
            record = self.records.at(sn)
            yield sn, (record.source, record.size)

    def clear(self):
        cdef unordered_map[int64_t, Record] empty_records
        cdef vector[int64_t] empty_order
        self.records.swap(empty_records)
        self.order.swap(empty_order)


cdef class Window:
    cdef public int64_t lower, upper, deadline
    cdef readonly _Frames frames
    cdef public dict duplicates

    def __init__(self, lower=0, upper=0, deadline=0):
        self.lower, self.upper, self.deadline = lower, upper, deadline
        self.frames = _Frames()
        self.duplicates = {}

    cdef int record(self, int64_t sn, int source, Py_ssize_t size, bint room) except -1:
        cdef Record record
        if self.frames.records.count(sn):
            self.duplicates[sn] = self.duplicates.get(sn, 0) + 1
            return 0
        if not room:
            return 2
        record.source, record.size = source, size
        self.frames.order.push_back(sn)
        self.frames.records[sn] = record
        return 1

    def split(self, int64_t upper, int64_t deadline):
        cdef Window result = Window(self.lower, upper, deadline)
        cdef vector[int64_t] remaining
        cdef int64_t sn
        for sn in self.frames.order:
            if sn <= upper:
                result.frames.order.push_back(sn)
                result.frames.records[sn] = self.frames.records.at(sn)
                self.frames.records.erase(sn)
            else:
                remaining.push_back(sn)
        self.frames.order.swap(remaining)
        result.duplicates = {n: v for n, v in self.duplicates.items() if n <= upper}
        self.duplicates = {n: v for n, v in self.duplicates.items() if n > upper}
        self.lower = upper
        return result

    def coverage(self, epoch):
        cdef vector[int64_t] keys = self.frames.order
        cdef uint64_t counts[9]
        cdef uint64_t sizes[9]
        cdef int source
        cdef int64_t sn, cursor = self.lower + 1
        cdef Record record
        for source in range(9):
            counts[source] = sizes[source] = 0
        result = IntervalResult(
            epoch, "snapshot", received_unique_sn_count=self.frames.records.size(),
            duplicates=dict(self.duplicates), duplicate_frames=sum(self.duplicates.values()),
        )
        sort(keys.begin(), keys.end())
        for sn in keys:
            record = self.frames.records.at(sn)
            if sn > cursor:
                _detail(result, "missing", cursor, sn - 1)
            cursor = sn + 1
            counts[record.source] += 1
            sizes[record.source] += record.size
        if cursor <= self.upper:
            _detail(result, "missing", cursor, self.upper)
        for source in range(9):
            if counts[source]:
                result.received[source] = Received(counts[source], sizes[source])
        return result


class LogChecker(PythonLogChecker):
    _window_type = Window

    def feed(self, frame):
        cdef int source, added
        cdef int64_t raw, sn, last_sn, delta
        cdef Py_ssize_t size
        cdef Window window, candidate
        if self._result is not None or self._file.file.closed:
            raise RuntimeError("Cannot feed a finished or closed checker")
        if hasattr(frame, "payload_view"):
            src, sequence = frame.source_code, frame.raw_sn
            payload, length = frame.payload_view, frame.payload_size
        else:
            src, sequence = frame.source_code, frame.sequence_number
            payload, length = frame.payload, len(frame.payload)
        if not 0 <= src <= 8 or not 0 <= sequence < 16777216 or len(payload) != length:
            raise ValueError("Invalid frame metadata")
        # All INTERNAL frames, the undecided prefix, and legacy statistics use
        # the reference state machine, including its validation and reset rules.
        if self._per_source is not None or src == 0 or self._last is None:
            return PythonLogChecker.feed(self, frame)
        source, raw, size = src, sequence, length + 10
        last_sn = self._last.sn
        delta = (raw - last_sn + 8388608) % 16777216 - 8388608
        sn = last_sn + delta
        if delta == -8388608 or sn <= self._first.sn:
            return PythonLogChecker.feed(self, frame)
        count = self._observed.get(source)
        if count is None:
            count = self._observed[source] = Received()
        count.frames += 1
        count.bytes += size
        if source == 8:
            self._independent += 1
            return
        if self._settled_upper is not None and sn <= self._settled_upper:
            self._late += 1
            if self._flush_sn is not None and sn <= self._flush_sn:
                self._accounting_note(
                    "Expired arrivals in INIT-to-FLUSH range; archived counts are unchanged"
                )
            return
        if sn > self._highest:
            self._highest = sn
        window = self._open
        if sn <= window.lower:
            for candidate in self._windows:
                if candidate.lower < sn <= candidate.upper:
                    window = candidate
                    break
        added = window.record(sn, source, size, self._pending < self._max_pending)
        if added == 1:
            self._pending += 1
            if self._flush_sn is not None and sn <= self._flush_sn and 1 <= source <= 7:
                count = self._source_received.get(source)
                if count is None:
                    count = self._source_received[source] = Received()
                count.frames += 1
                count.bytes += size
        elif added == 2:
            self._note("Pending frame budget exceeded; exact coverage for this lifecycle is unavailable")
            if self._flush_sn is not None and sn <= self._flush_sn:
                self._accounting_note("Pending frame budget exceeded within INIT-to-FLUSH range")
