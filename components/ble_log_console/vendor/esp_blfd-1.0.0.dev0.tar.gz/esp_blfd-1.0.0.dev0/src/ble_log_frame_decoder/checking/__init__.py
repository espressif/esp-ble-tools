"""Feed validated blfd frames in reception order; finish to obtain statistics."""

try:
    from ._native import LogChecker
except ModuleNotFoundError as exc:
    if exc.name != f"{__name__}._native":
        raise
    from .checker import LogChecker
from .results import CheckResult, IntervalResult

__all__ = ["CheckResult", "IntervalResult", "LogChecker"]
