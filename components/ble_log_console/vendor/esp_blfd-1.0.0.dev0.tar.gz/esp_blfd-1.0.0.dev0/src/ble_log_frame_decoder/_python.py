from __future__ import annotations

import struct
from array import array
from collections.abc import Callable, Mapping
from typing import TypeAlias

FORMAT_V1_SUM32 = 0
FORMAT_V2_SUM32 = 1
FORMAT_V2_XOR32 = 2

FrameRecord: TypeAlias = tuple[int, int, int, int, int, int, int, int]
CandidateValidator: TypeAlias = Callable[[memoryview], bool]
CandidatePolicies: TypeAlias = Mapping[int, CandidateValidator | None]

_NEED_MORE = 1
_VALID = 2
_U32_MASK = 0xFFFFFFFF
_U16 = struct.Struct("<H")
_U32 = struct.Struct("<I")


def _validate_range(data: memoryview, start: int, end: int) -> None:
    if start < 0 or end < start or end > len(data):
        raise ValueError("checksum range is outside the buffer")


def sum32(data: memoryview, start: int, end: int) -> int:
    _validate_range(data, start, end)
    return sum(data[start:end]) & _U32_MASK


def xor32(data: memoryview, start: int, end: int) -> int:
    _validate_range(data, start, end)
    checksum = 0
    offset = start

    while offset + 4 <= end:
        (word,) = _U32.unpack_from(data, offset)
        checksum ^= word
        offset += 4

    shift = 0
    while offset < end:
        checksum ^= data[offset] << shift
        shift += 8
        offset += 1

    return checksum & _U32_MASK


def _build_checksum_prefix(data: memoryview, *, xor: bool) -> array[int]:
    prefix = array("I", [0])
    checksum = 0
    if xor:
        for offset, value in enumerate(data):
            checksum ^= value << (8 * (offset & 3))
            prefix.append(checksum)
    else:
        for value in data:
            checksum = (checksum + value) & _U32_MASK
            prefix.append(checksum)
    return prefix


def scan_frames(
    data: memoryview,
    format_code: int,
    max_frame_size: int,
    buffer_offset: int,
    initial_skipped_bytes: int,
    candidate_policies: CandidatePolicies | None = None,
) -> tuple[list[FrameRecord], int, int, int, int]:
    if not FORMAT_V1_SUM32 <= format_code <= FORMAT_V2_XOR32:
        raise ValueError("unknown frame format")
    if max_frame_size <= 0:
        raise ValueError("max_frame_size must be positive")
    if initial_skipped_bytes < 0:
        raise ValueError("initial_skipped_bytes must not be negative")

    frames: list[FrameRecord] = []
    cursor = 0
    pending_skipped_bytes = initial_skipped_bytes
    discarded_bytes = 0
    resync_count = 0
    incomplete_fallback: tuple[int, int, int] | None = None
    checksum_prefix: array[int] | None = None

    while cursor < len(data):
        remaining = len(data) - cursor
        status = 0
        checksum_mismatch = False
        frame_size = 0
        payload_start = 0
        payload_end = 0
        first_field = 0
        second_field = 0
        type_code = -1

        if remaining < 6:
            status = _NEED_MORE
        else:
            (payload_length,) = _U16.unpack_from(data, cursor)
            frame_size = 6 + payload_length + 4
            # Zero-payload frames are invalid for v1/v2 BLE log formats: the
            # firmware never writes them and both parsers reject them. Accepting
            # them lets resync consume phantom frames inside a real frame's tail.
            if payload_length and frame_size <= max_frame_size:
                if remaining < frame_size:
                    status = _NEED_MORE
                else:
                    payload_start = cursor + 6
                    payload_end = payload_start + payload_length
                    (received_checksum,) = _U32.unpack_from(data, payload_end)
                    if checksum_prefix is None:
                        checksum = xor32 if format_code == FORMAT_V2_XOR32 else sum32
                        calculated_checksum = checksum(data, cursor, payload_end)
                    elif format_code == FORMAT_V2_XOR32:
                        calculated_checksum = (
                            checksum_prefix[payload_end] ^ checksum_prefix[cursor]
                        )
                        shift = 8 * (cursor & 3)
                        if shift:
                            calculated_checksum = (
                                (calculated_checksum >> shift)
                                | (calculated_checksum << (32 - shift))
                            ) & _U32_MASK
                    else:
                        calculated_checksum = (
                            checksum_prefix[payload_end] - checksum_prefix[cursor]
                        ) & _U32_MASK
                    if received_checksum == calculated_checksum:
                        first_field = data[cursor + 2]
                        if format_code == FORMAT_V1_SUM32:
                            type_code = data[cursor + 3]
                            (second_field,) = _U16.unpack_from(data, cursor + 4)
                        else:
                            (frame_meta,) = _U32.unpack_from(data, cursor + 2)
                            first_field = frame_meta & 0xFF
                            second_field = frame_meta >> 8
                        status = _VALID
                    else:
                        checksum_mismatch = True

        if checksum_mismatch and checksum_prefix is None:
            checksum_prefix = _build_checksum_prefix(
                data,
                xor=format_code == FORMAT_V2_XOR32,
            )

        if status == _VALID and candidate_policies is not None:
            if first_field not in candidate_policies:
                status = 0
            else:
                candidate_validator = candidate_policies[first_field]
                if candidate_validator is not None:
                    payload_view = data[payload_start:payload_end].toreadonly()
                    try:
                        if not candidate_validator(payload_view):
                            status = 0
                    finally:
                        payload_view.release()

        if status == _NEED_MORE:
            if incomplete_fallback is None:
                incomplete_fallback = (
                    cursor,
                    pending_skipped_bytes,
                    discarded_bytes,
                )
            cursor += 1
            pending_skipped_bytes += 1
            discarded_bytes += 1
            continue

        if status != _VALID:
            cursor += 1
            pending_skipped_bytes += 1
            discarded_bytes += 1
            continue

        frames.append(
            (
                first_field,
                second_field,
                type_code,
                payload_start,
                payload_end,
                buffer_offset + cursor,
                frame_size,
                pending_skipped_bytes,
            )
        )
        if pending_skipped_bytes:
            resync_count += 1
            pending_skipped_bytes = 0
        cursor += frame_size
        incomplete_fallback = None

    if incomplete_fallback is not None:
        cursor, pending_skipped_bytes, discarded_bytes = incomplete_fallback

    return (
        frames,
        cursor,
        pending_skipped_bytes,
        discarded_bytes,
        resync_count,
    )
