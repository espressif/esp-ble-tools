from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from enum import StrEnum
from typing import TYPE_CHECKING, TypeAlias, cast

from ._release import ENABLE_EXTENSION

try:
    from ._native import (
        FORMAT_V1_SUM32,
        FORMAT_V2_SUM32,
        FORMAT_V2_XOR32,
        scan_frames,
    )
except ModuleNotFoundError as exc:
    if exc.name != f"{__package__}._native":
        raise
    from ._python import (
        FORMAT_V1_SUM32,
        FORMAT_V2_SUM32,
        FORMAT_V2_XOR32,
        scan_frames,
    )

if TYPE_CHECKING:
    _release_extension = None
elif ENABLE_EXTENSION:
    from . import _internal as _release_extension
else:
    _release_extension = None

_BLE_HEADER_SIZE = 6
_CHECKSUM_SIZE = 4
_MIN_PAYLOAD_SIZE = 1
_MAX_U16 = (1 << 16) - 1


class FrameFormat(StrEnum):
    BLE_LOG_V1_SUM32 = "ble-log-v1-sum32"
    BLE_LOG_V2_SUM32 = "ble-log-v2-sum32"
    BLE_LOG_V2_XOR32 = "ble-log-v2-xor32"


if not TYPE_CHECKING and _release_extension is not None:
    FrameFormat = _release_extension.FrameFormat  # pyright: ignore[reportAssignmentType]


@dataclass(frozen=True, slots=True)
class BleLogFrame:
    source_code: int
    sequence_number: int
    payload: bytes
    offset: int
    size: int
    skipped_bytes_before: int
    type_code: int | None = None


@dataclass(frozen=True, slots=True)
class FrameView:
    """Borrowed view of one committed v2 BLE log frame payload.

    ``payload_view`` is valid only for the synchronous ``FrameSink`` call that
    receives this object. Consumers must not retain it or a derived view.
    """

    source_code: int
    raw_sn: int
    payload_offset: int
    payload_size: int
    payload_view: memoryview = field(repr=False, compare=False, hash=False)


Frame: TypeAlias = BleLogFrame
FrameSink: TypeAlias = Callable[[FrameView], None]
ReadableBuffer: TypeAlias = bytes | bytearray | memoryview
_FrameRecord: TypeAlias = tuple[int, int, int, int, int, int, int, int]
_ScanResult: TypeAlias = tuple[list[_FrameRecord], int, int, int, int]
_CandidateValidator: TypeAlias = Callable[[memoryview], bool]
_CandidatePolicies: TypeAlias = Mapping[int, _CandidateValidator | None]
_Scanner: TypeAlias = Callable[..., _ScanResult]
_FrameBuilder: TypeAlias = Callable[[_FrameRecord, bytes], object]


@dataclass(frozen=True, slots=True)
class DecodeStats:
    bytes_received: int
    frames_decoded: int
    discarded_bytes: int
    resync_count: int
    trailing_bytes: int
    buffered_bytes: int
    peak_buffered_bytes: int


class FrameDecodeError(ValueError):
    def __init__(self, message: str, offset: int) -> None:
        super().__init__(f"{message} at byte offset {offset}")
        self.offset = offset


class IncompleteFrameError(FrameDecodeError):
    pass


@dataclass(frozen=True, slots=True)
class _FormatSupport:
    native_code: int
    minimum_size: int
    maximum_size: int
    scanner: _Scanner
    frame_builder: _FrameBuilder


def _build_ble_frame(record: _FrameRecord, payload: bytes) -> BleLogFrame:
    (
        source_code,
        sequence_number,
        type_code,
        _payload_start,
        _payload_end,
        offset,
        size,
        skipped_bytes_before,
    ) = record
    return BleLogFrame(
        source_code=source_code,
        sequence_number=sequence_number,
        payload=payload,
        offset=offset,
        size=size,
        skipped_bytes_before=skipped_bytes_before,
        type_code=type_code if type_code >= 0 else None,
    )


_BLE_FORMAT_SUPPORT = {
    FrameFormat.BLE_LOG_V1_SUM32: _FormatSupport(
        FORMAT_V1_SUM32,
        _BLE_HEADER_SIZE + _MIN_PAYLOAD_SIZE + _CHECKSUM_SIZE,
        _BLE_HEADER_SIZE + _MAX_U16 + _CHECKSUM_SIZE,
        scan_frames,
        _build_ble_frame,
    ),
    FrameFormat.BLE_LOG_V2_SUM32: _FormatSupport(
        FORMAT_V2_SUM32,
        _BLE_HEADER_SIZE + _MIN_PAYLOAD_SIZE + _CHECKSUM_SIZE,
        _BLE_HEADER_SIZE + _MAX_U16 + _CHECKSUM_SIZE,
        scan_frames,
        _build_ble_frame,
    ),
    FrameFormat.BLE_LOG_V2_XOR32: _FormatSupport(
        FORMAT_V2_XOR32,
        _BLE_HEADER_SIZE + _MIN_PAYLOAD_SIZE + _CHECKSUM_SIZE,
        _BLE_HEADER_SIZE + _MAX_U16 + _CHECKSUM_SIZE,
        scan_frames,
        _build_ble_frame,
    ),
}


def _get_format_support(format: FrameFormat) -> _FormatSupport:
    if not isinstance(format, FrameFormat):
        raise TypeError("format must be a FrameFormat")

    support = _BLE_FORMAT_SUPPORT.get(format)
    if support is not None:
        return support
    if _release_extension is not None:
        extension_support = _release_extension.get_format_support(format)
        if extension_support is not None:
            return _FormatSupport(
                *extension_support  # pyright: ignore[reportGeneralTypeIssues]
            )
    raise TypeError("format must be a FrameFormat")


def _as_byte_view(data: ReadableBuffer) -> memoryview:
    try:
        view = memoryview(data)
    except TypeError as exc:
        raise TypeError("data must support the buffer protocol") from exc

    if not view.c_contiguous:
        view.release()
        raise ValueError("data must be C-contiguous")

    if view.format == "B" and view.itemsize == 1 and view.ndim == 1:
        return view

    try:
        byte_view = view.cast("B")
    finally:
        view.release()
    return byte_view


def _resolve_max_frame_size(
    format: FrameFormat,
    support: _FormatSupport,
    max_frame_size: int | None,
) -> int:
    if max_frame_size is None:
        return support.maximum_size
    if isinstance(max_frame_size, bool) or not isinstance(max_frame_size, int):
        raise TypeError("max_frame_size must be an integer")
    if not support.minimum_size <= max_frame_size <= support.maximum_size:
        raise ValueError(
            f"max_frame_size for {format.value} must be between "
            f"{support.minimum_size} and {support.maximum_size}"
        )
    return max_frame_size


class FrameDecoder:
    """Incrementally decode one explicitly selected frame format."""

    def __init__(
        self,
        format: FrameFormat = FrameFormat.BLE_LOG_V2_XOR32,
        *,
        max_frame_size: int | None = None,
        candidate_policies: _CandidatePolicies | None = None,
    ) -> None:
        support = _get_format_support(format)
        policies = dict(candidate_policies) if candidate_policies is not None else None
        if policies is not None and format not in _BLE_FORMAT_SUPPORT:
            raise ValueError("candidate_policies is only supported for BLE log formats")
        if policies is not None and any(
            isinstance(source_code, bool) or not isinstance(source_code, int)
            for source_code in policies
        ):
            raise TypeError("candidate policy source codes must be integers")
        if policies is not None and any(
            not 0 <= source_code <= 0xFF for source_code in policies
        ):
            raise ValueError("candidate policy source codes must be between 0 and 255")
        if policies is not None and any(
            validator is not None and not callable(validator)
            for validator in policies.values()
        ):
            raise TypeError("candidate policies must be callables or None")
        self._format = format
        self.max_frame_size = _resolve_max_frame_size(
            format,
            support,
            max_frame_size,
        )
        self._native_format = support.native_code
        self._scanner = support.scanner
        self._frame_builder = support.frame_builder
        self._candidate_policies = policies
        self._buffer = bytearray()
        self._buffer_offset = 0
        self._pending_skipped_bytes = 0
        self._bytes_received = 0
        self._frames_decoded = 0
        self._discarded_bytes = 0
        self._resync_count = 0
        self._trailing_bytes = 0
        self._peak_buffered_bytes = 0
        self._finished = False
        self._failed = False

    @property
    def format(self) -> FrameFormat:
        return self._format

    @property
    def stats(self) -> DecodeStats:
        return DecodeStats(
            bytes_received=self._bytes_received,
            frames_decoded=self._frames_decoded,
            discarded_bytes=self._discarded_bytes,
            resync_count=self._resync_count,
            trailing_bytes=self._trailing_bytes,
            buffered_bytes=len(self._buffer),
            peak_buffered_bytes=self._peak_buffered_bytes,
        )

    def _feed(
        self,
        data: ReadableBuffer,
        sink: FrameSink | None,
    ) -> list[Frame]:
        if self._finished:
            raise RuntimeError("cannot feed a finished FrameDecoder")
        if self._failed:
            raise RuntimeError("cannot feed a failed FrameDecoder")

        chunk = _as_byte_view(data)
        try:
            if not chunk:
                return []
            self._buffer.extend(chunk)
            self._bytes_received += len(chunk)
            self._peak_buffered_bytes = max(
                self._peak_buffered_bytes,
                len(self._buffer),
            )
        finally:
            chunk.release()

        frames: list[Frame] = []
        view = memoryview(self._buffer)
        try:
            if self._candidate_policies is None:
                scan_result = self._scanner(
                    view,
                    self._native_format,
                    self.max_frame_size,
                    self._buffer_offset,
                    self._pending_skipped_bytes,
                )
            else:
                scan_result = self._scanner(
                    view,
                    self._native_format,
                    self.max_frame_size,
                    self._buffer_offset,
                    self._pending_skipped_bytes,
                    self._candidate_policies,
                )
            (
                records,
                consumed_bytes,
                pending_skipped_bytes,
                discarded_bytes,
                resync_count,
            ) = scan_result
            for record in records:
                payload_start = record[3]
                payload_end = record[4]
                if sink is None:
                    payload = bytes(view[payload_start:payload_end])
                    frames.append(cast(Frame, self._frame_builder(record, payload)))
                    continue

                payload_view = view[payload_start:payload_end].toreadonly()
                try:
                    sink(
                        FrameView(
                            source_code=record[0],
                            raw_sn=record[1],
                            payload_offset=self._buffer_offset + payload_start,
                            payload_size=payload_end - payload_start,
                            payload_view=payload_view,
                        )
                    )
                except Exception:
                    self._failed = True
                    raise
                finally:
                    payload_view.release()
        finally:
            view.release()

        self._pending_skipped_bytes = pending_skipped_bytes
        self._discarded_bytes += discarded_bytes
        self._resync_count += resync_count
        self._frames_decoded += len(records)
        if consumed_bytes:
            del self._buffer[:consumed_bytes]
            self._buffer_offset += consumed_bytes

        return frames

    def feed(self, data: ReadableBuffer) -> list[Frame]:
        """Decode frames with owned payload bytes."""
        return self._feed(data, None)

    def feed_into(self, data: ReadableBuffer, *, sink: FrameSink) -> None:
        """Emit borrowed v2 XOR32 frame views synchronously into ``sink``."""
        if self._format is not FrameFormat.BLE_LOG_V2_XOR32:
            raise ValueError("feed_into is only supported for BLE log v2 XOR32")
        if not callable(sink):
            raise TypeError("sink must be callable")
        self._feed(data, sink)

    def finish(self, *, require_complete: bool = False) -> DecodeStats:
        if self._failed:
            raise RuntimeError("cannot finish a failed FrameDecoder")
        trailing_bytes = self._trailing_bytes if self._finished else len(self._buffer)
        if require_complete and trailing_bytes:
            offset = (
                self._buffer_offset - trailing_bytes
                if self._finished
                else self._buffer_offset
            )
            raise IncompleteFrameError("incomplete frame", offset)

        if not self._finished:
            self._trailing_bytes = len(self._buffer)
            self._buffer_offset += len(self._buffer)
            self._buffer.clear()
            self._pending_skipped_bytes = 0
            self._finished = True
        return self.stats
