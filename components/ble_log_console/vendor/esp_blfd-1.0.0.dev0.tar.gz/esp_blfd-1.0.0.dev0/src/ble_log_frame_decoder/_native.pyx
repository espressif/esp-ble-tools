# cython: language_level=3

import builtins
from array import array

from libc.stdint cimport uint16_t, uint32_t

cimport cython


FORMAT_V1_SUM32 = 0
FORMAT_V2_SUM32 = 1
FORMAT_V2_XOR32 = 2

cdef int _NEED_MORE = 1
cdef int _VALID = 2


@cython.boundscheck(False)
@cython.wraparound(False)
cdef inline uint16_t _read_u16(
    const unsigned char[::1] data,
    Py_ssize_t offset,
) noexcept nogil:
    return (
        <uint16_t>data[offset]
        | (<uint16_t>data[offset + 1] << 8)
    )


@cython.boundscheck(False)
@cython.wraparound(False)
cdef inline uint32_t _read_u32(
    const unsigned char[::1] data,
    Py_ssize_t offset,
) noexcept nogil:
    return (
        <uint32_t>data[offset]
        | (<uint32_t>data[offset + 1] << 8)
        | (<uint32_t>data[offset + 2] << 16)
        | (<uint32_t>data[offset + 3] << 24)
    )


@cython.boundscheck(False)
@cython.wraparound(False)
cdef uint32_t _sum32_unchecked(
    const unsigned char[::1] data,
    Py_ssize_t start,
    Py_ssize_t end,
) noexcept nogil:
    cdef uint32_t checksum = 0
    cdef Py_ssize_t offset

    for offset in range(start, end):
        checksum += data[offset]
    return checksum


@cython.boundscheck(False)
@cython.wraparound(False)
cdef uint32_t _xor32_unchecked(
    const unsigned char[::1] data,
    Py_ssize_t start,
    Py_ssize_t end,
) noexcept nogil:
    cdef uint32_t checksum = 0
    cdef uint32_t word
    cdef Py_ssize_t offset = start
    cdef int shift

    while offset + 4 <= end:
        checksum ^= _read_u32(data, offset)
        offset += 4

    shift = 0
    while offset < end:
        word = <uint32_t>data[offset]
        checksum ^= word << shift
        shift += 8
        offset += 1

    return checksum


cdef void _validate_range(
    const unsigned char[::1] data,
    Py_ssize_t start,
    Py_ssize_t end,
) except *:
    if start < 0 or end < start or end > data.shape[0]:
        raise ValueError("checksum range is outside the buffer")


cpdef uint32_t sum32(
    const unsigned char[::1] data,
    Py_ssize_t start,
    Py_ssize_t end,
):
    cdef uint32_t checksum

    if data is None:
        raise TypeError("data must not be None")
    _validate_range(data, start, end)
    with nogil:
        checksum = _sum32_unchecked(data, start, end)
    return checksum


cpdef uint32_t xor32(
    const unsigned char[::1] data,
    Py_ssize_t start,
    Py_ssize_t end,
):
    cdef uint32_t checksum

    if data is None:
        raise TypeError("data must not be None")
    _validate_range(data, start, end)
    with nogil:
        checksum = _xor32_unchecked(data, start, end)
    return checksum


def scan_frames(
    const unsigned char[::1] data not None,
    int format_code,
    Py_ssize_t max_frame_size,
    Py_ssize_t buffer_offset,
    Py_ssize_t initial_skipped_bytes,
    dict candidate_policies=None,
):
    """Scan a buffer and return valid frame metadata plus recovery state."""
    cdef Py_ssize_t data_length = data.shape[0]
    cdef Py_ssize_t cursor = 0
    cdef Py_ssize_t remaining
    cdef Py_ssize_t frame_size
    cdef Py_ssize_t payload_start
    cdef Py_ssize_t payload_end
    cdef Py_ssize_t pending_skipped_bytes = initial_skipped_bytes
    cdef Py_ssize_t discarded_bytes = 0
    cdef Py_ssize_t resync_count = 0
    cdef Py_ssize_t fallback_cursor = -1
    cdef Py_ssize_t fallback_skipped_bytes = 0
    cdef Py_ssize_t fallback_discarded_bytes = 0
    cdef Py_ssize_t prefix_offset
    cdef uint16_t payload_length
    cdef uint16_t sequence_number_v1
    cdef uint32_t frame_meta
    cdef uint32_t received_checksum
    cdef uint32_t calculated_checksum
    cdef unsigned char source_code
    cdef unsigned char type_code
    cdef int status
    cdef bint is_v1
    cdef bint is_xor
    cdef bint has_checksum_prefix = False
    cdef bint checksum_mismatch
    cdef int shift
    cdef list frames = []
    cdef object candidate_validator
    cdef object payload_view
    cdef object checksum_prefix_array = None
    cdef uint32_t[::1] checksum_prefix

    if format_code < FORMAT_V1_SUM32 or format_code > FORMAT_V2_XOR32:
        raise ValueError("unknown native frame format")
    if max_frame_size <= 0:
        raise ValueError("max_frame_size must be positive")
    if initial_skipped_bytes < 0:
        raise ValueError("initial_skipped_bytes must not be negative")

    is_v1 = format_code == FORMAT_V1_SUM32
    is_xor = format_code == FORMAT_V2_XOR32

    while cursor < data_length:
        status = 0
        checksum_mismatch = False
        remaining = data_length - cursor
        frame_size = 0
        payload_start = 0
        payload_end = 0
        source_code = 0
        type_code = 0
        sequence_number_v1 = 0
        frame_meta = 0
        if remaining < 6:
            status = _NEED_MORE
        else:
            payload_length = _read_u16(data, cursor)
            frame_size = 6 + payload_length + 4
            # Zero-payload frames are invalid for v1/v2 BLE log formats: the
            # firmware never writes them and both parsers reject them. Accepting
            # them lets resync consume phantom frames inside a real frame's tail.
            if payload_length and frame_size <= max_frame_size:
                if remaining < frame_size:
                    status = _NEED_MORE
                else:
                    payload_start = cursor + 6
                    payload_end = payload_start + payload_length
                    received_checksum = _read_u32(data, payload_end)
                    if is_xor:
                        if has_checksum_prefix:
                            calculated_checksum = (
                                checksum_prefix[payload_end]
                                ^ checksum_prefix[cursor]
                            )
                            shift = 8 * (cursor & 3)
                            if shift:
                                calculated_checksum = (
                                    (calculated_checksum >> shift)
                                    | (calculated_checksum << (32 - shift))
                                )
                        else:
                            calculated_checksum = _xor32_unchecked(
                                data, cursor, payload_end
                            )
                    else:
                        if has_checksum_prefix:
                            calculated_checksum = (
                                checksum_prefix[payload_end]
                                - checksum_prefix[cursor]
                            )
                        else:
                            calculated_checksum = _sum32_unchecked(
                                data, cursor, payload_end
                            )

                    if received_checksum == calculated_checksum:
                        source_code = data[cursor + 2]
                        if is_v1:
                            type_code = data[cursor + 3]
                            sequence_number_v1 = _read_u16(data, cursor + 4)
                        else:
                            frame_meta = _read_u32(data, cursor + 2)
                        status = _VALID
                    else:
                        checksum_mismatch = True

        if checksum_mismatch and not has_checksum_prefix:
            checksum_prefix_array = array("I", [0]) * (data_length + 1)
            checksum_prefix = checksum_prefix_array
            calculated_checksum = 0
            if is_xor:
                for prefix_offset in range(data_length):
                    calculated_checksum ^= (
                        <uint32_t>data[prefix_offset]
                        << (8 * (prefix_offset & 3))
                    )
                    checksum_prefix[prefix_offset + 1] = calculated_checksum
            else:
                for prefix_offset in range(data_length):
                    calculated_checksum += data[prefix_offset]
                    checksum_prefix[prefix_offset + 1] = calculated_checksum
            has_checksum_prefix = True

        if status == _VALID and candidate_policies is not None:
            candidate_validator = candidate_policies.get(source_code, False)
            if candidate_validator is False:
                status = 0
            elif candidate_validator is not None:
                payload_view = builtins.memoryview(
                    data[payload_start:payload_end]
                ).toreadonly()
                try:
                    if not candidate_validator(payload_view):
                        status = 0
                finally:
                    payload_view.release()

        if status == _NEED_MORE:
            if fallback_cursor < 0:
                fallback_cursor = cursor
                fallback_skipped_bytes = pending_skipped_bytes
                fallback_discarded_bytes = discarded_bytes
            cursor += 1
            pending_skipped_bytes += 1
            discarded_bytes += 1
            continue

        if status != _VALID:
            cursor += 1
            pending_skipped_bytes += 1
            discarded_bytes += 1
            continue

        if is_v1:
            frames.append(
                (
                    source_code,
                    sequence_number_v1,
                    type_code,
                    payload_start,
                    payload_end,
                    buffer_offset + cursor,
                    frame_size,
                    pending_skipped_bytes,
                )
            )
        else:
            frames.append(
                (
                    frame_meta & 0xFF,
                    frame_meta >> 8,
                    -1,
                    payload_start,
                    payload_end,
                    buffer_offset + cursor,
                    frame_size,
                    pending_skipped_bytes,
                )
            )

        if pending_skipped_bytes:
            resync_count += 1
            pending_skipped_bytes = 0
        cursor += frame_size
        fallback_cursor = -1

    if fallback_cursor >= 0:
        cursor = fallback_cursor
        pending_skipped_bytes = fallback_skipped_bytes
        discarded_bytes = fallback_discarded_bytes

    return (
        frames,
        cursor,
        pending_skipped_bytes,
        discarded_bytes,
        resync_count,
    )
