from collections.abc import Callable
from typing import TypeAlias

_FrameRecord: TypeAlias = tuple[int, int, int, int, int, int, int, int]

FORMAT_V1_SUM32: int
FORMAT_V2_SUM32: int
FORMAT_V2_XOR32: int

def sum32(data: memoryview, start: int, end: int) -> int: ...
def xor32(data: memoryview, start: int, end: int) -> int: ...
def scan_frames(
    data: memoryview,
    format_code: int,
    max_frame_size: int,
    buffer_offset: int,
    initial_skipped_bytes: int,
    candidate_policies: dict[int, Callable[[memoryview], bool] | None] | None = ...,
) -> tuple[list[_FrameRecord], int, int, int, int]: ...
