"""Pure payload decoding for BLE log INTERNAL source frames.

This module owns the wire-format knowledge of the INTERNAL (source code 0)
subtypes defined by ``ble_log.h`` in esp-idf
(``components/bt/common/ble_log/include/ble_log.h``): the subtype enum, the
record dataclasses with their ``from_payload`` parsers, the shared
source-code / version-info / chip-model tables, and the SNAPSHOT /
TASK_BINDING shape validators used by frame candidate policies.

It is stdlib-only and side-effect free: payload bytes in, decoded records
out. Logging, ordering, and file output stay with the consumers (v2 parser,
log checker, console).
"""

from __future__ import annotations

import struct
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum, IntEnum
from typing import Self, TypeAlias

CandidateValidator: TypeAlias = Callable[[bytes | memoryview], bool]

# ---------------------------------------------------------------------------
# Outer frame source codes (ble_log_src_t)
# ---------------------------------------------------------------------------


class BleLogSource(IntEnum):
    """BLE Log source code enumeration."""

    # Internal
    INTERNAL = 0

    # Custom
    CUSTOM = 1

    # BLE Stack
    LL_TASK = 2
    LL_HCI = 3
    LL_ISR = 4
    HOST = 5
    HCI = 6
    ENCODE = 7
    REDIR = 8

    MAX = 9


# Source code to string mapping for display purposes
SOURCE_CODE_STR_MAP = {
    BleLogSource.INTERNAL: "Internal",
    BleLogSource.CUSTOM: "Custom",
    BleLogSource.LL_TASK: "LL Task",
    BleLogSource.LL_HCI: "LL HCI",
    BleLogSource.LL_ISR: "LL ISR",
    BleLogSource.HOST: "Host",
    BleLogSource.HCI: "HCI",
    BleLogSource.ENCODE: "Encode",
    BleLogSource.REDIR: "Redir",
}


def get_source_name(source_code: int) -> str:
    """Get human-readable name for source code."""
    try:
        ble_source = BleLogSource(source_code)
        return SOURCE_CODE_STR_MAP.get(ble_source, f"Unknown({source_code})")
    except ValueError:
        return f"Unknown({source_code})"


# ---------------------------------------------------------------------------
# INTERNAL subtypes and display names
# ---------------------------------------------------------------------------


class InternalSource(Enum):
    INIT_DONE = 0
    TIMESTAMP = 1
    ENHANCED_STAT = 2
    INFO = 3
    FLUSH = 4
    BUF_UTIL = 5
    FINAL_STAT = 6
    VERSION_INFO = 7
    SNAPSHOT = 8
    TASK_BINDING = 9


INTERNAL_SOURCE_NAMES = {
    InternalSource.INIT_DONE: "Initialization Done",
    InternalSource.TIMESTAMP: "Timestamp",
    InternalSource.ENHANCED_STAT: "Enhanced Statistics",
    InternalSource.INFO: "Information",
    InternalSource.FLUSH: "Flush Event",
    InternalSource.BUF_UTIL: "Buffer Utilization",
    InternalSource.FINAL_STAT: "Final Statistics",
    InternalSource.VERSION_INFO: "Version Information",
    InternalSource.SNAPSHOT: "Snapshot",
    InternalSource.TASK_BINDING: "Task Bindings",
}

BUFFER_UTIL_POOL_NAMES = {
    0: "COMMON_TASK",
    1: "COMMON_ISR",
    2: "LL",
    3: "REDIR",
}

# ---------------------------------------------------------------------------
# Fixed payload lengths and candidate validation
# ---------------------------------------------------------------------------

_INTERNAL_SOURCE = 0
_SOURCE_COUNT = 9  # INTERNAL through REDIR
_INTERNAL_SUBTYPE_OFFSET = 4  # After the uint32 timestamp

# FINAL_STAT subtype constant, shared with the checker and parser.
FINAL_STAT = 6
SNAPSHOT = 8
TASK_BINDING = 9

# SNAPSHOT reason_flags bits, not record subtypes.
INIT = 1 << 0
PERIODIC = 1 << 1
FLUSH = 1 << 2
TS_VALID = 1 << 3

# Byte offsets from the start of the SNAPSHOT payload (including timestamp).
_SNAPSHOT_ANCHOR_OFFSET = 7  # uint24, after timestamp/subtype/reason_flags
_SNAPSHOT_VERSION_OFFSET = 10  # 58-byte embedded VERSION_INFO
_SNAPSHOT_CLOCK_OFFSET = 68  # uint8 io_level + uint32 LC / ESP / OS timestamps
_SNAPSHOT_POOL_OFFSET = 81  # uint8 total, reserve, inflight, peak
_SNAPSHOT_STATS_OFFSET = 85  # Seven core-source entries
_SOURCE_STAT_SIZE = 12  # uint32 written frames, lost frames, written bytes
SNAPSHOT_PAYLOAD_SIZE = 169

_TASK_BINDING_RECORD_SIZE = 19  # subtype + task_id + 17-byte NUL-padded name
_FINAL_STAT_STATS_OFFSET = 6  # After timestamp, subtype and source count
_FINAL_STAT_ENTRY_SIZE = 17  # uint8 source + uint32 written/lost frames and bytes

INTERNAL_PAYLOAD_LENGTHS = {
    0: 6,  # INIT_DONE
    1: 18,  # TIMESTAMP
    2: 22,  # ENHANCED_STAT
    3: 6,  # INFO
    4: 6,  # FLUSH
    5: 8,  # BUF_UTIL
    FINAL_STAT: 159,
    7: 62,  # VERSION_INFO
}


def is_snapshot(payload: bytes | memoryview) -> bool:
    return (
        len(payload) == SNAPSHOT_PAYLOAD_SIZE
        and payload[_INTERNAL_SUBTYPE_OFFSET] == SNAPSHOT
    )


def is_task_binding(payload: bytes | memoryview) -> bool:
    # One timestamp followed by one or more 19-byte binding records.
    return (
        len(payload) >= _INTERNAL_SUBTYPE_OFFSET + _TASK_BINDING_RECORD_SIZE
        and (len(payload) - _INTERNAL_SUBTYPE_OFFSET) % _TASK_BINDING_RECORD_SIZE == 0
        and all(
            payload[i] == TASK_BINDING
            for i in range(
                _INTERNAL_SUBTYPE_OFFSET, len(payload), _TASK_BINDING_RECORD_SIZE
            )
        )
    )


def is_valid_internal_candidate(payload: bytes | memoryview) -> bool:
    if len(payload) <= _INTERNAL_SUBTYPE_OFFSET:
        return False
    subtype = payload[_INTERNAL_SUBTYPE_OFFSET]
    if subtype == SNAPSHOT:
        return is_snapshot(payload)
    if subtype == TASK_BINDING:
        return is_task_binding(payload)
    return INTERNAL_PAYLOAD_LENGTHS.get(subtype) == len(payload)


FRAME_CANDIDATE_POLICIES: dict[int, CandidateValidator | None] = {
    source: is_valid_internal_candidate if source == _INTERNAL_SOURCE else None
    for source in range(_SOURCE_COUNT)
}


def is_valid_frame_candidate(source_code: int, payload: bytes | memoryview) -> bool:
    if source_code not in FRAME_CANDIDATE_POLICIES:
        return False
    validator = FRAME_CANDIDATE_POLICIES[source_code]
    return validator is None or validator(payload)


# ---------------------------------------------------------------------------
# Shared version-info model
# ---------------------------------------------------------------------------

_CHIP_MODEL_NAMES = {
    1: "ESP32",
    2: "ESP32S2",
    5: "ESP32C3",
    9: "ESP32S3",
    12: "ESP32C2",
    13: "ESP32C6",
    16: "ESP32H2",
    18: "ESP32P4",
    20: "ESP32C61",
    23: "ESP32C5",
    25: "ESP32H21",
    28: "ESP32H4",
    32: "ESP32S31",
    999: "POSIX_LINUX",
}


@dataclass
class BleLogVersionInfo:
    """Decoded build metadata shared by the parser context and presentation."""

    log_os_ts: int
    version: int
    idf_commit: str
    controller_commit: str
    btdm_common_commit: str
    mesh_commit: str
    audio_commit: str
    chip_model: int
    chip_revision: int

    @property
    def chip_name(self) -> str:
        return _CHIP_MODEL_NAMES.get(self.chip_model, f"UNKNOWN({self.chip_model})")

    @property
    def chip_revision_str(self) -> str:
        # esp_chip_info_t stores revisions as MXX (major * 100 + minor).
        return f"v{self.chip_revision // 100}.{self.chip_revision % 100:02d}"


def _decode_commit(raw: bytes) -> str:
    """Decode a fixed-width hexadecimal commit without terminal controls."""
    text = raw.rstrip(b"\x00")
    if not text:
        return "unknown"
    if b"\x00" in text or any(byte not in b"0123456789abcdefABCDEF" for byte in text):
        return f"invalid({raw.hex()})"
    return text.decode("ascii")


@dataclass
class InternalLogInfo:
    log_os_ts: int
    source: InternalSource
    version: int

    PAYLOAD_LEN = 6
    ALLOWED_SOURCES = (
        InternalSource.INFO,
        InternalSource.FLUSH,
        InternalSource.INIT_DONE,
    )

    @classmethod
    def from_payload(cls, payload: bytes | memoryview) -> Self:
        if len(payload) != cls.PAYLOAD_LEN:
            raise ValueError(
                f"Invalid payload length for InternalLogInitDone: {len(payload)}"
            )

        log_os_ts, source_id, version = struct.unpack("<IBB", payload)
        return cls(
            log_os_ts=log_os_ts, source=InternalSource(source_id), version=version
        )

    @staticmethod
    def is_info_log(source: InternalSource) -> bool:
        return source in InternalLogInfo.ALLOWED_SOURCES


_VERSION_INFO_STRUCT = struct.Struct("<IBB12s10s10s10s10sHH")
VERSION_INFO_PAYLOAD_LEN = _VERSION_INFO_STRUCT.size


def parse_version_info_payload(payload: bytes | memoryview) -> BleLogVersionInfo:
    """Decode the VERSION_INFO wire payload into the shared result model."""
    if len(payload) != VERSION_INFO_PAYLOAD_LEN:
        raise ValueError(f"Invalid payload length for VERSION_INFO: {len(payload)}")

    (
        log_os_ts,
        source_id,
        version,
        idf_commit,
        controller_commit,
        btdm_common_commit,
        mesh_commit,
        audio_commit,
        chip_model,
        chip_revision,
    ) = _VERSION_INFO_STRUCT.unpack(payload)
    if source_id != InternalSource.VERSION_INFO.value:
        raise ValueError(f"Invalid internal source for VERSION_INFO: {source_id}")
    if version < 6:
        raise ValueError(f"Invalid BLE Log version for VERSION_INFO: {version}")

    return BleLogVersionInfo(
        log_os_ts=log_os_ts,
        version=version,
        idf_commit=_decode_commit(idf_commit),
        controller_commit=_decode_commit(controller_commit),
        btdm_common_commit=_decode_commit(btdm_common_commit),
        mesh_commit=_decode_commit(mesh_commit),
        audio_commit=_decode_commit(audio_commit),
        chip_model=chip_model,
        chip_revision=chip_revision,
    )


# ---------------------------------------------------------------------------
# Record dataclasses
# ---------------------------------------------------------------------------


@dataclass
class InternalLogTimestamp:
    log_os_ts: int
    source: InternalSource
    io_level: int
    lc_ts: int
    esp_ts: int
    os_ts: int

    @classmethod
    def from_payload(cls, payload: bytes | memoryview) -> Self:
        expected_len = 18

        # Validate payload length
        if len(payload) != expected_len:
            raise ValueError(
                f"Invalid payload length for InternalLogTimestamp: {len(payload)}"
            )

        # Unpack timestamp
        (
            log_os_ts,
            source_id,
            io_level,
            lc_ts,
            esp_ts,
            os_ts,
        ) = struct.unpack("<IBBIII", payload)

        return cls(
            log_os_ts=log_os_ts,
            source=InternalSource(source_id),
            io_level=io_level,
            lc_ts=lc_ts,
            esp_ts=esp_ts,
            os_ts=os_ts,
        )


@dataclass
class InternalLogBufferUtil:
    log_os_ts: int
    source: InternalSource
    lbm_id: int
    trans_cnt: int
    inflight_peak: int

    PAYLOAD_LEN = 8

    @property
    def pool(self) -> int:
        return (self.lbm_id >> 4) & 0x0F

    @property
    def index(self) -> int:
        return self.lbm_id & 0x0F

    @classmethod
    def from_payload(cls, payload: bytes | memoryview) -> Self:
        if len(payload) != cls.PAYLOAD_LEN:
            raise ValueError(
                f"Invalid payload length for InternalLogBufferUtil: {len(payload)}"
            )

        log_os_ts, source_id, lbm_id, trans_cnt, inflight_peak = struct.unpack(
            "<IBBBB", payload
        )
        if source_id != InternalSource.BUF_UTIL.value:
            raise ValueError(
                f"Invalid internal source for InternalLogBufferUtil: {source_id}"
            )

        return cls(
            log_os_ts=log_os_ts,
            source=InternalSource.BUF_UTIL,
            lbm_id=lbm_id,
            trans_cnt=trans_cnt,
            inflight_peak=inflight_peak,
        )


@dataclass
class EnhancedStat:
    log_source: BleLogSource
    written_frame_cnt: int
    lost_frame_cnt: int
    written_bytes_cnt: int
    lost_bytes_cnt: int


@dataclass
class InternalLogEnhancedStat:
    log_os_ts: int
    source: InternalSource
    enhanced_stat: EnhancedStat

    PAYLOAD_LEN = 22

    @classmethod
    def from_payload(cls, payload: bytes | memoryview) -> Self:
        if len(payload) != cls.PAYLOAD_LEN:
            raise ValueError(
                f"Invalid payload length for InternalLogEnhancedStat: {len(payload)}"
            )

        (
            log_os_ts,
            source_id,
            log_source_id,
            written_frame_cnt,
            lost_frame_cnt,
            written_bytes_cnt,
            lost_bytes_cnt,
        ) = struct.unpack("<IBBIIII", payload)
        return cls(
            log_os_ts=log_os_ts,
            source=InternalSource(source_id),
            enhanced_stat=EnhancedStat(
                log_source=BleLogSource(log_source_id),
                written_frame_cnt=written_frame_cnt,
                lost_frame_cnt=lost_frame_cnt,
                written_bytes_cnt=written_bytes_cnt,
                lost_bytes_cnt=lost_bytes_cnt,
            ),
        )


@dataclass
class FinalStatEntry:
    log_source: BleLogSource
    written_frame_cnt: int
    lost_frame_cnt: int
    written_bytes_cnt: int
    lost_bytes_cnt: int


@dataclass
class InternalLogFinalStat:
    log_os_ts: int
    source: InternalSource
    src_cnt: int
    entries: list[FinalStatEntry]

    HEADER_STRUCT = struct.Struct("<IBB")
    ENTRY_STRUCT = struct.Struct("<BIIII")
    PAYLOAD_LEN = HEADER_STRUCT.size + BleLogSource.MAX.value * ENTRY_STRUCT.size

    @classmethod
    def from_payload(cls, payload: bytes | memoryview) -> Self:
        if len(payload) != cls.PAYLOAD_LEN:
            raise ValueError(
                f"Invalid payload length for InternalLogFinalStat: {len(payload)}"
            )

        log_os_ts, source_id, src_cnt = cls.HEADER_STRUCT.unpack_from(payload)
        if source_id != InternalSource.FINAL_STAT.value:
            raise ValueError(
                f"Invalid internal source for InternalLogFinalStat: {source_id}"
            )
        if src_cnt != BleLogSource.MAX.value:
            raise ValueError(
                f"Invalid source count for InternalLogFinalStat: {src_cnt}"
            )

        entries: list[FinalStatEntry] = []
        for index in range(src_cnt):
            offset = cls.HEADER_STRUCT.size + index * cls.ENTRY_STRUCT.size
            (
                log_source_id,
                written_frame_cnt,
                lost_frame_cnt,
                written_bytes_cnt,
                lost_bytes_cnt,
            ) = cls.ENTRY_STRUCT.unpack_from(payload, offset)
            if log_source_id >= BleLogSource.MAX.value:
                raise ValueError(
                    "Invalid source code for InternalLogFinalStat "
                    f"entry {index}: {log_source_id}"
                )
            entries.append(
                FinalStatEntry(
                    log_source=BleLogSource(log_source_id),
                    written_frame_cnt=written_frame_cnt,
                    lost_frame_cnt=lost_frame_cnt,
                    written_bytes_cnt=written_bytes_cnt,
                    lost_bytes_cnt=lost_bytes_cnt,
                )
            )

        return cls(
            log_os_ts=log_os_ts,
            source=InternalSource.FINAL_STAT,
            src_cnt=src_cnt,
            entries=entries,
        )


def get_internal_source_type(payload: bytes | memoryview) -> InternalSource:
    OS_TS_LEN = 4
    if len(payload) < OS_TS_LEN + 1:
        raise ValueError("Payload too short to determine internal log type")

    source_id = payload[OS_TS_LEN]
    try:
        source = InternalSource(source_id)
    except ValueError:
        raise ValueError(f"Unknown internal source ID: {source_id}")

    return source


# ---------------------------------------------------------------------------
# SNAPSHOT and TASK_BINDING
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class SourceStat:
    written_frame_cnt: int
    lost_frame_cnt: int
    written_bytes_cnt: int


@dataclass(frozen=True, slots=True)
class Snapshot:
    timestamp: int
    reason_flags: int
    anchor_count: int
    version_info: bytes
    io_level: int
    lc_ts: int
    esp_ts: int
    os_ts: int
    pool: tuple[int, int, int, int]
    stats: tuple[SourceStat, ...]


def parse_snapshot(payload: bytes | memoryview) -> Snapshot:
    if not is_snapshot(payload):
        raise ValueError("Invalid SNAPSHOT payload shape")
    timestamp, _, reason = struct.unpack_from("<IBH", payload)
    io_level, lc_ts, esp_ts, os_ts = struct.unpack_from(
        "<BIII", payload, _SNAPSHOT_CLOCK_OFFSET
    )
    return Snapshot(
        timestamp=timestamp,
        reason_flags=reason,
        anchor_count=int.from_bytes(
            payload[_SNAPSHOT_ANCHOR_OFFSET:_SNAPSHOT_VERSION_OFFSET], "little"
        ),
        version_info=bytes(payload[_SNAPSHOT_VERSION_OFFSET:_SNAPSHOT_CLOCK_OFFSET]),
        io_level=io_level,
        lc_ts=lc_ts,
        esp_ts=esp_ts,
        os_ts=os_ts,
        pool=struct.unpack_from("<4B", payload, _SNAPSHOT_POOL_OFFSET),
        stats=tuple(
            SourceStat(*struct.unpack_from("<III", payload, offset))
            for offset in range(
                _SNAPSHOT_STATS_OFFSET, SNAPSHOT_PAYLOAD_SIZE, _SOURCE_STAT_SIZE
            )
        ),
    )


def parse_snapshot_version_info(snapshot: Snapshot) -> BleLogVersionInfo:
    """Decode the VERSION_INFO block embedded in a SNAPSHOT frame.

    The 58-byte block is the VERSION_INFO wire payload without its leading
    ``uint32`` timestamp; the SNAPSHOT timestamp takes that slot.
    """
    return parse_version_info_payload(
        struct.pack("<I", snapshot.timestamp) + snapshot.version_info
    )


@dataclass(frozen=True, slots=True)
class FinalStat:
    timestamp: int
    stats: dict[int, dict[str, int]]


def parse_final_stat(payload: bytes | memoryview) -> FinalStat:
    if len(payload) != INTERNAL_PAYLOAD_LENGTHS[FINAL_STAT]:
        raise ValueError("Invalid FINAL_STAT payload shape")
    timestamp, subtype, source_count = struct.unpack_from("<IBB", payload)
    if subtype != FINAL_STAT or source_count != _SOURCE_COUNT:
        raise ValueError("Invalid FINAL_STAT payload shape")
    stats = {}
    for offset in range(_FINAL_STAT_STATS_OFFSET, len(payload), _FINAL_STAT_ENTRY_SIZE):
        source, written, lost, written_bytes, lost_bytes = struct.unpack_from(
            "<BIIII", payload, offset
        )
        if source >= _SOURCE_COUNT or source in stats:
            raise ValueError("Invalid or duplicate FINAL_STAT source")
        stats[source] = {
            "written_frame_cnt": written,
            "lost_frame_cnt": lost,
            "written_bytes_cnt": written_bytes,
            "lost_bytes_cnt": lost_bytes,
        }
    return FinalStat(timestamp, stats)


def task_names_from_binding(payload: bytes | memoryview) -> dict[int, str]:
    """Decode valid bindings into printable task names; 0xff is never bound."""
    names = {}
    if not is_task_binding(payload):
        return names
    for offset in range(4, len(payload), _TASK_BINDING_RECORD_SIZE):
        task_id = payload[offset + 1]
        name = (
            bytes(payload[offset + 2 : offset + 19])
            .split(b"\0", 1)[0]
            .decode("utf-8", "replace")
        )
        if task_id != 0xFF and name:
            names[task_id] = "".join(
                char if char.isprintable() else "?" for char in name
            )
    return names
