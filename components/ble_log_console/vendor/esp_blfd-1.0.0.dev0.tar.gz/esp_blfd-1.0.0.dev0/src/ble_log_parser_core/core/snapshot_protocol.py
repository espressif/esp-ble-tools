"""Compatibility import; implementation is provided by esp-blfd."""

import sys
from typing import TYPE_CHECKING, Any

import ble_log_frame_decoder.analysis.core.snapshot_protocol as _implementation

sys.modules[__name__] = _implementation

if TYPE_CHECKING:
    from ble_log_frame_decoder.analysis.core.snapshot_protocol import *


def __getattr__(name: str) -> Any:
    return getattr(_implementation, name)
