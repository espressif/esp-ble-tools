# BLE Log Frame Decoder 用户指南

`esp-blfd` 是一个 Python 库，用于解码 BLE log 二进制帧。它提供：

- `FrameDecoder`：解码输入中的所有有效帧，并在损坏数据后重新同步；
- Cython 加速后端；扩展不可用时自动使用纯 Python 后端。

1.0 开发版还提供完整性检查（`ble_log_frame_decoder.checking`）和实时／离线
Host/HCI 解析（`ble_log_frame_decoder.analysis`）。压缩 Host 使用 `esp-blfd[host]`，
离线导出使用 `esp-blfd[offline]`。见[解析接口](PARSING.md)。基础拆帧接口不变，
也不会加载这些可选依赖。

## 环境与安装

要求 Python 3.11 或更高版本。

在源码目录中开发或运行：

```bash
cd ble_log_frame_decoder
uv sync
uv run python -c "import ble_log_frame_decoder; print('ok')"
```

从本地源码安装到其他 Python 环境：

```bash
python -m pip install /path/to/ble_log_frame_decoder
```

源码安装需要 C/C++ 编译器和 Python 开发头文件；构建工具会自动安装 Cython。安装与当前 Python 版本及平台匹配的预编译 wheel 无需本地编译。基础拆帧支持纯 Python 后端，但这不代表整个包可以在没有编译环境时从源码安装。

## 选择帧格式

导入 `FrameFormat` 并显式选择输入数据的格式：

| 枚举值 | 字符串值 | 用途 |
|---|---|---|
| `FrameFormat.BLE_LOG_V1_SUM32` | `ble-log-v1-sum32` | BLE log v1，字节求和校验 |
| `FrameFormat.BLE_LOG_V2_SUM32` | `ble-log-v2-sum32` | 已 deprecated 的 BLE log v2 字节求和校验格式 |
| `FrameFormat.BLE_LOG_V2_XOR32` | `ble-log-v2-xor32` | BLE log v2，32 位异或校验 |

默认格式是 `BLE_LOG_V2_XOR32`。由于不同格式的帧包络可能重叠，库不会自动探测格式；除非调用方只接收默认格式，否则应始终显式传入 `format`。

## 快速开始

### 一次性解码整个文件

```python
from pathlib import Path

from ble_log_frame_decoder import FrameDecoder, FrameFormat

raw = Path("ble.log").read_bytes()
decoder = FrameDecoder(FrameFormat.BLE_LOG_V2_XOR32)
frames = decoder.feed(raw)
stats = decoder.finish(require_complete=True)

for frame in frames:
    print(frame.offset, frame.source_code, frame.sequence_number, frame.payload)
```

`feed()` 返回输入中所有完整的有效帧，并自动跳过损坏数据。小文件可以一次传入；大文件或持续输入使用同一个接口分块传入。

### 流式解码文件

流式接口适合包含多帧的大文件、串口数据或网络数据。帧可以跨任意 chunk 边界：

```python
from ble_log_frame_decoder import FrameDecoder, FrameFormat


decoder = FrameDecoder(FrameFormat.BLE_LOG_V2_XOR32)

with open("ble.log", "rb") as log_file:
    while chunk := log_file.read(64 * 1024):
        for frame in decoder.feed(chunk):
            print(frame.offset, frame.source_code, frame.sequence_number)

stats = decoder.finish(require_complete=True)
print(stats)
```

`feed()` 返回当前 chunk 使其完整可用的所有帧。调用 `finish()` 后不能再次调用 `feed()`。

### v2 XOR32 view-only 消费

当调用方可以同步处理每个 BLE log v2 XOR32 payload 且不需要获得其所有权时，
使用 `feed_into()`：

```python
from ble_log_frame_decoder import FrameDecoder, FrameFormat, FrameView


def consume(frame: FrameView) -> None:
    print(frame.source_code, frame.raw_sn, frame.payload_view[:4])


decoder = FrameDecoder(FrameFormat.BLE_LOG_V2_XOR32)
with open("ble.log", "rb") as log_file:
    while chunk := log_file.read(64 * 1024):
        decoder.feed_into(chunk, sink=consume)
stats = decoder.finish(require_complete=True)
```

`payload_view` 只读，并且只在当前 `sink` 调用期间有效。sink 不得保存
`FrameView`、payload view 或其子 view；只有确实需要所有权时才显式调用
`bytes(frame.payload_view)`。`feed_into()` 仅支持 `BLE_LOG_V2_XOR32`；
v1 和已 deprecated 的 v2 SUM32 格式继续使用现有的 materializing `feed()`。

`require_complete=True` 只保证流末尾没有未完成的帧。若输入不应包含任何垃圾或损坏数据，还应检查：

```python
assert stats.discarded_bytes == 0
assert stats.resync_count == 0
```

## 返回对象

### `BleLogFrame`

| 字段 | 含义 |
|---|---|
| `source_code` | 8 位日志来源码 |
| `sequence_number` | v1 为 16 位，v2 为 24 位序列号 |
| `payload` | payload 的 `bytes` 副本 |
| `offset` | 帧在整个输入流中的绝对字节偏移 |
| `size` | 完整帧大小，包含帧头和 checksum |
| `skipped_bytes_before` | 为找到本帧而在其前方丢弃的字节数；严格解析时为 `0` |
| `type_code` | v1 的 8 位类型码；v2 为 `None` |

`BleLogFrame` 是不可变 dataclass。

### `FrameView`

| 字段 | 含义 |
|---|---|
| `source_code` | 8 位日志来源码 |
| `raw_sn` | v2 原始 24 位序列号 |
| `payload_offset` | payload 在整个输入流中的绝对字节偏移 |
| `payload_size` | payload 字节数 |
| `payload_view` | 借用的只读 payload view，仅在 sink 调用期间有效 |

`FrameView` 是不可变 dataclass，但 payload 为借用数据。sink 返回后不得保留
该对象、payload view 或其子 view。

## 解码统计

`decoder.stats` 和 `decoder.finish()` 返回 `DecodeStats`：

| 字段 | 含义 |
|---|---|
| `bytes_received` | 传给 `feed()` 或 `feed_into()` 的总字节数 |
| `frames_decoded` | `feed()` 返回或成功的 `feed_into()` 调用交付的有效帧数 |
| `discarded_bytes` | 重同步时丢弃的无效字节总数 |
| `resync_count` | 丢弃无效数据后重新找到帧边界的次数 |
| `trailing_bytes` | `finish()` 时剩余的未完成数据字节数 |
| `buffered_bytes` | 当前内部缓冲区字节数 |
| `peak_buffered_bytes` | 解码期间内部缓冲区的峰值字节数 |

可在解码过程中读取 `decoder.stats`，而不结束 decoder。

## 错误处理

```python
from ble_log_frame_decoder import (
    FrameDecoder,
    IncompleteFrameError,
)

decoder = FrameDecoder(selected_format)
try:
    frames = decoder.feed(raw)
    decoder.finish(require_complete=True)
except IncompleteFrameError as exc:
    print(f"流末尾数据不完整，起始偏移：{exc.offset}")
```

- `IncompleteFrameError`：`require_complete=True` 时，流末尾的数据不足以构成完整帧。它继承自 `FrameDecodeError` 和 `ValueError`，并提供 `offset` 属性。
- `feed_into()` 的 sink 抛出异常时，异常会原样传播，并且 decoder 会进入不可恢复的 failed 状态。应丢弃该实例并创建新的 decoder；后续 `feed()`、`feed_into()` 和 `finish()` 调用都会被拒绝。
- 长度非法、超过大小限制或 checksum 不匹配的候选帧会被跳过，解码器随后尝试重新同步。
- 使用 `FrameDecoder` 的帧 `skipped_bytes_before` 和统计字段可以检测被跳过的数据。

## 候选帧验证

BLE 应用可以使用线格式规则拒绝 checksum 正确的候选帧：

```python
def valid_internal_candidate(payload: memoryview) -> bool:
    return len(payload) == 6


candidate_policies = {source_code: None for source_code in range(9)}
candidate_policies[0] = valid_internal_candidate
decoder = FrameDecoder(
    FrameFormat.BLE_LOG_V2_XOR32,
    candidate_policies=candidate_policies,
)
```

该 mapping 同时也是 source code allowlist：缺少的 source code 会被拒绝，值为 `None` 表示该 source 只需通过 checksum，值为回调时则继续验证 payload；每个 source code 可以使用独立回调。回调返回 `False` 时，扫描会从候选帧起点的下一个字节继续。回调收到借用的、只读的 Python 内建 `memoryview`；该 view 仅在回调执行期间有效，回调不得保留它。省略 `candidate_policies` 时，所有 source code 都保持 checksum-only 解码。

## 限制最大帧大小

如果数据来自不可信边界，可设置比协议上限更小的 `max_frame_size`：

```python
decoder = FrameDecoder(
    FrameFormat.BLE_LOG_V2_XOR32,
    max_frame_size=4096,
)
```

该值表示包含帧头、payload 和 checksum 的完整帧大小。有效范围取决于格式：

| 格式 | 最小值 | 协议最大值 |
|---|---:|---:|
| 所有 BLE log 格式 | 11 | 65545 |

超过 `max_frame_size` 的候选帧会作为无效数据跳过，解码器随后尝试重新同步。

## 线格式参考

所有整数均为小端序，checksum 字段为 32 位无符号整数。

### BLE log v1 sum32

```text
payload_length:u16 | source_code:u8 | type_code:u8 | sequence_number:u16
payload:payload_length | checksum:u32
```

checksum 是 checksum 字段之前所有帧字节之和，再对 $2^{32}$ 取模。

### BLE log v2 sum32 / xor32

```text
payload_length:u16 | frame_meta:u32 | payload:payload_length | checksum:u32
```

`frame_meta` 的低 8 位是 `source_code`，高 24 位是 `sequence_number`。

- sum32：checksum 是 checksum 字段之前所有帧字节之和，再对 $2^{32}$ 取模；
- xor32：将 checksum 字段之前的数据按小端 32 位字分组后异或；末尾不足 4 字节的部分按高位补零处理。

