# BLE Log Frame Decoder User Guide

`esp-blfd` is a Python library for decoding binary BLE log frames. It provides:

- `FrameDecoder` for decoding every valid frame and resynchronizing after corrupt data;
- a Cython-accelerated backend with an automatic pure-Python fallback.

Version 1.0 also provides integrity checking (`ble_log_frame_decoder.checking`) and
streaming/offline Host/HCI parsing (`ble_log_frame_decoder.analysis`).
Install `esp-blfd[host]` for compressed Host decoding or `esp-blfd[offline]` for
complete-file exports. See [the parsing guide](PARSING.md). Basic frame decoding
keeps its existing interface and does not load optional parsing dependencies.

## Requirements and installation

Python 3.11 or later is required.

For development or execution from the source directory:

```bash
cd ble_log_frame_decoder
uv sync
uv run python -c "import ble_log_frame_decoder; print('ok')"
```

To install from local source into another Python environment:

```bash
python -m pip install /path/to/ble_log_frame_decoder
```

Source installation requires a C/C++ compiler and Python development headers; the build system installs Cython automatically. A prebuilt wheel matching your Python version and platform needs no local compilation. Basic frame decoding supports a pure-Python fallback, but this does not make the whole package installable from source without a compiler.

## Selecting a frame format

Import `FrameFormat` and explicitly select the format of the input data:

| Enum value | String value | Purpose |
|---|---|---|
| `FrameFormat.BLE_LOG_V1_SUM32` | `ble-log-v1-sum32` | BLE log v1 with byte-sum checksum |
| `FrameFormat.BLE_LOG_V2_SUM32` | `ble-log-v2-sum32` | Deprecated BLE log v2 with byte-sum checksum |
| `FrameFormat.BLE_LOG_V2_XOR32` | `ble-log-v2-xor32` | BLE log v2 with 32-bit XOR checksum |

The default is `BLE_LOG_V2_XOR32`. Frame envelopes can overlap between formats, so the library does not auto-detect the format. Always pass `format` explicitly unless the caller only accepts the default format.

## Quick start

### Decode an entire file at once

```python
from pathlib import Path

from ble_log_frame_decoder import FrameDecoder, FrameFormat

raw = Path("ble.log").read_bytes()
decoder = FrameDecoder(FrameFormat.BLE_LOG_V2_XOR32)
frames = decoder.feed(raw)
stats = decoder.finish(require_complete=True)

for frame in frames:
    print(frame.offset, frame.source_code, frame.sequence_number, frame.payload)
```

`feed()` returns every complete, valid frame in its input and automatically skips corrupt data. Pass a small file in one call, or use the same interface with chunks for large files and continuous input.

### Stream-decode a file

The streaming API is intended for large multi-frame files, serial data, and network data. Frames may cross arbitrary chunk boundaries:

```python
from ble_log_frame_decoder import FrameDecoder, FrameFormat


decoder = FrameDecoder(FrameFormat.BLE_LOG_V2_XOR32)

with open("ble.log", "rb") as log_file:
    while chunk := log_file.read(64 * 1024):
        for frame in decoder.feed(chunk):
            print(frame.offset, frame.source_code, frame.sequence_number)

stats = decoder.finish(require_complete=True)
print(stats)
```

`feed()` returns every frame that became complete with the current chunk. `feed()` cannot be called again after `finish()`.

### View-only v2 XOR32 consumption

Use `feed_into()` when the consumer can process each BLE log v2 XOR32 payload
synchronously and does not need to own it:

```python
from ble_log_frame_decoder import FrameDecoder, FrameFormat, FrameView


def consume(frame: FrameView) -> None:
    print(frame.source_code, frame.raw_sn, frame.payload_view[:4])


decoder = FrameDecoder(FrameFormat.BLE_LOG_V2_XOR32)
with open("ble.log", "rb") as log_file:
    while chunk := log_file.read(64 * 1024):
        decoder.feed_into(chunk, sink=consume)
stats = decoder.finish(require_complete=True)
```

`payload_view` is read-only and valid only during the `sink` call. The sink
must not retain the `FrameView`, its payload view, or a derived view. Copy with
`bytes(frame.payload_view)` only when ownership is required. `feed_into()` only
supports `BLE_LOG_V2_XOR32`; v1 and the deprecated v2 SUM32 format continue to
use the existing materializing `feed()` behavior.

`require_complete=True` only guarantees that no incomplete frame remains at the end of the stream. If the input must contain no garbage or corrupt data, also check:

```python
assert stats.discarded_bytes == 0
assert stats.resync_count == 0
```

## Returned objects

### `BleLogFrame`

| Field | Meaning |
|---|---|
| `source_code` | 8-bit log source code |
| `sequence_number` | 16-bit sequence number for v1; 24-bit for v2 |
| `payload` | A `bytes` copy of the payload |
| `offset` | Absolute byte offset of the frame in the full input stream |
| `size` | Full frame size, including header and checksum |
| `skipped_bytes_before` | Bytes discarded immediately before this frame was found; `0` for strict parsing |
| `type_code` | 8-bit v1 type code; `None` for v2 |

`BleLogFrame` is an immutable dataclass.

### `FrameView`

| Field | Meaning |
|---|---|
| `source_code` | 8-bit log source code |
| `raw_sn` | Raw 24-bit v2 sequence number |
| `payload_offset` | Absolute byte offset of the payload in the full input stream |
| `payload_size` | Payload size in bytes |
| `payload_view` | Borrowed, read-only payload view, valid only during the sink call |

`FrameView` is an immutable dataclass, but its payload is borrowed. Do not
retain the object, its payload view, or a derived view after the sink returns.

## Decoder statistics

`decoder.stats` and `decoder.finish()` return `DecodeStats`:

| Field | Meaning |
|---|---|
| `bytes_received` | Total bytes passed to `feed()` or `feed_into()` |
| `frames_decoded` | Number of valid frames returned by `feed()` or emitted by successful `feed_into()` calls |
| `discarded_bytes` | Total invalid bytes discarded during resynchronization |
| `resync_count` | Times a frame boundary was found after invalid data was discarded |
| `trailing_bytes` | Incomplete bytes remaining when `finish()` was called |
| `buffered_bytes` | Bytes currently retained in the internal buffer |
| `peak_buffered_bytes` | Peak internal buffer size during decoding |

Read `decoder.stats` at any point without finishing the decoder.

## Error handling

```python
from ble_log_frame_decoder import (
    FrameDecoder,
    IncompleteFrameError,
)

decoder = FrameDecoder(selected_format)
try:
    frames = decoder.feed(raw)
    decoder.finish(require_complete=True)
except IncompleteFrameError as exc:
    print(f"Incomplete data at the end of the stream, starting at {exc.offset}")
```

- `IncompleteFrameError`: with `require_complete=True`, the data at the end of the stream is not a complete frame. It inherits from `FrameDecodeError` and `ValueError` and exposes an `offset` attribute.
- If a `feed_into()` sink raises an exception, that exception propagates and the decoder enters a terminal failed state. Discard it and create a new decoder; subsequent `feed()`, `feed_into()`, and `finish()` calls are rejected.
- Candidates with invalid lengths, excessive sizes, or checksum mismatches are skipped before the decoder attempts to resynchronize.
- Use each frame's `skipped_bytes_before` and the `FrameDecoder` statistics to detect skipped data.

## Candidate validation

BLE applications can reject checksum-valid candidates using wire-format rules:

```python
def valid_internal_candidate(payload: memoryview) -> bool:
    return len(payload) == 6


candidate_policies = {source_code: None for source_code in range(9)}
candidate_policies[0] = valid_internal_candidate
decoder = FrameDecoder(
    FrameFormat.BLE_LOG_V2_XOR32,
    candidate_policies=candidate_policies,
)
```

The mapping is also the source-code allowlist: a missing source code is rejected, `None` accepts that source after checksum validation, and a callback applies additional payload validation. Each source code can have its own callback. Returning `False` resumes scanning one byte after the candidate start. The callback receives a borrowed, read-only built-in `memoryview`; it must not be retained after the callback returns. Omitting `candidate_policies` preserves checksum-only decoding for all source codes.

## Limiting frame size

For data crossing an untrusted boundary, set `max_frame_size` below the protocol maximum:

```python
decoder = FrameDecoder(
    FrameFormat.BLE_LOG_V2_XOR32,
    max_frame_size=4096,
)
```

The value is the complete frame size, including header, payload, and checksum. Its valid range depends on the format:

| Format | Minimum | Protocol maximum |
|---|---:|---:|
| All BLE log formats | 11 | 65545 |

A candidate exceeding `max_frame_size` is skipped as invalid data before the decoder attempts to resynchronize.

## Wire format reference

All integers are little-endian. Every checksum field is an unsigned 32-bit integer.

### BLE log v1 sum32

```text
payload_length:u16 | source_code:u8 | type_code:u8 | sequence_number:u16
payload:payload_length | checksum:u32
```

The checksum is the sum of every frame byte before the checksum field, reduced modulo $2^{32}$.

### BLE log v2 sum32 / xor32

```text
payload_length:u16 | frame_meta:u32 | payload:payload_length | checksum:u32
```

The low 8 bits of `frame_meta` are `source_code`; the upper 24 bits are `sequence_number`.

- sum32: sum every frame byte before the checksum field, reduced modulo $2^{32}$;
- xor32: split the data before the checksum into little-endian 32-bit words and XOR them. A final group shorter than four bytes is zero-padded in its high bytes.

