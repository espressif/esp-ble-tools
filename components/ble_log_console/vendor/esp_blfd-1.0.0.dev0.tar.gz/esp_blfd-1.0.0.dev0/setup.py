# pyright: reportMissingImports=false, reportMissingModuleSource=false

import os

from Cython.Build import cythonize
from setuptools import Extension, setup

# CPython version hex of the stable-ABI baseline (0x030B0000 = 3.11).
# Keep limited-API compilation, but use CPython filenames consistently with the other engines.
PYTHON_LIMITED_API_HEX = "0x030B0000"
LIMITED_API_MACROS: list[tuple[str, str | None]] = [
    ("CYTHON_LIMITED_API", "1"),
    ("Py_LIMITED_API", PYTHON_LIMITED_API_HEX),
]

extensions = cythonize(
    [
        Extension(
            "ble_log_frame_decoder._native",
            ["src/ble_log_frame_decoder/_native.pyx"],
            define_macros=LIMITED_API_MACROS,
        )
    ],
    build_dir="build/cython",
    compiler_directives={
        "binding": False,
        "embedsignature": False,
        "language_level": "3",
        "linetrace": False,
        "profile": False,
    },
)
for extension in extensions:
    # Source installs may use the Python fallback; release wheels must contain native code.
    extension.optional = "CIBUILDWHEEL" not in os.environ

extensions += cythonize(
    [
        Extension(
            "ble_log_frame_decoder.checking._native",
            ["src/ble_log_frame_decoder/checking/_native.pyx"],
            language="c++",
        )
    ],
    build_dir="build/cython",
    compiler_directives={"language_level": "3", "binding": True},
)
extensions += cythonize(
    [
        Extension(
            "ble_log_frame_decoder.analysis.ordering._linearize_native",
            ["src/ble_log_frame_decoder/analysis/ordering/_linearize_native.pyx"],
        )
    ],
    build_dir="build/cython",
    compiler_directives={"language_level": "3", "binding": False},
)

setup(
    ext_modules=extensions,
    zip_safe=False,
)
