"""Shared frame model for best-effort instance detection and ordering."""

import struct
from dataclasses import dataclass
from enum import StrEnum

from ble_log_frame_decoder.analysis.core.source_codes import BleLogSource
from ble_log_frame_decoder.checking.protocol import (
    RESTART_SN_CEILING,
    is_valid_frame_candidate,
)


@dataclass(frozen=True)
class DetectorConfig:
    """Validated best-effort thresholds shared by the ordering pipeline."""

    # The same ceiling the checker splits a source's sequence into runs with.
    max_forward_sn_gap: int = RESTART_SN_CEILING
    consensus_window: int = 500
    min_reset_clock_drop_us: int = 1_000_000
    lc_t_low_us: int = 1_000
    os_t_low_us: int = 1_000_000
    # TS Sync anchors must be close to an LC observation of the same
    # instance. Deliberately wider than the nominal 1 Hz TS Sync period:
    # lightsleep can delay esp_timer callbacks well beyond 1 s.
    ts_sync_max_lc_distance_us: int = 10_000_000


class ClockDomain(StrEnum):
    """Clock source of a frame's timestamp."""

    LC = "lc"
    FREERTOS = "freertos"  # Historical system-clock label; final v8 uses ESP time.


class LcTimerUnit(StrEnum):
    """LC timer unit for the log's chip (CLI resolves chip name to this)."""

    US = "us"  # native us (C3/S3/Gen2 etc.)
    RTC_TICK = "tick"  # ESP32C2: 32768 Hz RTC tick


class AnchorKind(StrEnum):
    """Firmware event frame acting as an instance boundary anchor."""

    FLUSH = "flush"
    INIT_DONE = "init_done"


# Internal TIMESTAMP payload: struct "<IBBIII" — log_os_ts, source_id,
# io_level, lc_ts, esp_ts, os_ts (see src/decoder/internal.py).
_TIMESTAMP_PAYLOAD_LEN = 18
_TIMESTAMP_SOURCE_ID = 1
_INIT_DONE_SOURCE_ID = 0
_FLUSH_SOURCE_ID = 4


@dataclass(frozen=True)
class AnchorInfo:
    """One paired LC/system clock sample used for ordering.

    lc_ts is already unwrapped to the instance's LC epoch (k·2^32 + raw);
    os_ts_ms keeps its historical name: older protocols use OS milliseconds,
    final v8 uses unwrapped ESP microseconds. The instance selects the scale.
    """

    lc_ts: int
    os_ts_ms: int


@dataclass
class AnchorMap:
    """Piecewise-linear LC -> system-clock mapping from paired samples.

    Slopes come from the measured anchor pairs, never from nominal clock
    frequencies (ESP32C2 has 32768 vs 40000 Hz firmware divergence).
    Endpoints extrapolate with the nearest segment's slope.
    """

    anchors: tuple[AnchorInfo, ...]
    rejected: int = 0
    # Anchor coverage is a time-range question per domain: LC clocks against
    # [first, last].lc_ts, FreeRTOS clocks against [first, last].os_ts_ms.
    # Mappings beyond it are extrapolations; the mapping itself lives in
    # _linearize_native (Cython).

    @property
    def usable(self) -> bool:
        return len(self.anchors) >= 2


def parse_per_source_timestamp_anchor(
    source: BleLogSource,
    payload: bytes | memoryview,
) -> tuple[int, int] | None:
    """Return the older protocol's raw ``(lc_ts, os_ts_ms)`` TS Sync pair."""
    if (
        source is not BleLogSource.INTERNAL
        or len(payload) != _TIMESTAMP_PAYLOAD_LEN
        or payload[4] != _TIMESTAMP_SOURCE_ID
    ):
        return None
    _, _, _, lc_ts, _, os_ts = struct.unpack_from("<IBBIII", payload, 0)
    return lc_ts, os_ts


def build_anchor_map(anchors: list[AnchorInfo]) -> AnchorMap:
    """Sort anchors by LC clock and drop non-monotonic ones; map is usable
    only with >= 2 surviving anchors."""
    ordered = sorted(anchors, key=lambda anchor: (anchor.lc_ts, anchor.os_ts_ms))
    kept: list[AnchorInfo] = []
    rejected = 0
    for anchor in ordered:
        if kept and (
            anchor.lc_ts <= kept[-1].lc_ts or anchor.os_ts_ms <= kept[-1].os_ts_ms
        ):
            rejected += 1
            continue
        kept.append(anchor)
    return AnchorMap(anchors=tuple(kept), rejected=rejected)


# Source -> clock domain map (design §3.2). REDIR is excluded.
SOURCE_CLOCK_MAP: dict[BleLogSource, ClockDomain] = {
    BleLogSource.INTERNAL: ClockDomain.FREERTOS,
    BleLogSource.CUSTOM: ClockDomain.FREERTOS,
    BleLogSource.LL_TASK: ClockDomain.LC,
    BleLogSource.LL_HCI: ClockDomain.LC,
    BleLogSource.LL_ISR: ClockDomain.LC,
    BleLogSource.HOST: ClockDomain.FREERTOS,
    BleLogSource.HCI: ClockDomain.FREERTOS,
    BleLogSource.ENCODE: ClockDomain.FREERTOS,
}


_LL_SOURCES = {
    BleLogSource.LL_TASK,
    BleLogSource.LL_HCI,
    BleLogSource.LL_ISR,
}


def detect_per_source_anchor_kind(
    source: BleLogSource,
    payload: bytes | memoryview,
) -> AnchorKind | None:
    """Return an older-protocol INIT/FLUSH instance-boundary event."""
    if source is not BleLogSource.INTERNAL or len(payload) != 6:
        return None
    source_id = payload[4]
    if source_id == _FLUSH_SOURCE_ID:
        return AnchorKind.FLUSH
    if source_id == _INIT_DONE_SOURCE_ID:
        return AnchorKind.INIT_DONE
    return None


def has_reliable_payload(
    source: BleLogSource,
    payload: bytes | memoryview,
) -> bool:
    """Whether a payload is structurally sound enough for a hard SN edge."""
    if source is BleLogSource.INTERNAL:
        return is_valid_frame_candidate(source, payload)
    if source is BleLogSource.CUSTOM:
        return len(payload) == 7 and payload[4:6] == b"\x00\x00"
    if source in _LL_SOURCES:
        return len(payload) >= 6 and struct.unpack_from("<H", payload)[0] == len(
            payload
        )
    # HOST / HCI / ENCODE (FreeRTOS domain): the payload head is the 4-byte
    # os_ms field. Anything shorter is a truncated/malformed frame and must not
    # constrain neighbors through its sequence number.
    return len(payload) >= 4


def extract_raw_clock_from_payload(
    source: BleLogSource,
    payload: bytes | memoryview,
) -> int | None:
    """Extract a source's raw native u32 clock from a payload."""
    domain = SOURCE_CLOCK_MAP.get(source)
    if domain is None:
        return None
    offset = 2 if domain is ClockDomain.LC else 0
    if len(payload) < offset + 4:
        return None
    (raw,) = struct.unpack_from("<I", payload, offset)
    return raw


def normalize_raw_clock(
    source: BleLogSource,
    raw: int,
    lc_timer_unit: LcTimerUnit,
) -> int:
    """Normalize one source's native u32 clock to microseconds."""
    domain = SOURCE_CLOCK_MAP[source]
    if domain is ClockDomain.LC:
        if lc_timer_unit is LcTimerUnit.RTC_TICK:
            return raw * 1_000_000 // 32768
        return raw
    return raw * 1000
