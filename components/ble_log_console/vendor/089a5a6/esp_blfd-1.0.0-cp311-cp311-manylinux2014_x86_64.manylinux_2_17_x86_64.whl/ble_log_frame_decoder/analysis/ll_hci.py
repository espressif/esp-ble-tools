import struct
from collections.abc import Iterable
from pathlib import Path
from typing import Any as Synchronizer

from loguru import logger

from ble_log_frame_decoder import FrameView
from ble_log_frame_decoder.analysis.core.parse_context import ParseContext

from .hci import BTSNOOP_HEADER

# Maps
HCI_FLAG_MAP = {
    0: {"direction": 0, "cmd": 1, "packet_type": 1},
    1: {"direction": 0, "cmd": 0, "packet_type": 2},
    2: {"direction": 1, "cmd": 1, "packet_type": 4},
    3: {"direction": 1, "cmd": 0, "packet_type": 2},
    9: {"direction": 1, "cmd": 1, "packet_type": 4},
}

# Yaml config
ESP_LOG_PARAM_C2_HCI_MODULE = 11
ESP_LOG_PARAM_HCI_MODULE = 10

BTSNOOP_VERSION = 1
BTSNOOP_DATALINK_TYPE = 1002
BTSNOOP_FILE_ID = b"btsnoop\x00"
BTSNOOP_TIMESTAMP_BASE = 0x00DCDDB30F2F8000


def ll_hci_log_handler(
    frames: Iterable[FrameView],
    synchronizer: Synchronizer,
    chip_name: str | None,
    raw_hex_path: Path | None,
    btsnoop_path: Path,
    *,
    context: ParseContext | None = None,
    append: bool = False,
) -> None:
    """Stream LL HCI payloads directly to their two output files."""
    raw_file = None
    btsnoop_file = None
    raw_count = 0
    hci_count = 0
    dry_run = bool(context and context.dry_run)
    try:
        for frame in frames:
            payload = frame.payload_view
            raw_count += 1
            if not dry_run and raw_hex_path is not None:
                if raw_file is None:
                    raw_file = raw_hex_path.open(
                        "a" if append else "w", encoding="utf-8"
                    )
                raw_file.write(f"{payload.hex(' ')}\n")

            parsed = _parse_ll_hci_payload(payload, chip_name)
            if parsed is None:
                continue
            timestamp, id_val, params, expected, actual = parsed
            if id_val not in HCI_FLAG_MAP:
                continue
            if params is None:
                logger.warning("HCI log without params found")
                continue
            hci_count += 1
            if dry_run:
                continue
            if btsnoop_file is None:
                btsnoop_file = btsnoop_path.open("ab" if append else "wb")
                if btsnoop_file.tell() == 0:
                    btsnoop_file.write(BTSNOOP_HEADER)
            flags = HCI_FLAG_MAP[id_val]
            timestamp = (
                synchronizer.lc_ts_to_la_ts(
                    struct.unpack_from("<I", payload, 2)[0]
                    if synchronizer.edge_slope
                    else timestamp
                )
                if synchronizer.inited
                else timestamp
            )
            btsnoop_file.write(
                struct.pack(
                    "!IIIIQ",
                    expected + 1,
                    actual + 1,
                    (flags["cmd"] << 1) + flags["direction"],
                    0,
                    BTSNOOP_TIMESTAMP_BASE + int(timestamp),
                )
                + struct.pack("<B", flags["packet_type"])
                + params
            )
    finally:
        if raw_file is not None:
            raw_file.close()
        if btsnoop_file is not None:
            btsnoop_file.close()

    if raw_count and raw_hex_path is not None:
        if dry_run:
            logger.info(f"[Dry run] Would write: {raw_hex_path}")
        else:
            logger.info(f"LL HCI raw hex log has been saved to {raw_hex_path}")
        if context:
            context.add_output_file(raw_hex_path)
    if hci_count:
        if dry_run:
            logger.info(f"[Dry run] Would write: {btsnoop_path}")
        else:
            logger.info(f"LL HCI log has been saved to {btsnoop_path}")
        if context:
            context.add_output_file(btsnoop_path)


def _parse_ll_hci_payload(
    payload: bytes | memoryview,
    chip_name: str | None,
) -> tuple[int, int, bytes | None, int, int] | None:
    length_field_len = 2
    timestamp_field_len = 4
    id_field_len = 4
    base_log_len = length_field_len + timestamp_field_len + id_field_len
    if len(payload) < base_log_len:
        return None
    (body_len,) = struct.unpack_from("<H", payload)
    # The declared BTSnoop length and the captured payload length can differ.
    if body_len + 1 < base_log_len:
        return None
    body = payload[length_field_len:]
    raw_ts, id_field = struct.unpack_from("<II", body)
    timestamp = raw_ts
    id_val = id_field & 0xFFFF
    module = (id_field >> 16) & 0x1F
    if chip_name == "ESP32C2":
        module = (id_val >> 12) & 0x0F
        id_val &= 0xFFF
        timestamp = int(timestamp * (1e6 / 32768))
        if module != ESP_LOG_PARAM_C2_HCI_MODULE:
            return None
    elif module != ESP_LOG_PARAM_HCI_MODULE:
        return None
    params = (
        bytes(body[timestamp_field_len + id_field_len :])
        if len(body) > timestamp_field_len + id_field_len
        else None
    )
    return timestamp, id_val, params, body_len - base_log_len, len(params or b"")


def describe_ll_hci(payload, chip_name):
    from .hci import HciPacket, describe_hci

    parsed = _parse_ll_hci_payload(payload, chip_name)
    if parsed is None or parsed[2] is None:
        reason = "short_payload" if len(payload) <= 10 else "invalid_payload"
        return HciPacket(f"HCI undecodable: {payload.hex(' ')}", reason=reason)
    timestamp, log_id, _, expected, actual = parsed
    packet = parsed[2]
    flags = HCI_FLAG_MAP.get(log_id)
    if flags is None:
        return HciPacket(
            f"HCI undecodable: {payload.hex(' ')}", reason="unknown_hci_id"
        )
    raw_type = flags["packet_type"] | (flags["direction"] << 7)
    record = describe_hci(bytes(4) + bytes([raw_type]) + packet, timestamp)
    if expected != actual:
        return record._replace(
            btsnoop=struct.pack("!I", expected + 1) + record.btsnoop[4:],
            reason="truncated_packet",
        )
    return record
