"""Owned integrity summaries, independent of temporary storage."""

from copy import deepcopy
from dataclasses import asdict, dataclass, field
from typing import Any

from .protocol import INIT


@dataclass(frozen=True, slots=True)
class Anchor:
    sn: int
    anchor_count: int
    offset: int
    reason_flags: int


@dataclass(slots=True)
class Received:
    frames: int = 0
    bytes: int = 0


@dataclass(slots=True)
class SnRun:
    """One continuous stretch of a source's unfolded sequence numbers.

    A stretch ends where the sequence restarts: numbers on the far side of a
    restart belong to another run, and the span *between* two runs is not loss.
    An absent number inside a run's own range is loss, so it is counted in
    ``missing`` even when it sits between two runs' first and last numbers.
    """

    source: int
    index: int
    first: int
    last: int
    count: int
    missing: int
    first_row: int | None = None
    last_row: int | None = None

    @property
    def expected(self) -> int:
        """Numbers this run accounts for: its own arrivals plus its own holes."""
        return self.count + self.missing

    @property
    def sn_range(self) -> tuple[int, int]:
        """Inclusive unfolded bounds of the stretch."""
        return self.first, self.last

    @property
    def rows(self) -> tuple[int, int] | None:
        """Transport rows this run was observed in, when the caller supplied them."""
        if self.first_row is None or self.last_row is None:
            return None
        return self.first_row, self.last_row


@dataclass(slots=True)
class IntervalResult:
    epoch: int
    protocol: str
    status: str = "reported"
    scope: str = "trusted"
    notes: list[str] = field(default_factory=list)
    start_anchor: Anchor | None = None
    lower_anchor: Anchor | None = None
    upper_anchor: Anchor | None = None
    last_anchor: Anchor | None = None
    expected_sn_count: int | None = None
    received_unique_sn_count: int | None = None
    missing_ranges: list[tuple[int, int]] = field(default_factory=list)
    conflict_ranges: list[tuple[int, int]] = field(default_factory=list)
    missing_sn_count: int = 0
    conflict_sn_count: int = 0
    details_truncated: bool = False
    late_frames: int = 0
    duplicate_frames: int = 0
    # Global SN -> extra arrivals.
    duplicates: dict[int, int] = field(default_factory=dict)
    independent_frames: int = 0
    excluded_head_frames: int = 0
    # Head includes the first snapshot; SNs are unfolded within the lifecycle.
    head_first_sn: int | None = None
    excluded_tail_frames: int = 0
    unanchored_tail_frames: int = 0
    observed_frames: int = 0
    received: dict[int, Received] = field(default_factory=dict)
    observed: dict[int, Received] = field(default_factory=dict)
    firmware_start: dict[int, dict[str, int]] = field(default_factory=dict)
    firmware_end: dict[int, dict[str, int]] = field(default_factory=dict)
    firmware_delta: dict[int, dict[str, int]] | None = None
    written_frame_difference: dict[int, int] = field(default_factory=dict)
    source_missing_ranges: dict[int, list[tuple[int, int]]] = field(
        default_factory=dict
    )
    # Observed-SN accounting only: one entry per continuous run per source.
    source_runs: dict[int, list[SnRun]] = field(default_factory=dict)
    final_stat_offset: int | None = None
    source_sn_ranges: dict[int, tuple[int, int]] = field(default_factory=dict)
    excluded_sn_count: int = 0
    known_firmware_loss: bool = False
    write_failed_by_source: dict[int, int] | None = None
    write_failed_count: int | None = None
    transport_lost_count: int | None = None
    # Raw lost counters at the selected sampling endpoints, not parser accounting.
    write_fail_start: dict[int, int] | None = None
    write_fail_end: dict[int, int] | None = None

    # Lifecycle snapshot sequence anomaly; diagnostic only, not a verdict.
    snapshot_conflict: bool = False

    @property
    def sn_range(self) -> tuple[int, int] | None:
        """Inclusive unfolded Global SN bounds, when available."""
        start = (
            self.head_first_sn
            if self.scope in ("head", "best_effort")
            else self.start_anchor.sn + 1
            if self.start_anchor
            else None
        )
        if start is None or not self.expected_sn_count:
            return None
        return start, start + self.expected_sn_count - 1


def sn_run_totals(interval: IntervalResult) -> tuple[int, int] | None:
    """Missing and expected frame numbers, over continuous runs when known.

    A sequence restart splits the checked range into runs, so the span between
    two runs is not counted as loss. An absent number inside a run's range is,
    and an absent number that two runs' ranges share is counted once.
    Intervals without run data (new-capture snapshot accounting, FINAL_STAT
    counter ranges) keep their own totals. An interval the checker declined to
    measure has no total: its runs survive for diagnostics, its numbers do not.
    """
    if (
        interval.expected_sn_count is None
        or interval.received_unique_sn_count is None
        or interval.received_unique_sn_count + interval.missing_sn_count
        != interval.expected_sn_count
    ):
        return None
    if not interval.source_runs:
        return interval.missing_sn_count, interval.expected_sn_count
    missing = 0
    for runs in interval.source_runs.values():
        missing += sum(run.missing for run in runs)
    return missing, interval.received_unique_sn_count + missing


def _interval(data: dict[str, Any]) -> IntervalResult:
    for name in ("start_anchor", "lower_anchor", "upper_anchor", "last_anchor"):
        if data[name] is not None:
            data[name] = Anchor(**data[name])
    for name in ("received", "observed"):
        data[name] = {int(k): Received(**v) for k, v in data[name].items()}
    for name in (
        "firmware_start",
        "firmware_end",
        "firmware_delta",
        "written_frame_difference",
        "source_missing_ranges",
        "duplicates",
        "write_failed_by_source",
        "write_fail_start",
        "write_fail_end",
    ):
        if data.get(name) is not None:
            data[name] = {int(k): v for k, v in data[name].items()}
    for name in ("missing_ranges", "conflict_ranges"):
        data[name] = [tuple(pair) for pair in data[name]]
    data["source_missing_ranges"] = {
        source: [tuple(pair) for pair in ranges]
        for source, ranges in data["source_missing_ranges"].items()
    }
    data["source_sn_ranges"] = {
        int(source): tuple(bounds)
        for source, bounds in data.get("source_sn_ranges", {}).items()
    }
    data["source_runs"] = {
        int(source): [SnRun(**run) for run in runs]
        for source, runs in data.get("source_runs", {}).items()
    }
    return IntervalResult(**data)


@dataclass(slots=True)
class CheckResult:
    status: str
    intervals: list[IntervalResult] = field(default_factory=list)
    scan_stats: dict[str, int] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Historical sidecar shape; derived verdicts are recomputed on read."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CheckResult":
        """Restore a JSON sidecar without mutating caller-owned dictionaries."""
        owned = deepcopy(data)
        return cls(
            status=owned["status"],
            intervals=[_interval(item) for item in owned["intervals"]],
            scan_stats=owned.get("scan_stats", {}),
            notes=owned.get("notes", []),
        )

    @property
    def checked_intervals(self) -> list[IntervalResult]:
        """Select coverage per lifecycle without changing raw diagnostic intervals."""
        edges = {(i.epoch, i.scope): i for i in self.intervals}
        selected = []
        for interval in self.intervals:
            if interval.protocol != "snapshot":
                if interval.scope != "tail":
                    selected.append(interval)
                continue
            if interval.scope == "best_effort":
                selected.append(interval)
                continue
            if interval.scope != "trusted":
                continue
            if interval.expected_sn_count != 0:
                selected.append(interval)
                continue
            head = edges.get((interval.epoch, "head"))
            tail = edges.get((interval.epoch, "tail"))
            if head is None or tail is None:
                selected.append(interval)
                continue
            combined = IntervalResult(
                interval.epoch,
                "snapshot",
                scope="best_effort",
                head_first_sn=head.head_first_sn,
                last_anchor=tail.last_anchor,
                lower_anchor=interval.start_anchor,
                upper_anchor=interval.last_anchor,
                write_failed_by_source=interval.write_failed_by_source,
                write_failed_count=interval.write_failed_count,
                write_fail_start=interval.write_fail_start,
                write_fail_end=interval.write_fail_end,
                independent_frames=interval.independent_frames,
                known_firmware_loss=interval.known_firmware_loss,
                snapshot_conflict=interval.snapshot_conflict,
                notes=[
                    "Observed SN range only; coverage outside this range is unknown.",
                    *interval.notes,
                ],
            )
            parts = (head, tail)
            combined.expected_sn_count = sum(p.expected_sn_count or 0 for p in parts)
            if all(
                p.status == "reported" and p.received_unique_sn_count is not None
                for p in parts
            ):
                combined.received_unique_sn_count = sum(
                    p.received_unique_sn_count or 0 for p in parts
                )
            else:
                combined.status = "insufficient_evidence"
            for part in parts:
                combined.notes.extend(part.notes)
                combined.missing_sn_count += part.missing_sn_count
                combined.duplicate_frames += part.duplicate_frames
                combined.duplicates.update(part.duplicates)
                combined.missing_ranges.extend(part.missing_ranges)
                combined.details_truncated |= part.details_truncated
                for source, count in part.received.items():
                    total = combined.received.setdefault(source, Received())
                    total.frames += count.frames
                    total.bytes += count.bytes
            combined.details_truncated |= len(combined.missing_ranges) > 32
            combined.missing_ranges = combined.missing_ranges[:32]
            # A cumulative sample only matches the full observed range when INIT
            # establishes zero and the last sample closes its observed tail.
            matched = bool(
                combined.lower_anchor
                and combined.lower_anchor.reason_flags & INIT
                and combined.write_fail_start is not None
                and not any(combined.write_fail_start.values())
                and combined.upper_anchor
                and combined.sn_range
                == (combined.lower_anchor.sn, combined.upper_anchor.sn)
            )
            _attribute_transport(combined, matched)
            selected.append(combined)
        return selected

    @property
    def conclusion(self) -> str:
        """Range-scoped verdict; evidence status is not a pass/fail verdict."""
        intervals = self.checked_intervals
        if self.status == "error" or not intervals:
            return "indeterminate"
        missing = 0
        for interval in intervals:
            totals = sn_run_totals(interval)
            if (
                interval.status != "reported"
                or totals is None
                or totals[1] <= 0
                or not 0 <= totals[0] <= totals[1]
                or interval.conflict_sn_count
                or interval.late_frames
                or any(n < 0 for n in interval.written_frame_difference.values())
            ):
                return "indeterminate"
            missing += totals[0]
        if missing or any(i.duplicate_frames for i in intervals):
            return "failed"
        return "passed"


def _detail(
    result: IntervalResult, kind: str, start: int, end: int, source: int = -1
) -> None:
    preview = (
        result.source_missing_ranges.setdefault(source, [])
        if source >= 0
        else result.missing_ranges
        if kind == "missing"
        else result.conflict_ranges
    )
    if len(preview) < 32:
        preview.append((start, end))
    else:
        result.details_truncated = True
    if kind == "missing":
        result.missing_sn_count += end - start + 1
    else:
        result.conflict_sn_count += end - start + 1


def _attribute_transport(result: IntervalResult, matched: bool) -> None:
    """Add attribution without changing coverage, evidence status or verdicts."""
    result.transport_lost_count = None
    if result.write_failed_count is None:
        reason = "write-fail count is unknown"
    elif not matched:
        reason = "firmware sampling and SN coverage ranges do not match"
    elif (
        result.status != "reported"
        or result.expected_sn_count is None
        or result.expected_sn_count <= 0
        or result.received_unique_sn_count is None
        or result.received_unique_sn_count + result.missing_sn_count
        != result.expected_sn_count
        or result.conflict_sn_count
        or result.late_frames
    ):
        reason = "SN coverage is incomplete or ambiguous"
    elif result.write_failed_count > result.missing_sn_count:
        reason = "write-fail count exceeds missing SN count"
    else:
        result.transport_lost_count = (
            result.missing_sn_count - result.write_failed_count
        )
        return
    result.notes.append(f"Transport attribution unavailable: {reason}")
