"""Incremental coverage with bounded active windows and a JSONL scratch file."""

import hashlib
import json
import tempfile
from collections import deque
from collections.abc import Iterator
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from ble_log_frame_decoder import BleLogFrame, DecodeStats

from ._per_source import _PerSourceStats
from .protocol import (
    FLUSH,
    INIT,
    PERIODIC,
    SNAPSHOT,
    TASK_BINDING,
    Snapshot,
    is_valid_internal_candidate,
    parse_snapshot,
)
from .results import (
    Anchor,
    CheckResult,
    IntervalResult,
    Received,
    _attribute_transport,
    _detail,
    _interval,
)

if TYPE_CHECKING:
    from ble_log_frame_decoder import FrameView

_PERIOD = 1 << 24
_PREVIEW = 32


def _distance(raw: int, reference: int) -> int:
    return (raw - reference + _PERIOD // 2) % _PERIOD - _PERIOD // 2


@dataclass
class _Window:
    lower: int = 0
    upper: int = 0
    deadline: int = 0
    # First arrival's source/length are needed when an anchor splits this window.
    frames: dict[int, tuple[int, int]] = field(default_factory=dict)
    duplicates: dict[int, int] = field(default_factory=dict)

    def split(self, upper: int, deadline: int) -> "_Window":
        result = _Window(
            self.lower,
            upper,
            deadline,
            {n: v for n, v in self.frames.items() if n <= upper},
            {n: v for n, v in self.duplicates.items() if n <= upper},
        )
        self.frames = {n: v for n, v in self.frames.items() if n > upper}
        self.duplicates = {n: v for n, v in self.duplicates.items() if n > upper}
        self.lower = upper
        return result

    def coverage(self, epoch: int) -> IntervalResult:
        result = IntervalResult(
            epoch,
            "snapshot",
            received_unique_sn_count=len(self.frames),
            duplicates=dict(self.duplicates),
            duplicate_frames=sum(self.duplicates.values()),
        )
        cursor = self.lower + 1
        for sn, (source, length) in sorted(self.frames.items()):
            if sn > cursor:
                _detail(result, "missing", cursor, sn - 1)
            cursor = sn + 1
            _add_received(result.received, source, 1, length)
        if cursor <= self.upper:
            _detail(result, "missing", cursor, self.upper)
        return result


def _add_received(
    counts: dict[int, Received], source: int, frames: int, size: int
) -> None:
    count = counts.setdefault(source, Received())
    count.frames += frames
    count.bytes += size


def _merge(result: IntervalResult, part: IntervalResult) -> None:
    result.duplicates.update(part.duplicates)
    result.duplicate_frames += part.duplicate_frames
    if result.received_unique_sn_count is None:
        return
    result.received_unique_sn_count += part.received_unique_sn_count or 0
    result.missing_sn_count += part.missing_sn_count
    for source, value in part.received.items():
        count = result.received.setdefault(source, Received())
        count.frames += value.frames
        count.bytes += value.bytes
    ranges = sorted(result.missing_ranges + part.missing_ranges)
    result.details_truncated |= len(ranges) > _PREVIEW
    result.missing_ranges = ranges[:_PREVIEW]
    result.details_truncated |= part.details_truncated


class LogChecker:
    """Feed owned (blfd >=0.2.1) or borrowed frames in reception order.

    Settled windows leave memory. Finish returns owned summaries and removes the
    scratch file; close also removes it when a caller cancels or parsing fails.
    """

    _window_type = _Window

    def __init__(
        self, input_path: str | Path | None = None, *, max_pending_frames: int = 500_000
    ) -> None:
        if max_pending_frames <= 0:
            raise ValueError("max_pending_frames must be positive")
        path = Path(input_path) if input_path is not None else None
        try:
            self._file = tempfile.NamedTemporaryFile(  # noqa: SIM115 - owned until finish/close
                mode="w",
                encoding="utf-8",
                delete=False,
                suffix=".checker.tmp",
                prefix=f"{path.stem if path else 'ble-log'}-",
                dir=path.parent if path else None,
            )
        except OSError:
            self._file = tempfile.NamedTemporaryFile(  # noqa: SIM115 - owned until finish/close
                mode="w", encoding="utf-8", delete=False, suffix=".checker.tmp"
            )
        self.archive_path = Path(self._file.name)
        self._max_pending = max_pending_frames
        self._protocol: str | None = None
        # Preserve source-local prefix evidence until an INTERNAL record selects the path.
        self._per_source: _PerSourceStats | None = _PerSourceStats(max_pending_frames)
        self._epoch = 0
        # Feed order is transport order, so this counts rows for the run report.
        self._fed_frames = 0
        self._result: CheckResult | None = None
        self._reset_epoch()

    def close(self) -> None:
        try:
            if getattr(self, "_file", None) is not None:
                self._file.close()
                Path(self._file.name).unlink(missing_ok=True)
        finally:
            if hasattr(self, "_open"):
                self._open.frames.clear()
                self._open.duplicates.clear()
                self._windows.clear()
                self._head_window.frames.clear()
                self._head_window.duplicates.clear()
            per_source = getattr(self, "_per_source", None)
            if per_source is not None:
                per_source.frames.clear()
                per_source.observed.clear()
                per_source.sequences.clear()

    def __del__(self) -> None:
        try:
            self.close()
        except OSError:
            pass

    def _write(self, row: dict[str, Any]) -> None:
        self._file.write(json.dumps(row, separators=(",", ":")) + "\n")
        self._file.flush()

    def _read(self) -> Iterator[dict[str, Any]]:
        with self.archive_path.open(encoding="utf-8") as archive:
            for line in archive:
                yield json.loads(line)

    def _reset_epoch(self) -> None:
        self._first: Anchor | None = None
        self._last: Anchor | None = None
        self._first_stats: dict[int, dict[str, int]] = {}
        self._recent: deque[tuple[Anchor, bytes]] = deque(maxlen=4)
        self._first_identity = self._last_identity = b""
        self._flush_sn: int | None = None
        self._source_received: dict[int, Received] = {}
        self._accounting: IntervalResult | None = None
        self._anchor_gap = False
        self._notes: list[str] = []
        self._observed: dict[int, Received] = {}
        self._open = self._window_type()
        self._windows: list[_Window] = []
        self._periods = self._pending = 0
        self._head = self._independent = self._highest = 0
        self._head_first_sn: int | None = None
        self._head_window = self._window_type()
        self._head_incomplete = False
        self._late = 0
        self._snapshot_conflict = False
        self._settled_upper: int | None = None
        self._init_identity: tuple[int, bytes] | None = None
        self._known_firmware_loss = False
        self._write_fail_unknown: tuple[int, str] | None = None

    def _note(self, message: str) -> None:
        if message not in self._notes:
            self._notes.append(message)

    def _accounting_note(self, message: str) -> None:
        if self._accounting is not None:
            self._accounting.status = "insufficient_evidence"
            if message not in self._accounting.notes:
                self._accounting.notes.append(message)

    def _record_head(self, sn: int, source: int, size: int, repeats: int = 0) -> None:
        self._head += 1 + repeats
        self._head_first_sn = (
            sn if self._head_first_sn is None else min(self._head_first_sn, sn)
        )
        if sn in self._head_window.frames:
            repeats += 1
        elif len(self._head_window.frames) < self._max_pending:
            self._head_window.frames[sn] = (source, size)
        else:
            self._head_incomplete = True
            return
        if repeats:
            self._head_window.duplicates[sn] = (
                self._head_window.duplicates.get(sn, 0) + repeats
            )

    def feed(self, frame: "FrameView | BleLogFrame") -> None:
        if self._result is not None or self._file.file.closed:
            raise RuntimeError("Cannot feed a finished or closed checker")
        # FrameView did not exist in blfd 0.2.1; no runtime import is needed.
        if hasattr(frame, "payload_view"):
            view = cast("FrameView", frame)
            source, raw = view.source_code, view.raw_sn
            payload, offset, size = (
                view.payload_view,
                view.payload_offset,
                view.payload_size,
            )
        else:
            owned = cast(BleLogFrame, frame)
            source, raw = owned.source_code, owned.sequence_number
            payload, offset, size = owned.payload, owned.offset + 6, len(owned.payload)
        if not 0 <= source <= 8 or not 0 <= raw < _PERIOD or len(payload) != size:
            raise ValueError("Invalid frame metadata")
        row = self._fed_frames
        self._fed_frames += 1
        subtype = payload[4] if source == 0 and len(payload) >= 5 else 255
        if self._protocol is None and source == 0:
            if not is_valid_internal_candidate(payload):
                raise ValueError(
                    "Invalid INTERNAL payload shape; feed validated frames using "
                    "FrameDecoder(candidate_policies=FRAME_CANDIDATE_POLICIES). "
                    "Import FRAME_CANDIDATE_POLICIES from ble_log_frame_decoder.checking.protocol"
                )
            # Select once; only the undecided/older path needs content fingerprints.
            self._protocol = (
                "snapshot" if subtype in (SNAPSHOT, TASK_BINDING) else "per_source"
            )
            if self._protocol == "snapshot":
                assert self._per_source is not None
                prefix = self._per_source
                self._observed, self._notes = prefix.observed, prefix.notes
                self._independent = prefix.observed.get(8, Received()).frames
                for sn, records in prefix.frames.items():
                    for (src, _), (_, length, repeats, _) in records.items():
                        if 1 <= src <= 7:
                            self._record(self._open, sn, src, length, repeats)
                self._per_source = None
            else:
                assert self._per_source is not None
                self._per_source.select()
        if self._per_source is not None:
            self._feed_per_source(
                source,
                raw,
                subtype,
                payload,
                hashlib.sha256(payload).hexdigest()
                if self._protocol is None or (source == 0 and subtype in (0, 6))
                else "",
                offset,
                row,
            )
        else:
            self._feed_snapshot(source, raw, subtype, payload, offset)

    def _record(
        self, window: _Window, sn: int, source: int, size: int, repeats: int = 0
    ) -> None:
        if sn in window.frames:
            repeats += 1
        elif self._pending < self._max_pending:
            window.frames[sn] = (source, size)
            self._pending += 1
            if self._flush_sn is not None and sn <= self._flush_sn and 1 <= source <= 7:
                _add_received(self._source_received, source, 1, size)
        else:
            self._note(
                "Pending frame budget exceeded; exact coverage for this lifecycle is unavailable"
            )
            if self._flush_sn is not None and sn <= self._flush_sn:
                self._accounting_note(
                    "Pending frame budget exceeded within INIT-to-FLUSH range"
                )
            return
        if repeats:
            window.duplicates[sn] = window.duplicates.get(sn, 0) + repeats

    def _feed_per_source(
        self,
        source: int,
        raw: int,
        subtype: int,
        payload: bytes | memoryview,
        digest: str,
        offset: int,
        transport_row: int,
    ) -> None:
        assert self._per_source is not None
        is_final = (source, subtype) == (0, 6)
        if is_final and any(
            row.get("identity") == [raw, digest]
            and row["epoch"] == self._per_source.epoch
            for row in self._read()
        ):
            return
        result = self._per_source.feed(
            source, raw, subtype, payload, digest, offset, transport_row
        )
        if result is not None:
            self._save(result, identity=[raw, digest] if is_final else None)

    def _feed_snapshot(
        self,
        source: int,
        raw: int,
        subtype: int,
        payload: bytes | memoryview,
        offset: int,
    ) -> None:
        size = len(payload)
        snap = parse_snapshot(payload) if source == 0 and subtype == SNAPSHOT else None
        identity = bytes(payload) if snap is not None else b""
        is_init = bool(snap and snap.reason_flags & INIT)
        if is_init and (raw, identity) != self._init_identity:
            if self._observed:
                self._finish_epoch()
                self._epoch += 1
                self._reset_epoch()
            self._init_identity = (raw, identity)

        if snap is not None:
            self._known_firmware_loss |= any(s.lost_frame_cnt > 0 for s in snap.stats)

        count = self._observed.setdefault(source, Received())
        count.frames += 1
        count.bytes += size + 10
        independent = source == 8 or (source, subtype) == (0, TASK_BINDING)
        self._independent += int(independent)
        if independent:
            return
        sn = self._last.sn + _distance(raw, self._last.sn) if self._last else raw
        anchor_new = False
        if snap is not None:
            sn, anchor_new = self._anchor(raw, identity, offset, snap)
        if self._last is not None and (raw - self._last.sn) % _PERIOD == _PERIOD // 2:
            self._note("Frame SN has half-ring ambiguity")
            self._accounting_note("Frame SN has half-ring ambiguity")
        if self._first is not None and sn <= self._first.sn:
            self._record_head(sn, source, size + 10)
        elif self._settled_upper is not None and sn <= self._settled_upper:
            self._late += 1  # Expired windows are immutable summaries, not replay logs.
            if self._flush_sn is not None and sn <= self._flush_sn:
                self._accounting_note(
                    "Expired arrivals in INIT-to-FLUSH range; archived counts are unchanged"
                )
        else:
            self._highest = max(self._highest, sn)
            window = next(
                (w for w in self._windows if w.lower < sn <= w.upper), self._open
            )
            self._record(window, sn, source, size + 10)

        if anchor_new and snap is not None and snap.reason_flags & PERIODIC:
            self._periods += 1
            if sn > self._open.lower:
                self._windows.append(self._open.split(sn, self._periods + 3))
            self._settle()

    def _write_fail_uncertain(self, sn: int, reason: str) -> None:
        if self._write_fail_unknown is None or sn < self._write_fail_unknown[0]:
            self._write_fail_unknown = (sn, reason)

    def _anchor(
        self, raw: int, identity: bytes, offset: int, snap: Snapshot
    ) -> tuple[int, bool]:
        for point, previous in [
            (self._first, self._first_identity),
            (self._last, self._last_identity),
        ] + list(self._recent):
            if point is not None and point.sn % _PERIOD == raw and previous == identity:
                return point.sn, False
        if self._last is None:
            sn = raw
            window = self._window_type(lower=sn)
            for previous_sn, value in self._open.frames.items():
                if (previous_sn - sn) % _PERIOD == _PERIOD // 2:
                    self._note("Pre-anchor frame SN has half-ring ambiguity")
                expanded = sn + _distance(previous_sn, sn)
                repeats = self._open.duplicates.get(previous_sn, 0)
                if expanded <= sn:
                    self._record_head(expanded, value[0], value[1], repeats)
                else:
                    window.frames[expanded] = value
                    if repeats:
                        window.duplicates[expanded] = repeats
            self._open = window
            self._pending = len(window.frames)
            self._highest = max([sn, *window.frames])
        else:
            delta = (raw - self._last.sn) % _PERIOD
            count_delta = (snap.anchor_count - self._last.anchor_count) % _PERIOD
            if not 0 < delta < _PERIOD // 2 or not 0 < count_delta < _PERIOD // 2:
                self._snapshot_conflict = True
                sn = self._last.sn + _distance(raw, self._last.sn)
                self._write_fail_uncertain(sn, "conflicting or reordered snapshot")
                known = any(sn in w.frames for w in [self._open, *self._windows])
                expired = self._settled_upper is not None and sn <= self._settled_upper
                if not known and not expired:
                    self._note(
                        "Snapshot sequence is conflicting, reordered or wrap-ambiguous"
                    )
                    if self._flush_sn is not None and sn <= self._flush_sn:
                        self._accounting_note(
                            "Ambiguous snapshot within INIT-to-FLUSH range"
                        )
                return sn, False
            sn = self._last.sn + delta
            self._anchor_gap |= count_delta != 1
            previous = parse_snapshot(self._last_identity)
            if any(
                current.lost_frame_cnt < old.lost_frame_cnt
                or current.written_frame_cnt < old.written_frame_cnt
                or current.written_bytes_cnt < old.written_bytes_cnt
                for current, old in zip(snap.stats, previous.stats)
            ):
                self._write_fail_uncertain(sn, "counter decrease, reset or wrap")
        stats = {i + 1: asdict(value) for i, value in enumerate(snap.stats)}
        self._last = Anchor(sn, snap.anchor_count, offset, snap.reason_flags)
        self._last_identity = identity
        if self._first is None:
            self._first, self._first_stats, self._first_identity = (
                self._last,
                stats,
                identity,
            )
        if snap.reason_flags & PERIODIC:
            self._recent.append((self._last, identity))
        if snap.reason_flags & FLUSH and self._flush_sn is None:
            self._flush_sn = sn
            if self._first.reason_flags & INIT:
                # Earlier archived windows are already accumulated. Include only
                # this range's active SNs; post-FLUSH frames may have arrived early.
                for window in [*self._windows, self._open]:
                    for n, (source, size) in window.frames.items():
                        if n <= sn and 1 <= source <= 7:
                            _add_received(self._source_received, source, 1, size)
                self._accounting = IntervalResult(
                    self._epoch,
                    "snapshot",
                    scope="init_flush",
                    start_anchor=self._first,
                    upper_anchor=self._last,
                    received=self._source_received,
                    firmware_end=stats,
                    notes=list(self._notes),
                    status="insufficient_evidence" if self._notes else "reported",
                )
                if self._anchor_gap:
                    self._accounting_note(
                        "Snapshot count gap: an unobserved FLUSH/reset cannot be excluded"
                    )
                if self._late:
                    self._accounting_note(
                        "Expired arrivals before FLUSH; archived counts are unchanged"
                    )
                if any(
                    value
                    for counters in self._first_stats.values()
                    for value in counters.values()
                ):
                    self._accounting_note(
                        "INIT counters are not zero; the accounting baseline is unproven"
                    )
        return sn, True

    def _archive(self, window: _Window, reason: str) -> None:
        summary = window.coverage(self._epoch)
        if (
            self._flush_sn is None
            and self._first is not None
            and self._first.reason_flags & INIT
        ):
            for source, count in summary.received.items():
                if 1 <= source <= 7:
                    _add_received(
                        self._source_received, source, count.frames, count.bytes
                    )
        self._write(
            {
                "kind": "window",
                "epoch": self._epoch,
                "lower": window.lower,
                "upper": window.upper,
                "deadline": window.deadline,
                "settled": reason,
                "summary": asdict(summary),
            }
        )

    def _settle(self) -> None:
        for window in self._windows[:]:
            if self._periods >= window.deadline:
                self._archive(window, "deadline")
                self._settled_upper = window.upper
                self._pending -= len(window.frames)
                self._windows.remove(window)

    def _base(self, protocol: str, scope: str = "trusted") -> IntervalResult:
        result = IntervalResult(
            self._epoch,
            protocol,
            scope=scope,
            notes=list(self._notes),
            observed={
                k: Received(v.frames, v.bytes) for k, v in self._observed.items()
            },
        )
        result.observed_frames = sum(v.frames for v in self._observed.values())
        if self._notes:
            result.status = "insufficient_evidence"
        return result

    def _save(self, result: IntervalResult, **extra: Any) -> None:
        self._write(
            {
                "kind": "result",
                "epoch": result.epoch,
                "summary": asdict(result),
                **extra,
            }
        )

    def _write_fail_summary(self, result: IntervalResult) -> None:
        assert self._first is not None and self._last is not None
        trusted = result.upper_anchor is not None
        end = parse_snapshot(self._recent[0][1] if trusted else self._last_identity)
        endpoint = result.upper_anchor or self._last
        result.write_fail_start = {
            source: stats["lost_frame_cnt"]
            for source, stats in self._first_stats.items()
        }
        result.write_fail_end = {
            source: stats.lost_frame_cnt for source, stats in enumerate(end.stats, 1)
        }
        reason = None
        if self._flush_sn is not None and self._flush_sn < endpoint.sn:
            reason = "range crosses FLUSH; counter reset completion is unproven"
        elif self._write_fail_unknown and self._write_fail_unknown[0] <= endpoint.sn:
            reason = self._write_fail_unknown[1]
        elif self._first.reason_flags & INIT and any(
            count for stats in self._first_stats.values() for count in stats.values()
        ):
            reason = "INIT counters are not zero"
        if reason:
            result.notes.append(f"Write-fail count unknown: {reason}")
            return
        result.write_failed_by_source = {
            source: count - result.write_fail_start[source] if trusted else count
            for source, count in result.write_fail_end.items()
        }
        result.write_failed_count = sum(result.write_failed_by_source.values())
        if trusted:
            result.notes.append(
                "Write-fail count is the selected anchor sampling delta"
            )
        else:
            result.notes.append(
                "Write-fail count is the last cumulative sample; may include failures before recording and excludes the unsampled tail"
            )

    def _modern_summary(self) -> None:
        assert self._first is not None and self._last is not None
        result = self._base("snapshot")
        result.known_firmware_loss = self._known_firmware_loss
        result.start_anchor, result.last_anchor = self._first, self._last
        trusted = len(self._recent) == 4 and self._recent[0][0].sn > self._first.sn
        if trusted:
            result.upper_anchor = self._recent[0][0]
        else:
            result.status = "insufficient_evidence"
            result.notes.append(
                "No nonempty trusted interval with three subsequent periodic anchors"
            )
        upper = result.upper_anchor.sn if result.upper_anchor else self._first.sn
        result.expected_sn_count = upper - self._first.sn
        result.received_unique_sn_count = 0 if result.status == "reported" else None
        if self._accounting is None:
            result.notes.append(
                "Per-source accounting unavailable: a captured INIT and its first FLUSH are required"
            )
        if not self._first.reason_flags & INIT:
            result.notes.append(
                "Recording starts mid-lifecycle; prefix reported separately as head"
            )
        result.independent_frames, result.excluded_head_frames = (
            self._independent,
            self._head,
        )
        result.head_first_sn = self._head_first_sn
        result.snapshot_conflict = self._snapshot_conflict
        result.late_frames = self._late
        if self._late:
            result.status = "insufficient_evidence"
            result.notes.append(
                "Frames arrived after the three-period deadline; archived coverage is unchanged"
            )
        self._write_fail_summary(result)
        self._save(result)
        tail = self._base("snapshot", "tail")
        tail.start_anchor = result.upper_anchor or self._first
        tail.last_anchor = tail.upper_anchor = self._last
        tail.expected_sn_count = max(self._last.sn, self._highest) - upper
        tail.received_unique_sn_count = 0 if tail.status == "reported" else None
        tail.unanchored_tail_frames = sum(
            1 + self._open.duplicates.get(sn, 0)
            for sn in self._open.frames
            if sn > self._last.sn
        )
        tail.notes.append(
            "EOF observations, not the trusted three-period interval; trailing data has no closing anchor"
        )
        self._save(tail)
        assert self._head_first_sn is not None
        head = self._base("snapshot", "head")
        head.head_first_sn = self._head_first_sn
        head.upper_anchor = self._first
        head.expected_sn_count = self._first.sn - self._head_first_sn + 1
        head.observed_frames = self._head
        if self._head_incomplete:
            head.status = "insufficient_evidence"
            head.notes.append(
                "Head frame budget exceeded; exact head coverage is unavailable"
            )
        head.received_unique_sn_count = 0 if head.status == "reported" else None
        self._head_window.lower = self._head_first_sn - 1
        self._head_window.upper = self._first.sn
        _merge(head, self._head_window.coverage(self._epoch))
        head.notes.append(
            "Observed prefix only; loss before the earliest observed SN is unknown"
        )
        self._save(head)
        if self._accounting is not None:
            if self._accounting.status == "reported":
                self._accounting.written_frame_difference = {
                    source: stats["written_frame_cnt"]
                    - self._source_received.get(source, Received()).frames
                    for source, stats in self._accounting.firmware_end.items()
                }
            self._save(self._accounting)

    def _finish_epoch(self) -> None:
        if self._per_source is not None:
            self._finish_per_source_epoch()
        else:
            self._finish_snapshot_epoch()

    def _finish_per_source_epoch(self) -> None:
        assert self._per_source is not None
        result = self._per_source.finish()
        if result is not None:
            if self._protocol is None:
                result.protocol = "unknown"
                result.status = "insufficient_evidence"
                result.notes = list(self._per_source.notes) + [
                    "No protocol evidence; statistics cannot be matched to a firmware interval"
                ]
            self._save(result)

    def _finish_snapshot_epoch(self) -> None:
        if self._first is not None:
            for window in self._windows:
                self._archive(window, "eof")
            self._open.upper = max(self._highest, self._last.sn if self._last else 0)
            if self._open.upper > self._open.lower:
                self._archive(self._open, "tail")
            self._modern_summary()
        elif self._open.frames:
            # Without an anchor, use the first observed SN as the half-ring reference.
            reference = next(iter(self._open.frames))
            window = self._window_type()
            for raw, record in self._open.frames.items():
                if (raw - reference) % _PERIOD == _PERIOD // 2:
                    self._note("Frame SN has half-ring ambiguity")
                sn = reference + _distance(raw, reference)
                window.frames[sn] = record
                if raw in self._open.duplicates:
                    window.duplicates[sn] = self._open.duplicates[raw]
            window.lower = min(window.frames) - 1
            window.upper = max(window.frames)
            if window.upper - window.lower - 1 >= _PERIOD // 2:
                self._note("Observed SN range without anchors spans half a ring")
            result = self._base("snapshot", "best_effort")
            result.head_first_sn = window.lower + 1
            result.expected_sn_count = window.upper - window.lower
            result.received_unique_sn_count = 0 if result.status == "reported" else None
            result.independent_frames = self._independent
            _merge(result, window.coverage(self._epoch))
            result.notes.append(
                "No SNAPSHOT; observed Global SN range only, outside coverage unknown"
            )
            self._save(result)
        elif self._observed:
            result = self._base(self._protocol or "unknown")
            result.status = "insufficient_evidence"
            result.notes.append(
                "No SNAPSHOT establishes a statistics interval"
                if self._protocol == "snapshot"
                else "No protocol evidence; statistics cannot be matched to a firmware interval"
            )
            result.excluded_tail_frames = result.observed_frames
            self._save(result)

    def finish(self, scan_stats: DecodeStats | None = None) -> CheckResult:
        if self._result is not None:
            return self._result
        if self._file.closed:
            raise RuntimeError("Checker is closed")
        try:
            self._finish_epoch()
            intervals = [
                _interval(row["summary"])
                for row in self._read()
                if row["kind"] == "result"
            ]
            modern = {
                (r.epoch, r.scope): r for r in intervals if r.protocol == "snapshot"
            }
            for row in self._read():
                if row["kind"] != "window":
                    continue
                trusted = modern[row["epoch"], "trusted"]
                endpoint = trusted.upper_anchor or trusted.start_anchor
                assert endpoint is not None
                upper = endpoint.sn
                scope = "trusted" if row["upper"] <= upper else "tail"
                part = _interval(row["summary"])
                if scope == "tail":
                    trusted.excluded_tail_frames += (
                        sum(v.frames for v in part.received.values())
                        + part.duplicate_frames
                    )
                _merge(modern[row["epoch"], scope], part)
            for interval in intervals:
                if interval.protocol == "snapshot" and interval.scope in (
                    "trusted",
                    "best_effort",
                ):
                    if interval.write_fail_end is None:
                        interval.notes.append(
                            "Write-fail count unknown: no SNAPSHOT sample"
                        )
                    if interval.expected_sn_count:
                        _attribute_transport(interval, interval.scope == "trusted")
            status = (
                "reported"
                if intervals
                and all(r.status == "reported" for r in intervals if r.scope != "tail")
                else "insufficient_evidence"
            )
            self._result = CheckResult(
                status,
                intervals,
                asdict(scan_stats) if scan_stats is not None else {},
                [
                    "Statistics only; missing SNs and firmware losses are separate. Three periods are a lateness policy, not a physical TX guarantee."
                ],
            )
            return self._result
        finally:
            self.close()
