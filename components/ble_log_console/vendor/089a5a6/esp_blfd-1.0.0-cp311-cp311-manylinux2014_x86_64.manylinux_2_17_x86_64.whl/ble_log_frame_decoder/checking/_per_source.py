"""Older v2 accounting: FINAL_STAT counts, otherwise observed source-local SNs."""

from collections.abc import Iterator
from dataclasses import dataclass, field
from itertools import islice

from .protocol import is_sequence_restart, parse_final_stat
from .results import IntervalResult, Received, SnRun, _attribute_transport

_PERIOD = 1 << 24
_WORD_BITS = 1024


def _merged_spans(spans: list[tuple[int, int]]) -> list[tuple[int, int]]:
    """Overlapping spans combined, so a shared range is measured once."""
    merged: list[tuple[int, int]] = []
    for low, high in sorted(span for span in spans if span[0] <= span[1]):
        if merged and low <= merged[-1][1] + 1:
            merged[-1] = (merged[-1][0], max(merged[-1][1], high))
        else:
            merged.append((low, high))
    return merged


@dataclass(slots=True)
class _Run:
    """One continuous stretch of a source's unfolded numbers, before ownership."""

    first: int
    last: int
    count: int
    first_row: int | None
    last_row: int | None


@dataclass(slots=True)
class _Sequence:
    # Sparse bitmaps keep long captures compact without retaining frame payloads.
    words: dict[int, int] = field(default_factory=dict)
    first: int | None = None
    last: int | None = None
    count: int = 0
    bytes: int = 0
    repeats: int = 0
    ambiguous: bool = False
    # Arrival-order state, so a restart is visible without the retained payloads.
    previous: int | None = None
    runs: list[_Run] = field(default_factory=list)
    # Highest number any run covers, so an in-order arrival takes the fast path.
    top: int | None = None

    def unfold(self, raw: int) -> int:
        if self.last is None:
            return raw
        delta = (raw - self.last) % _PERIOD
        if delta == _PERIOD // 2:
            self.ambiguous = True
        return self.last + ((delta + _PERIOD // 2) % _PERIOD - _PERIOD // 2)

    def add(self, sn: int, length: int, row: int | None = None) -> None:
        word, bit = divmod(sn, _WORD_BITS)
        mask = 1 << bit
        old = self.words.get(word, 0)
        if old & mask:
            self.repeats += 1
            return
        self.words[word] = old | mask
        self.first = sn if self.first is None else min(self.first, sn)
        self.last = sn if self.last is None else max(self.last, sn)
        self.count += 1
        self.bytes += length
        # A backward step to a low value is a restart, not a wrap (unfold()
        # already turned a real 24-bit wrap into a forward step) and not a small
        # out-of-order arrival.
        if self.previous is not None and is_sequence_restart(self.previous, sn):
            self.runs.append(_Run(sn, sn, 1, row, row))
        elif self.runs:
            run = self._run_of(sn)
            run.first = min(run.first, sn)
            run.last = max(run.last, sn)
            run.count += 1
            run.last_row = row
        else:
            self.runs.append(_Run(sn, sn, 1, row, row))
        if self.top is None or sn > self.top:
            self.top = sn
        self.previous = sn

    def _run_of(self, sn: int) -> _Run:
        """The run whose range already owns this number, else the newest run.

        A late arrival from before a restart belongs to the run that already
        observed its neighbours; letting it extend the newest run would stretch
        that run's range back across the restart seam.
        """
        newest = self.runs[-1]
        if self.top is None or sn > self.top:
            return newest
        for run in self.runs:
            if run.first <= sn <= run.last:
                return run
        return newest

    def count_in(self, first: int, last: int) -> int:
        """Observed numbers inside an inclusive range."""
        total = 0
        for word, bits in self.words.items():
            base = word * _WORD_BITS
            start, end = max(first, base), min(last + 1, base + _WORD_BITS)
            if start < end:
                total += (
                    (bits >> (start - base)) & ((1 << (end - start)) - 1)
                ).bit_count()
        return total

    def run_missing(self, index: int) -> int:
        """Absent numbers this run owns.

        Every absent number inside a run's range is loss: a restart does not make
        a hole inside a continuous run explainable. Two runs can still cover the
        same numbers (a restarted sequence climbing through numbers the run
        before it already used), so the absence an earlier run's range already
        accounts for is removed here and each absent number is counted once.
        """
        run = self.runs[index]
        absent = run.last - run.first + 1 - self.count_in(run.first, run.last)
        shared = [
            (max(run.first, earlier.first), min(run.last, earlier.last))
            for earlier in self.runs[:index]
        ]
        for low, high in _merged_spans(shared):
            absent -= high - low + 1 - self.count_in(low, high)
        return absent

    def gaps(self, first: int, last: int) -> Iterator[tuple[int, int]]:
        """Yield missing runs, merging runs that cross bitmap word boundaries."""
        cursor = first
        for word, bits in sorted(self.words.items()):
            base = word * _WORD_BITS
            start, end = max(first, base), min(last + 1, base + _WORD_BITS)
            if start >= end:
                continue
            bits = (bits >> (start - base)) & ((1 << (end - start)) - 1)
            while bits:
                zeros = (bits & -bits).bit_length() - 1
                start += zeros
                bits >>= zeros
                if start > cursor:
                    yield cursor, start - 1
                ones = (bits ^ (bits + 1)).bit_length() - 1
                start += ones
                bits >>= ones
                cursor = start
        if cursor <= last:
            yield cursor, last

    def final_range(self, attempts: int) -> "_Sequence":
        """Counter-bounded coverage uses raw SNs, even after an outlier skewed unfolding."""
        words: dict[int, int] = {}
        for word, bits in self.words.items():
            word %= _PERIOD // _WORD_BITS
            width = min(_WORD_BITS, attempts - word * _WORD_BITS)
            if width > 0:
                words[word] = words.get(word, 0) | (bits & ((1 << width) - 1))
        return _Sequence(
            words=words, count=sum(bits.bit_count() for bits in words.values())
        )


class _PerSourceStats:
    def __init__(self, max_pending: int) -> None:
        self.max_pending = max_pending
        self.epoch = 0
        self.retain_prefix = True
        self._reset_epoch()

    def _reset_epoch(self) -> None:
        # Only the undecided protocol prefix needs content-aware frame records.
        self.frames: dict[int, dict[tuple[int, str], list[int]]] = {}
        self.pending = 0
        self.block = 0
        self.has_final = False
        self.init_identity: tuple[int, str] | None = None
        self._reset_block()

    def _reset_block(self) -> None:
        self.observed: dict[int, Received] = {}
        self.sequences: dict[int, _Sequence] = {}
        self.notes: list[str] = []
        self.word_count = 0
        self.degraded = False

    def select(self) -> None:
        self.retain_prefix = False
        self.frames.clear()
        self.notes = [n for n in self.notes if not n.startswith("Pending frame budget")]

    def feed(
        self,
        source: int,
        raw: int,
        subtype: int,
        payload: bytes | memoryview,
        digest: str,
        offset: int,
        row: int | None = None,
    ) -> IntervalResult | None:
        completed = None
        if (source, subtype) == (0, 0) and (raw, digest) != self.init_identity:
            if self.observed or self.has_final:
                completed = self.finish()
                self.epoch += 1
                self._reset_epoch()
            self.init_identity = (raw, digest)
        if (source, subtype) == (0, 6):
            completed = self._summary(parse_final_stat(payload).stats, offset, raw)
            self._reset_block()
            self.block += 1
            self.has_final = True
            return completed

        length = len(payload) + 10
        count = self.observed.setdefault(source, Received())
        count.frames += 1
        count.bytes += length
        sequence = self.sequences.setdefault(source, _Sequence())
        sn = sequence.unfold(raw)
        if sn // _WORD_BITS not in sequence.words:
            if self.word_count >= self.max_pending:
                self.degraded = True
                if self.retain_prefix and not self.notes:
                    self.notes.append(
                        "Pending frame budget exceeded in protocol prefix"
                    )
                return completed
            self.word_count += 1
        sequence.add(sn, length, row)
        if self.retain_prefix:
            records = self.frames.setdefault(raw, {})
            if (source, digest) in records:
                records[source, digest][2] += 1
            elif self.pending < self.max_pending:
                records[source, digest] = [subtype, length, 0, 0]
                self.pending += 1
            else:
                if not self.notes:
                    self.notes.append(
                        "Pending frame budget exceeded in protocol prefix"
                    )
                if not records:
                    del self.frames[raw]
        return completed

    def _summary(
        self,
        stats: dict[int, dict[str, int]] | None = None,
        offset: int | None = None,
        final_sn: int = 0,
    ) -> IntervalResult:
        result = IntervalResult(
            self.epoch,
            "legacy-sn",
            scope=f"legacy:{self.block}",
            observed={k: Received(v.frames, v.bytes) for k, v in self.observed.items()},
            observed_frames=sum(v.frames for v in self.observed.values()),
            notes=list(self.notes),
            final_stat_offset=offset,
        )
        matched = stats is not None and (
            not self.has_final
            or final_sn == 0
            or any(s.first == 0 for s in self.sequences.values())
        )
        final_sequences: dict[int, _Sequence] = {}
        if stats is not None:
            result.firmware_end = stats
            for source in stats.keys() | self.sequences.keys():
                expected = stats.get(source)
                seq = self.sequences.get(source)
                attempts = (
                    expected["written_frame_cnt"] + expected["lost_frame_cnt"]
                    if expected
                    else 0
                )
                coverage = (seq or _Sequence()).final_range(attempts)
                final_sequences[source] = coverage
                if attempts >= _PERIOD or coverage.count > (
                    expected["written_frame_cnt"] if expected else 0
                ):
                    matched = False
            if matched:
                result.protocol = "legacy-final-stat"
                result.notes.append(
                    "FINAL_STAT counts include unrecorded prefix frames; FINAL_STAT itself is excluded"
                )
            else:
                result.notes.append(
                    "FINAL_STAT cannot be matched to this SN interval; using observed SN ranges"
                )
        if not matched:
            result.notes.append(
                "Observed source-local SN ranges only; data before/after these ranges is unknown"
            )
        result.expected_sn_count = 0
        result.received_unique_sn_count = 0
        sources = (
            stats.keys() | self.sequences.keys()
            if matched and stats is not None
            else self.sequences.keys()
        )
        for source in sorted(sources):
            seq = self.sequences.get(source, _Sequence())
            # Preserve raw unique arrivals/bytes for diagnostics; coverage is filtered below.
            result.received[source] = Received(seq.count, seq.bytes)
            result.duplicate_frames += seq.repeats
            if matched and stats is not None:
                coverage = final_sequences[source]
                excluded = seq.count - coverage.count
                result.excluded_sn_count += excluded
                if excluded:
                    result.notes.append(
                        f"Source {source}: excluded {excluded} SN observations from FINAL_STAT coverage"
                    )
                seq = coverage
                expected = stats[source]
                first, last = (
                    0,
                    expected["written_frame_cnt"] + expected["lost_frame_cnt"] - 1,
                )
                result.written_frame_difference[source] = (
                    expected["written_frame_cnt"] - seq.count
                )
            elif seq.first is not None and seq.last is not None:
                first, last = seq.first, seq.last
                if seq.runs:
                    result.source_runs[source] = [
                        SnRun(
                            source,
                            index,
                            run.first,
                            run.last,
                            run.count,
                            seq.run_missing(index - 1),
                            run.first_row,
                            run.last_row,
                        )
                        for index, run in enumerate(seq.runs, 1)
                    ]
            else:
                continue
            expected_count = last - first + 1
            result.expected_sn_count += expected_count
            result.received_unique_sn_count += seq.count
            result.missing_sn_count += expected_count - seq.count
            if expected_count:
                result.source_sn_ranges[source] = (first, last)
            gaps = list(islice(seq.gaps(first, last), 33))
            if gaps:
                result.source_missing_ranges[source] = gaps[:32]
                result.details_truncated |= len(gaps) > 32
            if seq.ambiguous:
                result.status = "insufficient_evidence"
                result.notes.append(
                    f"Source {source}: ambiguous half-ring SN displacement"
                )
        if self.degraded:
            result.status = "insufficient_evidence"
            result.notes.append(
                "SN bitmap budget exceeded; exact coverage is unavailable"
            )
        if result.status != "reported":
            result.expected_sn_count = result.received_unique_sn_count = None
            result.missing_sn_count = 0
            result.source_missing_ranges.clear()
            result.written_frame_difference.clear()
        if stats is not None:
            result.write_fail_end = {
                source: counters["lost_frame_cnt"] for source, counters in stats.items()
            }
            result.write_failed_by_source = dict(result.write_fail_end)
            result.write_failed_count = sum(result.write_failed_by_source.values())
        else:
            result.notes.append("Write-fail count unknown: no FINAL_STAT sample")
        _attribute_transport(result, matched)
        return result

    def finish(self) -> IntervalResult | None:
        return self._summary() if self.observed else None
