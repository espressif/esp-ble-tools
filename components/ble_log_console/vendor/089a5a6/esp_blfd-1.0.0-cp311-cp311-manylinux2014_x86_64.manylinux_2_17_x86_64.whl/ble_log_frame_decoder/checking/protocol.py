"""State-independent decoding shared by the parser and integrity checker.

The payload decoding moved to ``ble_log_frame_decoder.internal``; this module
remains as the import path used by the checker and the v2 parser. It also owns
the one definition of a sequence restart, which the checker and the ordering
stage both apply.
"""

from ble_log_frame_decoder import (
    FINAL_STAT,
    FLUSH,
    FRAME_CANDIDATE_POLICIES,
    INIT,
    INTERNAL_PAYLOAD_LENGTHS,
    PERIODIC,
    SNAPSHOT,
    SNAPSHOT_PAYLOAD_SIZE,
    TASK_BINDING,
    TS_VALID,
    CandidateValidator,
    FinalStat,
    Snapshot,
    SourceStat,
    is_snapshot,
    is_task_binding,
    is_valid_frame_candidate,
    is_valid_internal_candidate,
    parse_final_stat,
    parse_snapshot,
)

# A sequence restart steps back further than this and resumes at or below it.
# The ordering stage's DetectorConfig.max_forward_sn_gap defaults to this value,
# so a restart is the same event for the checker's run split and for ordering.
RESTART_SN_CEILING = 500


def is_sequence_restart(
    previous: int, current: int, ceiling: int = RESTART_SN_CEILING
) -> bool:
    """Whether an arrival steps a source's sequence back far enough to restart it.

    Unfolding already turns a real 24-bit wrap into a forward step, so a backward
    step is either a restart or a small out-of-order arrival. Only a drop past the
    ceiling that resumes at or below it restarts the sequence; a higher landing
    value is unfolded as a wrap and a shallower drop is reordering.
    """
    return previous - current > ceiling and current <= ceiling


__all__ = [
    "FINAL_STAT",
    "FLUSH",
    "FRAME_CANDIDATE_POLICIES",
    "INIT",
    "INTERNAL_PAYLOAD_LENGTHS",
    "PERIODIC",
    "RESTART_SN_CEILING",
    "SNAPSHOT",
    "SNAPSHOT_PAYLOAD_SIZE",
    "TASK_BINDING",
    "TS_VALID",
    "CandidateValidator",
    "FinalStat",
    "Snapshot",
    "SourceStat",
    "is_sequence_restart",
    "is_snapshot",
    "is_task_binding",
    "is_valid_frame_candidate",
    "is_valid_internal_candidate",
    "parse_final_stat",
    "parse_snapshot",
]
