# BLFD streaming and offline parsing

Shared parsing for v2 BLE Log frames, including older per-source protocols and final v8.
The core has no consumer registry, device ownership, UI, or application acceptance policy.
`esp-blfd` scans once; checker sees every arrival before selection/deduplication/ordering.

## Install for development

Use Python 3.11+ and esp-blfd 1.0.0.dev0. From the Analyzer repository:

```sh
uv pip install -e './ble_log_frame_decoder[offline,host]'
```

`esp-blfd 1.0.0.dev0` is a development version. Framing, checking and parsing ship together.
The base import does not load NumPy, loguru, or the offline parser. `[host]` enables
compressed Host decoding; `[offline]` includes dependencies for complete-file exports.
There is no dependency on the Parser application's `src` package or controller decoders.

## Streaming API

```python
from ble_log_frame_decoder import ParserSession

with ParserSession(
    check=True,
    decode={"host", "hci"},  # also supports "custom"; empty means checker only
    ordering="live",  # "arrival" bypasses content reordering
    database="/path/to/log-db",  # directory containing BLE_HOST_logs.json
) as session:
    batch = session.feed(chunk)
    consume(batch.records)
    consume(session.poll().records)  # call regularly even when transport is idle
    progress = session.snapshot()
    result = session.finish()
    consume(result.records)  # final window / unfinished Host messages
    review(result.integrity)
```

- `feed` returns owned records and the number of all frames decoded in this call.
- `poll` advances the live sorting window. Applications should schedule it regularly
  (e.g. every 50 ms); the core creates no timer or worker thread.
- `snapshot` is nonterminal: scan counts, state, pending ordering count/payload bytes.
  Its integrity is `None` while running. It does **not** turn a partial stream into an EOF verdict.
- `finish` is idempotent, seals the checker, drains content and releases scratch files.
  `finish().integrity` is `None` only when `check=False`.
- `close` cancels and releases state, without inventing final content. Feed/poll/finish
  after cancellation raise `RuntimeError`. Use the context manager or a `finally` block.
- `frame_sink=` optionally receives synchronous borrowed `FrameView`s for existing
  consumers (e.g. INTERNAL/REDIR/text accounting). Do not retain views or call back
  into the session; copy only retained payloads. The checker runs before the sink.
- `decoder=` transfers exclusive use of an explicitly configured **v2** decoder;
  this preserves consumer-specific frame limits/checksum policies. The default is
  XOR32, 4106 bytes, shared INTERNAL candidate validation. v1 stays on its legacy path.
  With `check=True`, a custom decoder must use `FRAME_CANDIDATE_POLICIES` from
  `ble_log_frame_decoder.checking.protocol` (or equivalent INTERNAL validation).
  Invalid INTERNAL frames raise `ValueError` and close the session; no partial
  integrity verdict is returned. The default decoder already applies this policy.
- Instances are independent. Serialize calls within each instance; use separate
  sessions for separate devices. Returned records are immutable; later buffer data
  can return a new version of the same message. Database caches are session-local.

`Record` carries `record_id`, kind, source/SN, optional timestamp/value, text,
raw bytes, `incomplete`, and a diagnostic `reason`. There is no per-record
`uncertain` verdict: recording integrity belongs to Checker.

- A `record_id` identifies one message within a session. It is opaque to consumers;
  implementations use the originating frame's payload offset, so SN reuse after a
  wrap or INIT does not reuse an ID. Custom decoders must preserve stream offsets.
- A pending compressed message is returned immediately after content ordering,
  with its available text and `incomplete=True`. Later buffers return the updated
  text under the same ID, preserving the originating SN and timestamp. Consumers
  may update the existing display entry or append a clearly associated update.
  Do not count each update as another received frame; use scan/checker counts.
- `reason` describes a concrete decode limitation, such as `missing_database`,
  `unknown_clock_unit`, `orphan_buffer`, or `missing_buffer`. Normal sorting-window
  expiry and input completion do not themselves create diagnostic records.
- `incomplete` describes content, not packet loss. At the end of an unfinished
  message, its final update retains available text and reports `missing_buffer`.
  A consumer that has discarded the original row can still display the full update.

CUSTOM value is the observed DUT number (0..4); identity confirmation thresholds
stay in the consumer. HCI text contains timestamp, direction, packet type and
complete packet hex; it is not an opcode/field dissector. A missing version leaves
clock units unknown. Undecodable records retain raw payloads and a hex fallback.

### Firmware counters

Enable `ParserSession(firmware_stats=True)` independently of `check`, `decode`,
and content ordering. Read `session.snapshot().firmware` during recording and
`session.finish().firmware` afterwards. The default is disabled (`None`), preserving
the checker-only native sink. An enabled empty session returns an empty `sources`
tuple. The same session API can scan an existing file in chunks; `export_file` and
its historical checker JSON remain unchanged.

```python
with ParserSession(firmware_stats=True) as session:
    session.feed(chunk)
    for source in session.snapshot().firmware.sources:
        print(source.source, source.latest, source.observed, source.partial)
    result = session.finish()
    firmware = result.firmware  # separate from result.integrity
```

Each immutable `FirmwareSourceStats` contains:

- `source`: numeric firmware source ID, including INTERNAL when reported.
- `latest`: latest accepted raw firmware counters in the current lifecycle;
  `None` after a new INIT until this source reports again.
- `observed`: recording-observed increments, accumulated across lifecycles.
  The four named fields are `written_frame_cnt`, `lost_frame_cnt`,
  `written_bytes_cnt`, and `lost_bytes_cnt` (the immutable `FirmwareCounters` tuple).
- `kind` / `timestamp`: latest sample's `enh_stat`, `final_stat`, or `snapshot`
  origin and raw firmware timestamp; `None` when `latest` is absent.
- `partial`: some counter coverage was omitted or ambiguous. This is **not**
  whole-capture integrity: `False` does not prove that an unreported tail is covered.

`FirmwareSnapshot` contains the source tuple sorted by ID, `epoch` (accepted INIT
count), and diagnostic counts `counter_resets`, `ignored_reports`, `invalid_reports`.
State is bounded by source count, with no retained frame history. Reads do not
advance baselines, and previously returned snapshots never change.

Accounting rules:

- ENH_STAT first establishes a baseline when recording starts mid-interval. For
  example, 10,000 → 11,000 written bytes and 1,000 → 1,100 lost bytes yield observed
  **1,000 / 100**, while `latest` retains **11,000 / 1,100**. A captured legacy INIT
  establishes a zero baseline; protocol-version-zero INIT markers are ignored.
- With a known interval start, FINAL_STAT replaces that interval's ENH accrual.
  Without one, keep only its observed ENH increments. A contradictory smaller
  terminal total is retained as `latest`, but cannot erase observed increments;
  mark `partial`. The next legacy interval starts from zero. Repeated final reports
  do not contribute twice. A new INIT retains prior observed totals.
- v8 uses SNAPSHOT samples for sources 1–7. Its INIT sample is the baseline;
  nonzero INIT counters mark partial coverage. v8 has **no lost-byte counter**:
  both `latest.lost_bytes_cnt` and `observed.lost_bytes_cnt` are `None`, never
  inferred from packet size. Accumulating a lifecycle with unknown lost bytes
  keeps that field unknown for the recording.
- Counter decreases re-establish a baseline and mark partial coverage, rather
  than inventing negative increments or a counter wrap. Legacy FLUSH invalidates
  the incremental baseline while awaiting FINAL_STAT. v8 FLUSH is sampled before
  reset completion; its following sample becomes a fresh baseline. Missing v8
  anchors can hide a FLUSH, so those gaps also rebaseline and mark partial coverage.
- Older reports and repeated lifecycle/final/snapshot markers are ignored. Firmware
  timestamp ordering uses 32-bit modular distance (successive samples must be less
  than half a clock period apart); v8 also validates SN/anchor progression. Identical
  INIT payloads with identical SN cannot distinguish a replay from an identical
  reboot. This bounded accounting is not offline reordering or capture deduplication.

Percentages, rate displays, funnel presentation and recapture thresholds stay in
consumers. No transport-specific byte-rate filter is applied by Core. BUF_UTIL and
other UI-specific events remain available through `frame_sink`. Existing checker
conclusions, `finish().integrity`, and serialized checker report fields are unchanged.

### Live ordering and bounded state

v8 content is ordered by unfolded global SN, observing INTERNAL anchors even
when only sparse Host/HCI sources are selected; older content uses unfolded system
clock with source-local SN tie breaks. This is a bounded best-effort display window,
not the complete-file anchor/DAG algorithm. Late records are still decoded;
already displayed positions do not determine whether a buffer can be associated.
No display timeout is translated into packet loss or a reassembly timeout.

The oldest pending arrival has a maximum 3-second sorting wait (configurable
downward with `max_wait`); polling also expires windows without new data. The
application must service the session for this deadline to be observable. The
sorting limits default to 64 MiB retained payloads or 250,000 records. Pressure
outputs the current window rather than blocking raw capture. Snapshot pending
counts/bytes describe sorting, not reassembly or consumer display history.

Compressed-message reassembly has no wall-clock expiry. Within each source/task,
the decoder retains the current message and matches log ID and buffer index.
Completion, a subsequent ordinary message, INIT, or end of input ends the pending
association. Available content is always retained in returned records. A missing
database entry for the next message still closes the previous association.
Unmatched buffers are returned separately with raw/hex content, without destroying
an unrelated pending message. Unknown task ID 0xff does not support cross-frame
association. Missing TASK_BINDING otherwise uses `task#id`; it does not delay text.

Reassembly separately applies `max_pending_bytes` to retained raw/rendered record
bytes. On pressure, an older pending message is returned with its available content
and `reassembly_capacity`, then its association is released. These budgets exclude
Python object overhead, decoder workspace and database caches. The frame-size cap
still applies. The checker keeps its separate evidence budget.

Host reassembly shares the offline compressed-decoder primitives; streaming owns
its pending state and database cache. Offline decoding keeps its existing final-text
export and can use later task bindings. Real-time UI refresh, scrollback retention,
and the choice to replace or append a message update belong to the consumer.

## Offline API

```python
from ble_log_frame_decoder.analysis.offline import export_file, ordered_capture

result = export_file("capture.bin", "parsed/", database="log-db/")
result.integrity.to_dict()  # historical checker JSON shape
result.integrity.checked_intervals  # selected ranges, not whole-capture coverage
result.integrity.conclusion
```

Offline operation is deliberately a separate file entry, not `feed` with an
unbounded in-memory list. `ordered_capture` yields `(frames, integrity)` inside a
context manager; `frames.iter_views_with_context()` exposes disk-backed ordered
views for consumers needing other semantic modules. For empty files `frames` is None.
Scratch mappings are cleaned up on completion, error or cancellation. Views are
valid only during their iteration step.

`export_file` writes raw HOST text, compressed logs when configured, binary BTSnoop
HCI (`*_hci_btsnoop_*.log`) and the complete checker JSON. It returns artifact paths
and warnings. Call it **after sealing the input**; device release and background
job/UI status are consumer responsibilities. Files use the standalone Parser's
naming/formatting and ordering. External time synchronization is not inferred;
consumers needing it can use `ordered_capture` with `hci_export.hci_log_handler`.
Core and standalone log contents match under the same input/options/device-clock mode.
The standalone Parser labels unsynchronized v8 HCI files with `_unsynced_epochN`;
Core's device-clock-only export retains its existing filename without that suffix.
Offline protocol selection shares the Parser's capture-wide evidence (INTERNAL and
ENCODE layouts), including legacy layouts advertising version 8. This complete-file
selection does not enable external synchronization in Core.

`CheckResult.from_dict` restores historical JSON without mutating it, including
integer keys and range tuples. `to_dict` keeps the old `asdict` schema; no extra
interval fields are injected. `None` remains unknown, and application verdicts
(e.g. Client's stricter snapshot-conflict policy) stay outside the core.

## Verification

Run from `ble_log_frame_decoder/` in an environment containing the development packages:

```sh
python -m pytest tests/analysis
python ../ble_log_parser_core/tools/benchmark.py capture.bin --offline
```

The benchmark alternates three trials per mode in isolated processes, reports CPU,
peak RSS, MB/s, frames/s and integrity hashes, and fails if required BLFD/checker/
ordering native backends are missing. It separates checker-only parity from the
additional live decoding and final offline export costs. Profile separately from
timing. Python/native checker parity tests live in `tests/checking`;
standalone output parity lives in `../ble_log_parser_v2/tests/test_core_exports.py`.

The original Cython checker and native offline linearizer are retained. BLFD remains
an independent distribution. Live glue uses Python and the built-in sort; additional
Cython work should follow measured hotspots. This development implementation still
requires real Host/HCI dual-device acceptance and target-platform wheel verification.
Console/Client integration is handled separately.

### Current local verification

- 317 Checker/Core tests and 406 standalone Parser tests passed (723 total).
  Old/v8 Host, compressed Host and binary BTSnoop exports match the standalone
  parser byte for byte in the shared-input tests. Legacy unfinished compressed
  messages now survive EOF and cannot be joined across lifecycle boundaries.
- Independent pre-refactor comparison against `f9871b1`: all 26 existing golden
  cases pass on both versions without changing expected hashes. Their 189 tracked
  outputs and 38 complete checker results/reports match.
- Beyond golden, 100 distinct captures producing Parser artifacts were compared
  through the complete v2 CLI: all 487 pre-existing output files match. Six
  captures additionally export raw HOST text; those files were independently
  reconstructed using the old decoder and old ordering, and match byte for byte.
  The corresponding report changes only list the added files. Thirteen inputs
  skipped by both CLIs were excluded and replaced. Twenty-seven captures had
  matching databases, covering 642,673 decompressed records. Captures without a
  database do not establish compressed-log decoding coverage. These local inputs
  are not committed as additional golden fixtures.
- A separate 100-capture streaming comparison covered 1.54 GB, 43,036,387 frames
  and 7,670 snapshots using alternating 1/127/4093/65536-byte chunks. Ordered
  frame-content hashes and complete checker results match the old implementation.
- Core Ruff and Pyright pass. The Parser production-code type check reports one
  pre-existing error in `src/decoder/ellisys/profile.py:64`; that file was not changed.
- Three alternating subprocess trials on Linux x86-64, Python 3.11.0rc1,
  esp-blfd 0.4.0, with native checker: 100,006 small frames / 1.80 MB took
  median 0.134 s for direct checker and 0.137 s through Core; integrity hashes match.
  One saved H2 capture took 0.0166 s and 0.0169 s respectively. These are local
  measurements, not hardware capacity or cross-platform release guarantees.
- A 1,000,001-frame / 18 MB streaming run emitted all 999,900 selected HCI records,
  drained explicitly at the record cap, and peaked at approximately 189 MiB RSS.
  The retained-payload limit intentionally does not claim to bound total RSS.
- A separate profile identified live window insertion as a hotspot. Compiling the
  same Python source with Cython improved the alternating test by only about 2%;
  the experiment was removed instead of adding an unproven native module.
  Existing BLFD/checker/offline native paths are retained; the moved offline
  `.pyx` source is byte-identical to the original.
- The saved H2 USJ transport captures contain synthetic traffic; real Host/HCI
  captures are included in the independent offline comparisons above. Simultaneous
  hardware recording, live ordering, and Windows/macOS wheels still need acceptance.

Borrowed offline iterators should be closed when iteration stops early. On consumer
errors, cleanup preserves the original exception and closes the capture file handle;
a mapping with externally retained views can only be unmapped after those views are
released. A retained view on normal context exit still raises `BufferError`.


## Compatibility and direct helper calls

Legacy Parser module paths remain import aliases. This does not preserve the old
module-level `LOG_DATABASE_CACHE`, `PARSED_LOG_STATISTICS`, or the incidental
`ordering.frame_metadata.LogChecker` export. Import `LogChecker` from
`ble_log_frame_decoder.checking`; use the statistics returned by
`parse_compressed_logs` rather than shared globals.

`ParserSession` and `parse_compressed_logs` own their decoding state. Direct calls
to internal compressed-decoder helpers without an installed `DecodeState` have
no persistent cache or accumulated counters across calls. Use the session or
complete parse entry point when that state is needed; `_state()` is not a public
session factory. This boundary avoids reintroducing cross-session mutable globals.

### Recording products

With the `offline` and `host` extras installed, use
`ble_log_frame_decoder.analysis.recording.RecordingExport(recording_path, database=...)`
as a context manager. Call `feed(chunk)` with consecutive wire bytes and
`finish()` to publish new paths beside the recording. Cancel by closing the context.
The exporter keeps on-disk frame metadata and payloads while recording. Ordinary
anchored v8 Host and HCI data is decoded and staged during reception. Late frames,
changed task bindings, fragmented messages, ambiguous clocks and legacy layouts
can require ordering the index and reading payloads at finish. Wall-clock pacing
and USB read sizes do not decide the order. Reserve temporary disk space for
payloads, metadata, ordering and staged products.

Host text and compressed BLE_HOST output use the offline formats. Host-side
HCI and controller HCI produce separate BTSnoop files in device time. Multiple
explicit v8 lifecycles have separate epoch files. External clock synchronization
requires the offline CLI and its synchronization inputs.
