"""BLE compressed log parser

This module provides functionality to decompress and parse BLE compressed logs.
Supports multiple log types and formats including argument logs and buffer logs.
"""

import json
import os
import re
import struct
import traceback
from contextvars import ContextVar
from dataclasses import dataclass, field
from enum import IntEnum
from pathlib import Path
from typing import Any

from loguru import logger

from ble_log_frame_decoder.analysis.core.parse_context import ParseContext
from ble_log_frame_decoder.analysis.core.protocol import encoded_has_task_id
from ble_log_frame_decoder.analysis.core.snapshot_protocol import (
    task_names_from_binding,
)
from ble_log_frame_decoder.analysis.core.source_codes import BleLogSource

from .c_format_parse import parse_args_bytes

# Constants
DEFAULT_TIMESTAMP_FORMAT = "{:>6}"
DEFAULT_LOG_ID_FORMAT = "{:04}"
DEFAULT_TAG_FORMAT = "{:<18}"
DEFAULT_CTX_FORMAT = "{}"
DEFAULT_MAX_LINES_PER_FILE = 10_000

# Compressed payload prefix: timestamp, source, and (in final v8) task ID.
TIMESTAMP_SIZE = 4
SOURCE_SIZE = 1
TASK_ID_SIZE = 1
MIN_COMPRESSED_HEADER_SIZE = 3

# Supported log sources
SUPPORTED_LOG_SOURCES = [
    "BLE_MESH",
    "BLE_HOST",
    "BLE_MESH_LIB",
    "BLE_ISO",
    "BLE_AUDIO_LIB",
]


class _InvalidEncodePrefix(ValueError):
    """A frame cannot be decoded using the selected ENCODE layout."""


class MissingDictionaryEntry(LookupError):
    """The selected dictionary contains no usable entry for this frame."""


class LogType(IntEnum):
    """Log type enumeration"""

    ZERO_ARGS = 0  # No argument log
    HEX_ARGS = 1  # Hexadecimal argument log
    HEX_BUF = 2  # Hexadecimal buffer log
    LOG_TYPE_INFO = 3  # Log type information


class LogSubType(IntEnum):
    """Log subtype enumeration"""

    NULL_BUF = 1  # Null buffer
    TASK_SWITCH = 2  # Task switch


class CompressedLogSource(IntEnum):
    """Compressed log source enumeration"""

    BLE_HOST = 0
    BLE_MESH = 1
    BLE_MESH_LIB = 2
    BLE_ISO = 3
    BLE_AUDIO_LIB = 4


@dataclass
class DecodeState:
    cache: dict = field(default_factory=dict)
    stats: dict = field(
        default_factory=lambda: {
            s: {"total": 0, "missed": 0} for s in CompressedLogSource
        }
    )


_STATE: ContextVar[DecodeState | None] = ContextVar(
    "compressed_decoder_state", default=None
)


def _state():
    state = _STATE.get()
    if state is None:
        # Legacy direct helper calls have no persistent parsing session.
        return DecodeState()
    return state


def query_log_from_database(
    log_id: int, source: str, log_database_path: str | None
) -> dict[str, Any] | None:
    state = _state()
    if log_database_path is None:
        return None

    if source not in state.cache:
        state.cache[source] = None

    if state.cache[source] is None:
        db_file_path = os.path.join(log_database_path, f"{source}_logs.json")
        state.cache[source] = load_log_database(db_file_path) or {}

    log_db = state.cache[source]
    if log_db and log_id in log_db:
        return log_db[log_id]

    return None


def load_log_database(db_path: str) -> dict[int, dict[str, Any]] | None:
    """Load log database file

    Args:
        db_path: Database file path

    Returns:
        Log database dictionary, None if load failed
    """
    try:
        with open(db_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not data or len(data) == 0:
            logger.warning(f"Empty log database: {db_path}")
            return {}

        log_data = data.get("logs", {})
        if len(log_data) == 0:
            logger.warning("No log entries found in database")
            return {}

        logs_dict = {}
        for entry in log_data.values():
            if (
                isinstance(entry, dict)
                and type(entry.get("id")) is int
                and isinstance(entry.get("format"), str)
                and isinstance(entry.get("tag", ""), str)
            ):
                logs_dict[entry["id"]] = entry

        logger.info(f"Loaded {len(logs_dict)} logs from {db_path}")
        return logs_dict

    except json.JSONDecodeError:
        logger.warning(
            f"Data file for source {db_path} is empty or invalid, starting fresh"
        )
        return {}
    except FileNotFoundError:
        logger.error(f"Database file not found: {db_path}")
        return {}
    except Exception as e:  # noqa: BLE001 - malformed input is reported per record
        logger.error(f"Failed to load database: {e!s}")
        return {}


def parse_log_header(payload: bytes) -> list[Any] | None:
    """Parse log header from payload

    Args:
        payload: Raw payload bytes

    Returns:
        List containing parsed header information, None if parsing failed
        Format: [log_type, log_id/subtype, arg_count/buf_idx, header_size]
    """
    if len(payload) < 3:
        logger.error(f"Payload too short for header parsing: {len(payload)} bytes")
        return None

    try:
        (first_byte,) = struct.unpack_from("<B", payload, 0)
        log_type = first_byte >> 6

        if log_type == LogType.HEX_ARGS:
            args_count = first_byte & 0x3F
            log_id = struct.unpack_from("<H", payload, 1)[0]
            return [log_type, log_id, args_count, 3]

        elif log_type == LogType.LOG_TYPE_INFO:
            log_sub_info = first_byte & 0x3F
            if log_sub_info == LogSubType.NULL_BUF:
                log_id = struct.unpack_from("<H", payload, 1)[0]
                return [log_type, log_sub_info, log_id, 3]
            elif log_sub_info == LogSubType.TASK_SWITCH:
                return [log_type, log_sub_info, 1]

        elif log_type == LogType.HEX_BUF:
            buffer_index = first_byte & 0x3F
            log_id = struct.unpack_from("<H", payload, 1)[0]
            return [log_type, log_id, buffer_index, 3]

        else:
            raise ValueError(f"Unknown log type: {first_byte} (type: {log_type})")

    except struct.error as e:
        logger.error(f"Struct parsing error: {e}, payload: {payload.hex()}")
        return None
    except ValueError as e:
        logger.error(
            f"Value error during header parsing: {e}, payload: {payload.hex()}"
        )
        return None


def parse_hex_arguments(payload: bytes, args_count: int, log_format: str) -> str:
    """Parse hexadecimal arguments from payload

    Args:
        payload: Raw payload bytes containing arguments
        args_count: Number of arguments to parse
        log_format: Format string for the log

    Returns:
        Parsed log string with arguments substituted
    """
    if args_count == 0:
        return log_format

    try:
        parsed_log = parse_args_bytes(payload, args_count, log_format)
        return parsed_log
    except UnicodeDecodeError:
        return payload.hex()
    except Exception as e:  # noqa: BLE001 - malformed input is reported per record
        logger.warning(f"Argument parsing error: {e}, payload: {payload.hex()}")
        return payload.hex()


def format_log_entry(
    timestamp: int,
    tag: str,
    log_id: int,
    context: str,
    caller_function: str,
    line_number: int,
    message: str,
) -> str:
    """Format a log entry with consistent formatting

    Args:
        timestamp: Log timestamp
        tag: Log tag/identifier
        log_id: Log ID
        context: Task context
        caller_function: Function name where log was called
        line_number: Line number where log was called
        message: Log message content

    Returns:
        Formatted log string
    """
    return f"{log_id:04} | {tag:<18} | ({context}) | [{timestamp:>6}] | {caller_function}:{line_number} | {message}\n"


def initialize_log_file(
    source: int, output_dir: str | None = None, dry_run: bool = False
) -> Path:
    """Initialize a new log file for the specified source

    Args:
        source: Log source identifier
        output_dir: Directory to save log files (default: current directory)
        dry_run: If True, return path without creating file

    Returns:
        Path to the log file
    """
    source_name = CompressedLogSource(source).name
    log_filename = f"{output_dir}_DECOMPRESSED_{source_name}.log"
    log_path = Path(log_filename)
    if not dry_run:
        log_path.unlink(missing_ok=True)
    return log_path


def flush_log_buffer(
    log_buffer: dict[int, list[str]],
    source: int,
    log_file: Path,
    force_flush: bool = False,
    dry_run: bool = False,
) -> None:
    """Flush accumulated log lines to file

    Args:
        log_buffer: Dictionary containing log lines by source
        source: Source identifier
        log_file: File path to write to
        force_flush: Force flush even if buffer not full
        dry_run: If True, skip actual file write
    """
    if source not in log_buffer:
        return

    lines = log_buffer[source]
    if not lines:
        return

    if (not force_flush) and len(lines) < DEFAULT_MAX_LINES_PER_FILE:
        return

    if dry_run:
        _state().stats[CompressedLogSource(source)]["total"] += len(lines)
        lines.clear()
        return

    try:
        with log_file.open("a+", encoding="utf-8") as f:
            f.writelines(lines)
            _state().stats[CompressedLogSource(source)]["total"] += len(lines)
        lines.clear()
    except Exception as e:
        logger.error(f"Error flushing log buffer for source {source}: {e}")
        raise


def _parse_compressed_logs(
    payload_sequence,
    log_database_path: str | None = None,
    output_dir: str | None = None,
    context: ParseContext | None = None,
    *,
    has_task_id: bool = False,
) -> dict[str, dict[str, int]]:
    """Parse compressed log payloads

    Args:
        payload_sequence: Sequence of payload frames to parse
        log_database_path: Path to log database directory
        output_dir: Directory to save decompressed logs (default: current directory)
        context: Parse context for dry-run mode

    Returns:
        Dict mapping source names to parsing statistics (total, missed)
    """
    for src in CompressedLogSource:
        _state().stats[src] = {"total": 0, "missed": 0}

    log_buffer: dict[int, list[str]] = {}
    hex_buffer_cache: dict[int, dict[int, list[Any] | None]] = {}
    task_context: dict[int, int] = {}
    log_files: dict[int, Path] = {}
    dry_run = context.dry_run if context else False
    task_names: dict[int, str] = {}
    instance_index: int | None = None
    rejected_prefix_frames = 0
    buffer_has_length = context.encoded_buffer_has_length if context else None
    if buffer_has_length is None:
        version = context.ble_log_version if context else None
        buffer_has_length = has_task_id or (version is not None and version >= 5)
        if not has_task_id and (version is None or version == 4):
            message = (
                "ENCODE buffer layout is ambiguous for v4 or missing version metadata; "
                "preserving raw bytes. Use --encoded-buffer-length for firmware that "
                "writes a uint16 length prefix."
            )
            logger.warning(message)
            if context:
                context.add_warning("ENCODE", "ambiguous_buffer_layout", message)

    def flush_pending_buffers(task_id: int | None = None) -> None:
        for source, pending in hex_buffer_cache.items():
            for task, cached in pending.items():
                if cached is None or (task_id is not None and task != task_id):
                    continue
                _state().stats[CompressedLogSource(source)]["missed"] += cached[
                    -1
                ].count("@hex_buffer")
                flush_formatted_log(
                    source, format_log_entry(*cached), log_buffer, log_files, dry_run
                )
                pending[task] = None

    for item in payload_sequence:
        frame, order = item if isinstance(item, tuple) else (item, None)
        try:
            if order is not None and order.instance_index != instance_index:
                flush_pending_buffers()
                task_names.clear()
                hex_buffer_cache.clear()
                task_context.clear()
                instance_index = order.instance_index
                if context:
                    task_names.update(
                        context.task_names_by_instance.get(order.instance_index, {})
                    )
            if has_task_id and frame.source_code == BleLogSource.INTERNAL:
                task_names.update(task_names_from_binding(frame.payload_view))
                continue
            source, cached_log, parsed_log = _parse_single_frame(
                frame,
                log_database_path,
                output_dir,
                log_buffer,
                hex_buffer_cache,
                task_context,
                log_files,
                context,
                has_task_id=has_task_id,
                task_names=task_names,
                buffer_has_length=buffer_has_length,
            )
            if cached_log:
                flush_formatted_log(source, cached_log, log_buffer, log_files, dry_run)
            if parsed_log:
                _handle_parsed_log(parsed_log, log_buffer, log_files, dry_run)
            if has_task_id and task_context.get(source) == 0xFF:
                # 0xff can represent different writers; never guess their pairing.
                flush_pending_buffers(task_id=0xFF)
        except OSError:
            raise
        except MissingDictionaryEntry:
            continue
        except _InvalidEncodePrefix:
            rejected_prefix_frames += 1
            logger.debug(
                "Rejected ENCODE prefix ({} bytes): {}",
                len(frame.payload_view),
                frame.payload_view[:16].hex(),
            )
        except UnicodeDecodeError:
            continue
        except Exception as e:  # noqa: BLE001 - malformed input is reported per record
            logger.error(
                f"Error parsing frame: {e}, payload: {frame.payload_view.hex()}"
            )
            traceback.print_exc()
            continue

    if rejected_prefix_frames:
        logger.error(
            "Invalid ENCODE prefix: skipped {} frame(s)", rejected_prefix_frames
        )
        if context:
            context.add_warning(
                "ENCODE",
                "invalid_prefix",
                "ENCODE frames with invalid prefixes were skipped",
                count=rejected_prefix_frames,
            )

    flush_pending_buffers()
    # Flush remaining logs
    for source in log_buffer:
        flush_log_buffer(
            log_buffer, source, log_files[source], force_flush=True, dry_run=dry_run
        )

    logger.debug(f"_state().stats: {_state().stats}")

    # Convert enum keys to string names
    return {
        src.name: dict(stats)
        for src, stats in _state().stats.items()
        if stats["total"] or stats.get("missing_id_frames")
    }


def _parse_single_frame(
    frame,
    log_database_path: str | None,
    output_dir: str | None,
    log_buffer: dict[int, list[str]],
    hex_buffer_cache: dict[int, dict[int, list[Any] | None]],
    task_context: dict[int, int],
    log_files: dict[int, Path],
    context: ParseContext | None = None,
    *,
    has_task_id: bool = False,
    task_names: dict[int, str] | None = None,
    buffer_has_length: bool = True,
) -> tuple[int, str | None, dict[str, Any] | None]:
    """Parse a single frame and extract log information"""
    payload = frame.payload_view
    header_start = TIMESTAMP_SIZE + SOURCE_SIZE + (TASK_ID_SIZE if has_task_id else 0)
    if len(payload) < header_start + MIN_COMPRESSED_HEADER_SIZE:
        return 0, None, None
    if encoded_has_task_id(payload) is not has_task_id:
        raise _InvalidEncodePrefix

    # Extract timestamp and source
    timestamp, source = struct.unpack_from("<IB", payload, 0)

    # Parse header
    header = parse_log_header(payload[header_start:])
    if not header:
        return 0, None, None

    # Calculate content index
    content_index = header_start + header[-1]
    if content_index > len(payload):
        return 0, None, None

    # Initialize per-source data structures
    _initialize_source_data(
        source,
        output_dir,
        log_buffer,
        hex_buffer_cache,
        task_context,
        log_files,
        context,
    )

    task_name = None
    if has_task_id:
        task_id = int(payload[TIMESTAMP_SIZE + SOURCE_SIZE])
        task_context[source] = task_id
        hex_buffer_cache[source].setdefault(task_id, None)
        task_name = (
            "unknown"
            if task_id == 0xFF
            else (task_names or {}).get(task_id, f"task#{task_id}")
        )

    # Extract log information
    res = _extract_log_info(
        payload,
        header,
        content_index,
        timestamp,
        source,
        hex_buffer_cache,
        task_context,
        log_database_path,
        task_name,
        buffer_has_length,
    )

    return source, res[0], res[1]


def _initialize_source_data(
    source: int,
    output_dir: str | None,
    log_buffer: dict[int, list[str]],
    hex_buffer_cache: dict[int, dict[int, list[Any] | None]],
    task_context: dict[int, int],
    log_files: dict[int, Path],
    context: ParseContext | None = None,
) -> None:
    """Initialize data structures for a new source"""
    if source not in log_buffer:
        dry_run = context.dry_run if context else False
        log_buffer[source] = []
        log_files[source] = initialize_log_file(source, output_dir, dry_run)
        if context:
            context.add_output_file(log_files[source])
    if source not in hex_buffer_cache:
        hex_buffer_cache[source] = {0: None, 1: None}
    if source not in task_context:
        task_context[source] = 0


def _extract_log_info(
    payload: bytes,
    header: list[Any],
    content_index: int,
    timestamp: int,
    source: int,
    hex_buffer_cache: dict[int, dict[int, list[Any] | None]],
    task_context: dict[int, int],
    log_database_path: str | None,
    task_name: str | None = None,
    buffer_has_length: bool = True,
) -> tuple[str | None, dict[str, Any] | None]:
    """Extract log information from payload and header"""
    log_type = header[0]
    current_task_context = task_context[source]
    log_context = task_name if task_name is not None else "          "
    log_id = -1
    offset = 0
    h = header

    # Handle different log types
    if log_type == LogType.LOG_TYPE_INFO:
        sub_info = _handle_info_log_type(
            payload, header, content_index, source, current_task_context, task_context
        )
        if sub_info[0] is not None:
            log_id = sub_info[0]
        elif sub_info[1]:
            embedded_header = sub_info[1]
            if (
                embedded_header[0] == LogType.LOG_TYPE_INFO
                and embedded_header[1] == LogSubType.NULL_BUF
            ):
                log_context = "Null Buffer"
                log_id = embedded_header[2]
                offset = embedded_header[-1]
                log_type = embedded_header[0]
            else:
                log_context = "TaskSwitch"
                log_id = embedded_header[1]
                offset = embedded_header[-1]
                log_type = embedded_header[0]
                h = embedded_header

        else:
            return None, None
    else:
        log_id = h[1]

    if log_id == -1:
        logger.error(f"Invalid log ID: {log_id}")
        return None, None

    # Query log database
    log_metadata = query_log_from_database(
        log_id, CompressedLogSource(source).name, log_database_path
    )
    if not log_metadata:
        if log_database_path is not None:
            stats = _state().stats[CompressedLogSource(source)]
            stats["missing_id_frames"] = stats.get("missing_id_frames", 0) + 1
            raise MissingDictionaryEntry(log_id)
        return None, None

    # Parse log content
    cached_log, log_content = _parse_log_content(
        payload,
        content_index + offset,
        log_type,
        h,
        log_metadata,
        source,
        current_task_context,
        hex_buffer_cache,
        timestamp,
        log_context,
        buffer_has_length,
    )

    if log_content is not None:
        return cached_log, {
            "timestamp": timestamp,
            "source": source,
            "log_id": log_id,
            "context": log_context,
            "tag": log_metadata.get("tag", ""),
            "caller_function": log_metadata.get("caller", "Unknown"),
            "line_number": log_metadata.get("line_number", 0),
            "message": log_content,
        }

    return cached_log, None


def _handle_info_log_type(
    payload: bytes,
    header: list[Any],
    content_index: int,
    source: int,
    current_task_context: int,
    task_context: dict[int, int],
) -> tuple[int | None, list[Any] | None]:
    """Handle LOG_TYPE_INFO log type including task switching"""
    if header[1] == LogSubType.TASK_SWITCH:
        # Parse embedded header for task switch
        embedded_header = parse_log_header(payload[content_index:])
        if not embedded_header:
            return None, None

        # Update task context
        task_context[source] = int(not current_task_context)
        current_task_context = task_context[source]

        # Extract log ID from embedded header
        if (
            embedded_header[0] == LogType.LOG_TYPE_INFO
            and embedded_header[1] == LogSubType.TASK_SWITCH
        ):
            logger.error(f"Invalid payload: {payload.hex()}")
            return None, None
        return None, embedded_header

    elif header[1] == LogSubType.NULL_BUF:
        log_id = header[2]
        return log_id, None

    return None, None


def _parse_log_content(
    payload: bytes,
    content_index: int,
    log_type: int,
    header: list[Any],
    log_metadata: dict[str, Any],
    source: int,
    current_task_context: int,
    hex_buffer_cache: dict[int, dict[int, list[Any] | None]],
    timestamp: int,
    log_context: str = "          ",
    buffer_has_length: bool = True,
) -> tuple[str | None, str | None]:
    """Parse the content of the log based on its type"""
    log_format = log_metadata.get("format", "")

    if log_type == LogType.HEX_ARGS or log_type == LogType.ZERO_ARGS:
        return _parse_hex_or_zero_args_log(
            payload[content_index:],
            header[2],
            log_format,
            source,
            current_task_context,
            hex_buffer_cache,
            timestamp,
            log_metadata,
            log_context,
        )
    elif log_type == LogType.HEX_BUF:
        return _parse_hex_buffer_log(
            payload[content_index:],
            header[1],
            header[2],
            source,
            current_task_context,
            hex_buffer_cache,
            log_format,
            buffer_has_length,
        )
    elif log_type == LogType.LOG_TYPE_INFO:
        cached_log = hex_buffer_cache[source][current_task_context]
        if cached_log and cached_log[2] == log_metadata["id"]:
            placeholders = set(re.findall(r"@hex_buffer\d+", cached_log[-1]))
            if len(placeholders) == 1:
                cached_log[-1] = cached_log[-1].replace(placeholders.pop(), "NULL")
                hex_buffer_cache[source][current_task_context] = None
                return format_log_entry(*cached_log), None
            # NULL_BUF carries no buffer index: do not guess between slots.
            logger.warning(f"Ambiguous NULL buffer for log ID {log_metadata['id']}")
            return None, None
        return None, f"NULL buffer for log ID {log_metadata['id']} (text unavailable)"
    else:
        logger.error(f"Invalid log type: {log_type}")
        return None, None


def _parse_hex_or_zero_args_log(
    payload: bytes,
    args_count: int,
    log_format: str,
    source: int,
    current_task_context: int,
    hex_buffer_cache: dict[int, dict[int, list[Any] | None]],
    timestamp: int,
    log_metadata: dict[str, Any],
    log_context: str = "          ",
) -> tuple[str | None, str | None]:
    """Parse hexadecimal arguments log or zero arguments log"""
    parsed_message = parse_hex_arguments(payload, args_count, log_format)

    # Handle hex buffer references
    if "@hex_buffer" in parsed_message:
        cached_log = hex_buffer_cache[source][current_task_context]
        # Cache this log for later buffer completion
        hex_buffer_cache[source][current_task_context] = [
            timestamp,
            log_metadata.get("tag", ""),
            log_metadata.get("id", ""),
            log_context,
            log_metadata.get("caller", "Unknown"),
            log_metadata.get("line_number", 0),
            parsed_message,
        ]
        if cached_log is not None:
            _state().stats[CompressedLogSource(source)]["missed"] += cached_log[
                -1
            ].count("@hex_buffer")
            return format_log_entry(*cached_log), None
        return None, None
    else:
        cached_log = hex_buffer_cache[source][current_task_context]
        if cached_log is not None:
            # Format and flush the cached log
            hex_buffer_cache[source][current_task_context] = None
            _state().stats[CompressedLogSource(source)]["missed"] += cached_log[
                -1
            ].count("@hex_buffer")
            return format_log_entry(*cached_log), parsed_message

    return None, parsed_message


def _parse_hex_buffer_log(
    payload: bytes,
    log_id: int,
    buffer_index: int,
    source: int,
    current_task_context: int,
    hex_buffer_cache: dict[int, dict[int, list[Any] | None]],
    log_format: str,
    buffer_has_length: bool = True,
) -> tuple[str | None, str | None]:
    """Parse hexadecimal buffer log"""
    if buffer_has_length:
        if len(payload) < 2:
            logger.warning(f"Missing buffer length for log ID {log_id}")
            return None, None
        buffer_length = struct.unpack_from("<H", payload)[0]
        if buffer_length != len(payload) - 2:
            logger.warning(
                f"Buffer length mismatch for log ID {log_id}: "
                f"declared {buffer_length}, received {len(payload) - 2}"
            )
            return None, None
        payload = payload[2:]
    hex_data = payload.hex()

    # Check if there's a cached log waiting for this buffer
    cached_log = hex_buffer_cache[source][current_task_context]
    pattern = re.escape(f"@hex_buffer{buffer_index}") + r"(?!\d)"
    if cached_log and cached_log[2] == log_id:
        # Replace the hex buffer placeholder with actual data
        format_string = re.sub(pattern, hex_data, cached_log[-1])

        if "@hex_buffer" not in format_string:
            # All buffers filled, return complete log
            hex_buffer_cache[source][current_task_context] = None
            return None, format_string
        else:
            # Update cached log and wait for more buffers
            cached_log[-1] = format_string
            return None, None
    else:
        hex_buffer_cache[source][current_task_context] = None
        format_string = re.sub(pattern, hex_data, log_format)
        if cached_log:
            _state().stats[CompressedLogSource(source)]["missed"] += cached_log[
                -1
            ].count("@hex_buffer")
            return format_log_entry(*cached_log), format_string
        return None, format_string


def _handle_parsed_log(
    log_info: dict[str, Any],
    log_buffer: dict[int, list[str]],
    log_files: dict[int, Path],
    dry_run: bool = False,
) -> None:
    """Handle a successfully parsed log entry"""
    source = log_info["source"]
    formatted_log = format_log_entry(
        log_info["timestamp"],
        log_info["tag"],
        log_info["log_id"],
        log_info["context"],
        log_info["caller_function"],
        log_info["line_number"],
        log_info["message"],
    )

    flush_formatted_log(source, formatted_log, log_buffer, log_files, dry_run)


def flush_formatted_log(
    source,
    formatted_log,
    log_buffer: dict[int, list[str]],
    log_files: dict[int, Path],
    dry_run: bool = False,
) -> None:
    log_buffer[source].append(formatted_log)
    flush_log_buffer(log_buffer, source, log_files[source], dry_run=dry_run)


def parse_compressed_logs(
    payload_sequence,
    log_database_path: str | None = None,
    output_dir: str | None = None,
    context: ParseContext | None = None,
    *,
    has_task_id: bool = False,
) -> dict[str, dict[str, int]]:
    """File adapter with isolated database/statistics for each invocation."""
    token = _STATE.set(DecodeState())
    try:
        return _parse_compressed_logs(
            payload_sequence,
            log_database_path,
            output_dir,
            context,
            has_task_id=has_task_id,
        )
    finally:
        _STATE.reset(token)
