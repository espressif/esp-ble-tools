"""HCI payload conversion shared by live display and BTSnoop export."""

import struct
from typing import NamedTuple

# Constants
BTSNOOP_VERSION = 1
BTSNOOP_DATALINK_TYPE = 1002
BTSNOOP_FILE_ID = "btsnoop\x00"
BTSNOOP_TIMESTAMP_BASE = 0x00DCDDB30F2F8000
BTSNOOP_HEADER = BTSNOOP_FILE_ID.encode("ascii") + struct.pack(
    "!II", BTSNOOP_VERSION, BTSNOOP_DATALINK_TYPE
)
ESP_TIMER_SIZE = 4
HCI_PACKET_TYPE_SIZE = 1
HCI_PARSE_OVERHEAD = ESP_TIMER_SIZE + HCI_PACKET_TYPE_SIZE
HCI_PACKET_TYPE_CMD = 1
HCI_PACKET_TYPE_ACL = 2
HCI_PACKET_TYPE_SYNC = 3
HCI_PACKET_TYPE_EVT = 4
HCI_PACKET_TYPE_ISO = 5
HCI_PACKET_TYPE_MASK = 0x7F
HCI_DIRECTION_BIT = 0x80

# btsnoop flags: bit 0 = direction (0=sent, 1=recv), bit 1 = type (0=data, 1=cmd/evt)
BTSNOOP_FLAG_CMD = 0x02  # Sent, Command/Event
BTSNOOP_FLAG_EVT = 0x03  # Received, Command/Event
BTSNOOP_FLAG_DATA_SENT = 0x00  # Sent, Data
BTSNOOP_FLAG_DATA_RECV = 0x01  # Received, Data


def encode_hci_payload(payload: bytes | memoryview, timestamp_us: int) -> bytes | None:
    if len(payload) <= HCI_PARSE_OVERHEAD:
        return None
    (raw_type,) = struct.unpack_from("<B", payload, ESP_TIMER_SIZE)
    hci_packet_type = raw_type & HCI_PACKET_TYPE_MASK
    if hci_packet_type == HCI_PACKET_TYPE_CMD:
        btsnoop_flags = BTSNOOP_FLAG_CMD
    elif hci_packet_type == HCI_PACKET_TYPE_EVT:
        btsnoop_flags = BTSNOOP_FLAG_EVT
    else:
        direction = (raw_type & HCI_DIRECTION_BIT) >> 7
        btsnoop_flags = BTSNOOP_FLAG_DATA_RECV if direction else BTSNOOP_FLAG_DATA_SENT
    hci_ts = BTSNOOP_TIMESTAMP_BASE + timestamp_us
    hci_packet_len = len(payload) - HCI_PARSE_OVERHEAD + HCI_PACKET_TYPE_SIZE
    return (
        struct.pack(
            "!IIIIQ",
            hci_packet_len,
            hci_packet_len,
            btsnoop_flags,
            0,
            hci_ts,
        )
        + struct.pack("<B", hci_packet_type)
        + bytes(payload[HCI_PARSE_OVERHEAD:])
    )


class HciPacket(NamedTuple):
    text: str
    btsnoop: bytes = b""
    reason: str = ""


def describe_hci(payload: bytes, timestamp_us: int | None) -> HciPacket:
    if len(payload) < 6 or payload[4] & 0x7F not in (1, 2, 3, 4, 5):
        return HciPacket(
            f"HCI undecodable: {payload.hex(' ')}", reason="invalid_payload"
        )
    packet_type = payload[4] & 0x7F
    incoming = packet_type == 4 or (packet_type != 1 and bool(payload[4] & 0x80))
    clock = (
        f"{timestamp_us} us"
        if timestamp_us is not None
        else f"raw clock={int.from_bytes(payload[:4], 'little')} (unit unknown)"
    )
    text = f"{clock} {'RX' if incoming else 'TX'} HCI type={packet_type} {payload[5:].hex(' ')}"
    return HciPacket(
        text,
        (encode_hci_payload(payload, timestamp_us) or b"")
        if timestamp_us is not None
        else b"",
        "unknown_clock_unit" if timestamp_us is None else "",
    )
