"""Disk-backed frame metadata produced by the v2 view-only scan path."""

from __future__ import annotations

import shutil
import sys
import tempfile
import zlib
from array import array
from dataclasses import dataclass
from enum import IntFlag
from pathlib import Path
from typing import BinaryIO, Final

import numpy as np

from ble_log_frame_decoder import FrameView
from ble_log_frame_decoder.analysis import ParserSession
from ble_log_frame_decoder.analysis.core.frame_decoder import create_frame_decoder
from ble_log_frame_decoder.analysis.core.protocol import ProtocolEvidence
from ble_log_frame_decoder.checking import CheckResult
from ble_log_frame_decoder.checking.protocol import (
    INIT,
    TS_VALID,
    is_snapshot,
    is_task_binding,
    parse_snapshot,
)
from ble_log_frame_decoder.core import _BLE_HEADER_SIZE

MAX_FRAME_LENGTH = 4106
from ble_log_frame_decoder.analysis.core.source_codes import BleLogSource
from ble_log_frame_decoder.analysis.ordering.frame_model import (
    AnchorKind,
    detect_per_source_anchor_kind,
    extract_raw_clock_from_payload,
    has_reliable_payload,
    parse_per_source_timestamp_anchor,
)

_COLUMN_SPECS: Final[dict[str, tuple[str, int, str]]] = {
    "source_sn": ("I", 4, "<u4"),
    "payload_offset": ("Q", 8, "<u8"),
    "payload_size": ("H", 2, "<u2"),
    "raw_clock": ("I", 4, "<u4"),
    "payload_crc32": ("I", 4, "<u4"),
    "flags": ("B", 1, "u1"),
}
_ANCHOR_NAME = "anchors"
_ANCHOR_WIDTH = 12


class FrameMetadataFlag(IntFlag):
    CLOCK_PRESENT = 1 << 0
    RELIABLE_SN = 1 << 1
    INIT_DONE = 1 << 2
    FLUSH = 1 << 3
    SNAPSHOT = 1 << 4
    TASK_BINDING = 1 << 5


def product_payload_offset(raw_offset: int) -> int:
    if raw_offset < 0:
        raise ValueError("Negative recording start offset")
    return raw_offset + _BLE_HEADER_SIZE


class FrameMetadataStore:
    """Append-only fixed-width columns that become read-only when sealed."""

    def __init__(self, path: Path, *, buffer_rows: int = 16_384) -> None:
        if sys.byteorder != "little":
            raise RuntimeError("FrameMetadataStore requires a little-endian host")
        if buffer_rows <= 0:
            raise ValueError("buffer_rows must be positive")

        self.path = path
        self.path.mkdir(parents=True, exist_ok=False)
        self._buffer_rows = buffer_rows
        self._files: dict[str, BinaryIO] = {}
        self._buffers: dict[str, array[int]] = {}
        self._maps: dict[str, np.ndarray] = {}
        self._row_count = 0
        self._anchor_count = 0
        self._sealed = False
        self._closed = False
        self.integrity: CheckResult | None = None
        self.protocol_evidence = ProtocolEvidence()
        try:
            for name, (typecode, _, _) in _COLUMN_SPECS.items():
                self._files[name] = (self.path / f"{name}.bin").open("wb")
                self._buffers[name] = array(typecode)
            self._files[_ANCHOR_NAME] = (self.path / f"{_ANCHOR_NAME}.bin").open("wb")
            self._buffers[_ANCHOR_NAME] = array("I")
        except Exception:
            self.discard()
            raise

    @property
    def row_count(self) -> int:
        return self._row_count

    @property
    def anchor_count(self) -> int:
        return self._anchor_count

    @property
    def sealed(self) -> bool:
        return self._sealed

    def append(
        self,
        *,
        source_sn: int,
        payload_offset: int,
        payload_size: int,
        raw_clock: int,
        payload_crc32: int,
        flags: int,
    ) -> int:
        if self._sealed or self._closed:
            raise RuntimeError("cannot append to a sealed FrameMetadataStore")

        row = self._row_count
        self._buffers["source_sn"].append(source_sn)
        self._buffers["payload_offset"].append(payload_offset)
        self._buffers["payload_size"].append(payload_size)
        self._buffers["raw_clock"].append(raw_clock)
        self._buffers["payload_crc32"].append(payload_crc32)
        self._buffers["flags"].append(flags)
        self._row_count += 1
        if len(self._buffers["source_sn"]) >= self._buffer_rows:
            self._flush_rows()
        return row

    def append_anchor(self, transport_index: int, lc_ts: int, os_ts: int) -> None:
        if self._sealed or self._closed:
            raise RuntimeError("cannot append to a sealed FrameMetadataStore")
        if not 0 <= transport_index < self._row_count:
            raise ValueError("anchor transport index is outside stored rows")
        anchors = self._buffers[_ANCHOR_NAME]
        anchors.extend((transport_index, lc_ts, os_ts))
        self._anchor_count += 1
        if self._anchor_count % self._buffer_rows == 0:
            self._flush_buffer(_ANCHOR_NAME)

    def seal(self) -> FrameMetadataStore:
        if self._closed:
            raise RuntimeError("cannot seal a closed FrameMetadataStore")
        if self._sealed:
            return self

        self._flush_rows()
        self._flush_buffer(_ANCHOR_NAME)
        for file in self._files.values():
            file.close()
        self._files.clear()
        self._validate_sizes()
        self._sealed = True
        return self

    def product_start_row(self, raw_offset: int) -> int:
        """Resolve a caller-selected wire offset using the original capture index."""
        if raw_offset == 0:
            return 0
        target = product_payload_offset(raw_offset)
        offsets = self.mmap_column("payload_offset")
        row = int(np.searchsorted(offsets, target))
        if row == len(offsets) or offsets[row] != target:
            raise ValueError("Product start offset does not point to a frame")
        return row

    def mmap_column(self, name: str) -> np.ndarray:
        if not self._sealed or self._closed:
            raise RuntimeError("FrameMetadataStore must be sealed and open")
        if name not in _COLUMN_SPECS:
            raise KeyError(name)
        mapped = self._maps.get(name)
        if mapped is not None:
            return np.asarray(mapped)
        if self._row_count == 0:
            mapped = np.empty(0, dtype=_COLUMN_SPECS[name][2])
        else:
            mapped = np.memmap(
                self.path / f"{name}.bin",
                dtype=_COLUMN_SPECS[name][2],
                mode="r",
                shape=(self._row_count,),
            )
        self._maps[name] = mapped
        return np.asarray(mapped)

    def mmap_anchors(self) -> np.ndarray:
        if not self._sealed or self._closed:
            raise RuntimeError("FrameMetadataStore must be sealed and open")
        mapped = self._maps.get(_ANCHOR_NAME)
        if mapped is not None:
            return np.asarray(mapped)
        if self._anchor_count == 0:
            mapped = np.empty((0, 3), dtype="<u4")
        else:
            mapped = np.memmap(
                self.path / f"{_ANCHOR_NAME}.bin",
                dtype="<u4",
                mode="r",
                shape=(self._anchor_count, 3),
            )
        self._maps[_ANCHOR_NAME] = mapped
        return np.asarray(mapped)

    def close(self) -> None:
        if self._closed:
            return
        for file in self._files.values():
            file.close()
        self._files.clear()
        for mapped in self._maps.values():
            mmap_object = getattr(mapped, "_mmap", None)
            if mmap_object is not None:
                mmap_object.close()
        self._maps.clear()
        self._closed = True

    def discard(self) -> None:
        self.close()
        shutil.rmtree(self.path, ignore_errors=True)

    def _flush_rows(self) -> None:
        for name in _COLUMN_SPECS:
            self._flush_buffer(name)

    def _flush_buffer(self, name: str) -> None:
        values = self._buffers[name]
        if not values:
            return
        view = memoryview(values).cast("B")
        try:
            self._files[name].write(view)
        finally:
            view.release()
        del values[:]

    def _validate_sizes(self) -> None:
        for name, (_, width, _) in _COLUMN_SPECS.items():
            actual = (self.path / f"{name}.bin").stat().st_size
            expected = self._row_count * width
            if actual != expected:
                raise ValueError(
                    f"invalid {name} column size: expected {expected}, got {actual}"
                )
        anchor_size = (self.path / f"{_ANCHOR_NAME}.bin").stat().st_size
        expected_anchor_size = self._anchor_count * _ANCHOR_WIDTH
        if anchor_size != expected_anchor_size:
            raise ValueError(
                "invalid anchors column size: "
                f"expected {expected_anchor_size}, got {anchor_size}"
            )


def _common_frame_metadata(
    source: BleLogSource, payload: memoryview
) -> tuple[int, int]:
    flags = 0
    clock = extract_raw_clock_from_payload(source, payload)
    if clock is not None:
        flags |= int(FrameMetadataFlag.CLOCK_PRESENT)
    if has_reliable_payload(source, payload):
        flags |= int(FrameMetadataFlag.RELIABLE_SN)
    return clock if clock is not None else 0, flags


def _snapshot_internal_metadata(
    payload: memoryview,
) -> tuple[int, int, tuple[int, int] | None]:
    if is_task_binding(payload):
        clock, flags = _common_frame_metadata(BleLogSource.INTERNAL, payload)
        return clock, flags | int(FrameMetadataFlag.TASK_BINDING), None
    snapshot = parse_snapshot(payload)
    flags = int(
        FrameMetadataFlag.SNAPSHOT
        | FrameMetadataFlag.CLOCK_PRESENT
        | FrameMetadataFlag.RELIABLE_SN
    )
    if snapshot.reason_flags & INIT:
        flags |= int(FrameMetadataFlag.INIT_DONE)
    anchor = None
    if snapshot.reason_flags & TS_VALID and snapshot.lc_ts:
        anchor = (snapshot.lc_ts, snapshot.esp_ts)
    return snapshot.timestamp, flags, anchor


def _per_source_internal_metadata(
    payload: memoryview,
) -> tuple[int, int, tuple[int, int] | None]:
    source = BleLogSource.INTERNAL
    clock, flags = _common_frame_metadata(source, payload)
    kind = detect_per_source_anchor_kind(source, payload)
    if kind is AnchorKind.INIT_DONE:
        flags |= int(FrameMetadataFlag.INIT_DONE)
    elif kind is AnchorKind.FLUSH:
        flags |= int(FrameMetadataFlag.FLUSH)
    return clock, flags, parse_per_source_timestamp_anchor(source, payload)


class FrameMetadataWriter:
    """FrameSink that projects borrowed v2 payload views into metadata rows."""

    def __init__(self, store: FrameMetadataStore) -> None:
        self.store = store

    def write(self, frame: FrameView) -> None:
        source = BleLogSource(frame.source_code)
        if source is BleLogSource.REDIR:
            return
        payload = frame.payload_view
        self.store.protocol_evidence.observe(source, payload)
        if source is BleLogSource.INTERNAL:
            if is_snapshot(payload) or is_task_binding(payload):
                raw_clock, flags, raw_anchor = _snapshot_internal_metadata(payload)
            else:
                raw_clock, flags, raw_anchor = _per_source_internal_metadata(payload)
        else:
            raw_clock, flags = _common_frame_metadata(source, payload)
            raw_anchor = None

        row = self.store.append(
            source_sn=(frame.raw_sn << 8) | frame.source_code,
            payload_offset=frame.payload_offset,
            payload_size=frame.payload_size,
            raw_clock=raw_clock,
            payload_crc32=zlib.crc32(payload),
            flags=flags,
        )
        if raw_anchor is not None:
            self.store.append_anchor(row, raw_anchor[0], raw_anchor[1])


@dataclass(slots=True)
class ScannedFrameMetadata:
    store: FrameMetadataStore
    scratch_dir: Path
    _temporary_directory: tempfile.TemporaryDirectory[str]

    def close(self) -> None:
        self.store.close()
        self._temporary_directory.cleanup()


def scan_frame_metadata(
    file_path: Path,
    store_path: Path,
    *,
    chunk_size: int = 1024 * 1024,
) -> FrameMetadataStore:
    """Scan one v2 capture into a sealed metadata store."""
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    decoder = create_frame_decoder(MAX_FRAME_LENGTH)

    store = FrameMetadataStore(store_path)
    try:
        writer = FrameMetadataWriter(store)
        with ParserSession(
            file_path, decoder=decoder, frame_sink=writer.write
        ) as session:
            with file_path.open("rb") as file:
                while chunk := file.read(chunk_size):
                    session.feed(chunk)
            store.integrity = session.finish().integrity
        return store.seal()
    except Exception:
        store.discard()
        raise


def prepare_frame_metadata(
    file_path: Path,
    *,
    chunk_size: int = 1024 * 1024,
) -> ScannedFrameMetadata:
    temporary_directory = tempfile.TemporaryDirectory(
        prefix=f"ble-metadata-{file_path.stem}-"
    )
    scratch_dir = Path(temporary_directory.name)
    try:
        store = scan_frame_metadata(
            file_path,
            scratch_dir / "metadata",
            chunk_size=chunk_size,
        )
    except Exception:
        temporary_directory.cleanup()
        raise
    return ScannedFrameMetadata(store, scratch_dir, temporary_directory)
