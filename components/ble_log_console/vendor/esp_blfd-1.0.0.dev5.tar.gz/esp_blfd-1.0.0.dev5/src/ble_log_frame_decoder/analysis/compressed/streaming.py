"""Incremental compressed messages, completed by protocol events rather than time."""

from dataclasses import replace

from ..core.parse_context import ParseContext
from ..records import Record
from . import decompress as codec


class CompressedDecoder:
    def __init__(self, database, version, names, *, max_pending_bytes=64 * 1024 * 1024):
        if max_pending_bytes <= 0:
            raise ValueError("max_pending_bytes must be positive")
        self.database, self.version, self.names = database, version, names
        self.max_pending_bytes = max_pending_bytes
        self.state = codec.DecodeState()
        self.pending, self.tasks, self.buffers, self.files = {}, {}, {}, {}
        self.context = ParseContext(dry_run=True, ble_log_version=version)
        self._origins = {}
        self._sizes = {}
        self._bytes = 0

    def feed(self, frame, timestamp=None):
        payload = frame.payload_view
        base = Record(
            "undecodable",
            7,
            frame.raw_sn,
            (int.from_bytes(payload[:4], "little") if timestamp is None else timestamp)
            * (1 if self.version >= 8 else 1000)
            if len(payload) >= 4
            else None,
            record_id=frame.payload_offset,
            raw=bytes(payload),
            text=bytes(payload).hex(" "),
            incomplete=True,
        )
        records = []
        token = codec._STATE.set(self.state)
        try:
            start = 6 if self.version >= 8 else 5
            if len(payload) < start + 3:
                return [replace(base, reason="short_payload")]
            source = payload[4]
            task = payload[5] if self.version >= 8 else self.tasks.get(source, 0)
            header = codec.parse_log_header(payload[start:])
            if not header:
                return [replace(base, reason="invalid_payload")]
            # Legacy task-switch records carry an embedded message header.
            if header[:2] == [
                codec.LogType.LOG_TYPE_INFO,
                codec.LogSubType.TASK_SWITCH,
            ]:
                header = codec.parse_log_header(payload[start + header[-1] :])
                if not header:
                    return [replace(base, reason="invalid_payload")]
            key = (source, task)
            previous = self.pending.get(source, {}).get(task)
            origin = self._origins.get(key, base)
            continuation = header[0] == codec.LogType.HEX_BUF or header[:2] == [
                codec.LogType.LOG_TYPE_INFO,
                codec.LogSubType.NULL_BUF,
            ]
            if continuation:
                log_id = header[1] if header[0] == codec.LogType.HEX_BUF else header[2]
                if previous is None or previous[2] != log_id:
                    return [replace(base, reason="orphan_buffer")]
                previous = list(previous)
            else:
                records.extend(self._flush([key]))
                origin = base

            _, cached, parsed = codec._parse_single_frame(
                frame,
                self.database,
                None,
                self.buffers,
                self.pending,
                self.tasks,
                self.files,
                self.context,
                has_task_id=self.version >= 8,
                task_names=self.names,
                buffer_has_length=self.version >= 5,
            )
            pending = self.pending.get(source, {}).get(task)
            if cached:
                records.append(
                    replace(
                        origin,
                        kind="host",
                        text=cached,
                        incomplete="@hex_buffer" in cached,
                        reason="",
                    )
                )
            if parsed:
                text = (
                    codec.format_log_entry(*(previous[:-1] + [parsed["message"]]))
                    if continuation and previous is not None
                    else codec.format_log_entry(
                        parsed["timestamp"],
                        parsed["tag"],
                        parsed["log_id"],
                        parsed["context"],
                        parsed["caller_function"],
                        parsed["line_number"],
                        parsed["message"],
                    )
                )
                records.append(
                    replace(
                        origin,
                        kind="host",
                        text=text,
                        incomplete="@hex_buffer" in text,
                        reason="",
                    )
                )
            if pending is not None:
                record = replace(
                    origin,
                    kind="host",
                    text=codec.format_log_entry(*pending),
                    incomplete=True,
                    reason="",
                )
                if not continuation or record.text != origin.text:
                    records.append(record)
                elif not cached and not parsed:
                    # A malformed/nonmatching fragment must remain visible too.
                    records.append(replace(base, reason="unmatched_buffer"))
                self._remember(key, record)
            else:
                self._forget(key)
                if not cached and not parsed:
                    records.append(
                        replace(base, reason="missing_log_or_invalid_payload")
                    )
            if task == 255:
                records.extend(self._flush([key], "unknown_task"))
            while self._bytes > self.max_pending_bytes:
                records.extend(
                    self._flush([next(iter(self._origins))], "reassembly_capacity")
                )
            return records
        except codec.MissingDictionaryEntry:
            records.append(replace(base, reason="missing_dictionary_entry"))
            return records
        except (ValueError, IndexError, KeyError, UnicodeDecodeError) as exc:
            records.append(replace(base, reason=str(exc)))
            return records
        finally:
            codec._STATE.reset(token)

    def _forget(self, key):
        self._bytes -= self._sizes.pop(key, 0)
        return self._origins.pop(key, None)

    def _remember(self, key, record):
        self._forget(key)
        self._origins[key] = record
        size = len(record.raw) + len(record.text.encode("utf-8"))
        self._sizes[key] = size
        self._bytes += size

    def _flush(self, keys, reason="missing_buffer"):
        records = []
        for source, task in keys:
            origin = self._forget((source, task))
            if origin is not None:
                self.pending[source][task] = None
                records.append(replace(origin, reason=reason))
        return records

    def finish(self):
        return self._flush(list(self._origins))
