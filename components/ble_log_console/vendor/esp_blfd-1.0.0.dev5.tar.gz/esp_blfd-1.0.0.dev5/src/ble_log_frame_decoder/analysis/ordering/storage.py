"""Small disk-backed array helpers shared by ordering implementations."""

import heapq
from pathlib import Path
from typing import Any

import numpy as np


def create_memmap(
    path: Path,
    dtype: str | np.dtype[Any],
    count: int,
    *,
    fill: int | None = None,
) -> np.ndarray:
    dtype_obj = np.dtype(dtype)
    with path.open("wb") as file:
        file.truncate(count * dtype_obj.itemsize)
    if count == 0:
        return np.empty(0, dtype=dtype_obj)
    mapped = np.memmap(path, dtype=dtype_obj, mode="r+", shape=(count,))
    if fill is not None:
        mapped[:] = fill
    return np.asarray(mapped)


def close_memmap(mapped: np.ndarray) -> None:
    owner = mapped
    while getattr(owner, "_mmap", None) is None and owner.base is not None:
        owner = owner.base
    mmap_object = getattr(owner, "_mmap", None)
    if mmap_object is not None:
        mmap_object.close()


def sort_record_runs(
    records: np.ndarray,
    order: tuple[str, ...],
    *,
    chunk_bytes: int = 64 * 1024 * 1024,
) -> list[tuple[int, int]]:
    if not len(records):
        return []
    rows_per_run = max(1, chunk_bytes // records.dtype.itemsize)
    runs = []
    for start in range(0, len(records), rows_per_run):
        end = min(start + rows_per_run, len(records))
        records[start:end].sort(order=order, kind="quicksort")
        runs.append((start, end))
    flush = getattr(records, "flush", None)
    if flush is not None:
        flush()
    return runs


def iter_merged_records(
    records: np.ndarray,
    runs: list[tuple[int, int]],
    order: tuple[str, ...],
):
    yield from heapq.merge(
        *(records[start:end] for start, end in runs),
        key=lambda record: tuple(int(record[name]) for name in order),
    )


def read_at(file, size: int, offset: int) -> bytes:
    """Ordering owns this read handle and uses only absolute offsets."""
    file.seek(offset)
    return file.read(size)
