from __future__ import annotations

import struct
from collections.abc import Iterable
from pathlib import Path
from typing import TYPE_CHECKING

from loguru import logger

from ble_log_frame_decoder import FrameView
from ble_log_frame_decoder.analysis.core.parse_context import ParseContext
from ble_log_frame_decoder.analysis.hci import BTSNOOP_HEADER, encode_hci_payload
from ble_log_frame_decoder.analysis.ordering.metadata_ordering import FrameOrderContext

if TYPE_CHECKING:
    from typing import Any as Synchronizer

# Constants
BTSNOOP_VERSION = 1
BTSNOOP_DATALINK_TYPE = 1002
BTSNOOP_FILE_ID = "btsnoop\x00"
BTSNOOP_TIMESTAMP_BASE = 0x00DCDDB30F2F8000
ESP_TIMER_SIZE = 4
HCI_PACKET_TYPE_SIZE = 1
HCI_PARSE_OVERHEAD = ESP_TIMER_SIZE + HCI_PACKET_TYPE_SIZE
HCI_PACKET_TYPE_CMD = 1
HCI_PACKET_TYPE_ACL = 2
HCI_PACKET_TYPE_SYNC = 3
HCI_PACKET_TYPE_EVT = 4
HCI_PACKET_TYPE_ISO = 5
HCI_PACKET_TYPE_MASK = 0x7F
HCI_DIRECTION_BIT = 0x80

# btsnoop flags: bit 0 = direction (0=sent, 1=recv), bit 1 = type (0=data, 1=cmd/evt)
BTSNOOP_FLAG_CMD = 0x02  # Sent, Command/Event
BTSNOOP_FLAG_EVT = 0x03  # Received, Command/Event
BTSNOOP_FLAG_DATA_SENT = 0x00  # Sent, Data
BTSNOOP_FLAG_DATA_RECV = 0x01  # Received, Data


def hci_log_handler(
    logs: Iterable[FrameView | tuple[FrameView, FrameOrderContext]],
    synchronizer: Synchronizer,
    hci_log_path: Path,
    context: ParseContext | None = None,
    *,
    append: bool = False,
):
    logger.debug("Processing HCI logs...")
    output = None
    written = 0
    try:
        for item in logs:
            frame, order = item if isinstance(item, tuple) else (item, None)
            content = _encode_hci_payload(
                frame.payload_view,
                synchronizer,
                timestamp_us=order.timestamp_us if order is not None else None,
            )
            if content is None:
                continue
            written += 1
            if context and context.dry_run:
                continue
            if output is None:
                output = hci_log_path.open("ab" if append else "wb")
                if output.tell() == 0:
                    output.write(BTSNOOP_HEADER)
            output.write(content)
    finally:
        if output is not None:
            output.close()
    if not written:
        return
    if context and context.dry_run:
        logger.info(f"[Dry run] Would write: {hci_log_path}")
    else:
        logger.info(f"HCI log has been saved to {hci_log_path}")
    if context:
        context.add_output_file(hci_log_path)


def _encode_hci_payload(
    payload: bytes | memoryview,
    syncer: Synchronizer,
    *,
    timestamp_us: int | None = None,
) -> bytes | None:
    if len(payload) <= HCI_PARSE_OVERHEAD:
        logger.warning("No invalid data in payload")
        return None
    (os_ts,) = struct.unpack_from("<I", payload, 0)
    ts = syncer.os_ts_to_la_ts(os_ts) if syncer.inited else os_ts * 1000
    if timestamp_us is not None:
        ts = syncer.esp_ts_to_la_ts(timestamp_us) if syncer.inited else timestamp_us
    return encode_hci_payload(payload, ts)
