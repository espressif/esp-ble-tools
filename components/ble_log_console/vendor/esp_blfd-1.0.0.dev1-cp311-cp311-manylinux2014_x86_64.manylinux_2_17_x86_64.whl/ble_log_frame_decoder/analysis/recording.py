"""Incremental, unsynchronized Host and HCI products for a recording."""

import errno
import heapq
import os
import shutil
from collections import deque
from contextlib import ExitStack
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

from ble_log_frame_decoder import (
    FrameView,
    is_snapshot,
    is_task_binding,
    parse_snapshot_version_info,
    parse_version_info_payload,
    task_names_from_binding,
)
from ble_log_frame_decoder.checking.protocol import INIT, PERIODIC, parse_snapshot

from .compressed.decompress import parse_compressed_logs
from .content import ContentDecoder
from .core.parse_context import ParseContext
from .core.source_codes import BleLogSource as Source
from .hci import BTSNOOP_HEADER, encode_hci_payload
from .hci_export import hci_log_handler
from .host import write_host_text
from .ll_hci import ll_hci_log_handler
from .ordering.frame_metadata import FrameMetadataStore, FrameMetadataWriter
from .ordering.frame_model import LcTimerUnit
from .ordering.metadata_ordering import OrderedFrameSource, order_metadata_store
from .session import ParserSession


class _AnchoredHostHci:
    """Stage one ordinary v8 lifecycle. Decline when full ordering is required.

    With strictly increasing anchors and no SN wrap, a selected SN inside the
    offline receive window has exactly one lift. A half-ring span excludes a
    second lift at either capture edge. Require the same for ESP clock samples
    so official BTSnoop timestamps cannot change after a later clock wrap.
    """

    def __init__(self, directory, database, stem):
        self.directory, self.stem = directory, stem
        self.content = ContentDecoder({"host"}, database)
        self.content.version = 8
        self.files = {}
        self.pending = []
        self.pending_bytes = 0
        self.last_written = -1
        self.low_sn, self.high_sn = 1 << 24, -1
        self.low_clock, self.high_clock = 1 << 32, -1
        self.previous_anchor = None
        self.periodic = deque(maxlen=4)
        self.lower = -1
        self.interval_max = self.previous_max = -1
        self.task_names_used = {}

    def observe(self, frame):
        src, sn, data = frame.source_code, frame.raw_sn, frame.payload_view
        if src in (2, 4, 8):
            return True
        if src == 3:
            return False
        if src == 0 and is_task_binding(data):
            names = task_names_from_binding(data)
            if any(
                self.content.task_names.get(k, v) != v
                or self.task_names_used.get(k, v) != v
                for k, v in names.items()
            ):
                return False
            self.content.task_names.update(names)
            return True
        if len(data) >= 4:
            clock = int.from_bytes(data[:4], "little")
            self.low_clock, self.high_clock = (
                min(self.low_clock, clock),
                max(self.high_clock, clock),
            )
            if self.high_clock - self.low_clock >= 1 << 31:
                return False
        if src == 1:
            return True
        self.low_sn, self.high_sn = min(self.low_sn, sn), max(self.high_sn, sn)
        if self.high_sn - self.low_sn >= 1 << 23:
            return False
        if src == 0:
            if not is_snapshot(data):
                return False
            snap = parse_snapshot(data)
            if snap.reason_flags & INIT:
                if frame.payload_offset:
                    return False
                self.lower = sn - 1
            if self.previous_max > sn:
                return False
            if self.previous_anchor is not None:
                old_sn, count = self.previous_anchor
                if sn <= old_sn or snap.anchor_count == count:
                    return False
                if not self.drain(old_sn):
                    return False
            self.previous_anchor = sn, snap.anchor_count
            self.previous_max, self.interval_max = self.interval_max, -1
            if snap.reason_flags & PERIODIC:
                self.periodic.append(sn)
                if len(self.periodic) == 4:
                    self.lower = self.periodic[0]
            return True
        if src == 7 and (not self.content.database or len(data) < 5 or data[4] != 0):
            return True
        if sn <= self.lower or sn <= self.last_written:
            return False
        self.interval_max = max(self.interval_max, sn)
        heapq.heappush(self.pending, (sn, frame.payload_offset, src, bytes(data)))
        self.pending_bytes += len(data)
        return len(self.pending) <= 65536 and self.pending_bytes <= 16 * 1024 * 1024

    def drain(self, through):
        while self.pending and self.pending[0][0] <= through:
            sn, offset, src, data = heapq.heappop(self.pending)
            if sn <= self.last_written:
                return False
            self.last_written = sn
            self.pending_bytes -= len(data)
            if src == 5:
                name = "host"
                output = data[4:].decode("utf-8", "replace").encode()
            elif src == 6:
                name = "hci_btsnoop"
                output = encode_hci_payload(data, int.from_bytes(data[:4], "little"))
            else:
                # Stateful fragments use the complete-file codec and task bindings.
                if len(data) < 9 or data[6] >> 6 != 1:
                    return False
                frame = FrameView(src, sn, offset, len(data), memoryview(data))
                records = self.content.feed(frame)
                if (
                    len(records) != 1
                    or records[0].kind != "host"
                    or records[0].incomplete
                ):
                    return False
                task = data[5]
                self.task_names_used[task] = self.content.task_names.get(
                    task, f"task#{task}"
                )
                name = "DECOMPRESSED_BLE_HOST"
                output = records[0].text.encode()
                if os.linesep != "\n":
                    output = output.replace(b"\n", os.linesep.encode())
            if output:
                if name not in self.files:
                    file = (self.directory / f"{self.stem}_{name}.log").open("xb")
                    self.files[name] = file
                    if src == 6:
                        file.write(BTSNOOP_HEADER)
                self.files[name].write(output)
        return True

    def close(self):
        self.pending.clear()
        self.content.close()
        for file in self.files.values():
            file.close()


class RecordingExport:
    """Feed contiguous wire bytes, then publish Parser-compatible recording files.

    Scratch files and provisional outputs belong to this context manager.
    No host receive timestamp is used for ordering or written to these files.
    """

    def __init__(self, recording_path, *, database=None, decoder=None):
        self.path = Path(recording_path)
        self.database = database
        self._stack = ExitStack()
        try:
            self.root = Path(
                self._stack.enter_context(
                    TemporaryDirectory(prefix=".ble-export-", dir=self.path.parent)
                )
            )
            self.output = self.root / "products"
            self.output.mkdir()
            self.store = FrameMetadataStore(self.root / "metadata")
            self._stack.callback(self.store.close)
            self.writer = FrameMetadataWriter(self.store)
            self.payloads = self._stack.enter_context(
                (self.root / "payloads").open("wb")
            )
            self.fast = _AnchoredHostHci(self.output, database, self.path.stem)
            self._stack.callback(self.fast.close)
            self.session = self._stack.enter_context(
                ParserSession(check=False, frame_sink=self._observe, decoder=decoder)
            )
            self.selected = False
            self.chip = None
            self.result = None
        except BaseException:
            self.close()
            raise

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def close(self):
        self._stack.close()

    def feed(self, chunk):
        self.session.feed(chunk)

    def _observe(self, frame):
        src, p = frame.source_code, frame.payload_view
        if src == 8:
            return
        projected = FrameView(src, frame.raw_sn, self.payloads.tell(), len(p), p)
        self.writer.write(projected)
        self.payloads.write(p)
        self.selected |= src in (3, 5, 6) or (
            src == 7 and self.database is not None and len(p) > 4 and p[4] == 0
        )
        if src == 0:
            try:
                if is_snapshot(p):
                    self.chip = parse_snapshot_version_info(parse_snapshot(p)).chip_name
                elif len(p) > 5 and p[4] == 7:
                    self.chip = parse_version_info_payload(p).chip_name
            except ValueError:
                pass  # Optional chip metadata can be malformed in an otherwise valid frame.
        if self.fast is not None and not self.fast.observe(projected):
            self._discard_fast()

    def _discard_fast(self):
        if self.fast is not None:
            self.fast.close()
            self.fast = None
            for path in self.output.iterdir():
                path.unlink()

    def finish(self):
        if self.result is not None:
            return self.result
        try:
            self.session.finish()
            if self.selected:
                protocol = self.store.protocol_evidence.resolve()
                if not (
                    self.fast
                    and self.fast.previous_anchor
                    and protocol.is_v8
                    and self.fast.drain(1 << 24)
                ):
                    self._discard_fast()
                    self._ordered_products(protocol)
            if self.fast:
                self.fast.close()
            published = []
            try:
                for path in sorted(self.output.iterdir()):
                    dest = self.path.with_name(path.name)
                    # Same volume; publish atomically without replacing older products.
                    with path.open("rb+") as file:
                        os.fsync(file.fileno())
                    try:
                        os.link(path, dest)
                    except OSError as exc:
                        if exc.errno not in (
                            errno.EPERM,
                            errno.ENOTSUP,
                            errno.ENOSYS,
                            errno.EACCES,
                        ):
                            raise
                        with dest.open("xb") as out:
                            published.append(dest)
                            with path.open("rb") as source:
                                shutil.copyfileobj(source, out)
                            out.flush()
                            os.fsync(out.fileno())
                    else:
                        published.append(dest)
            except BaseException:
                for dest in published:
                    dest.unlink()
                raise
            self.result = tuple(published)
            return self.result
        finally:
            self.close()

    def _ordered_products(self, protocol):
        self.payloads.close()
        path = Path(self.payloads.name)
        result = order_metadata_store(
            self.store.seal(),
            path,
            self.root / "order",
            protocol=protocol,
            lc_timer_unit=LcTimerUnit.RTC_TICK
            if self.chip == "ESP32C2"
            else LcTimerUnit.US,
        )
        sync = SimpleNamespace(inited=False)
        stem = self.output / self.path.stem
        try:
            with OrderedFrameSource(path, result) as frames:
                ctx = ParseContext(ble_log_version=protocol.version)
                for f, order in frames.iter_views_with_context(
                    sources={Source.INTERNAL}
                ):
                    ctx.task_names_by_instance.setdefault(
                        order.instance_index, {}
                    ).update(task_names_from_binding(f.payload_view))
                write_host_text(
                    frames.iter_views(sources={Source.HOST}), Path(f"{stem}_host.log")
                )
                if self.database:
                    entries = (
                        (f, o)
                        for f, o in frames.iter_views_with_context(
                            sources={Source.ENCODE}
                        )
                        if len(f.payload_view) > 4 and f.payload_view[4] == 0
                    )
                    parse_compressed_logs(
                        entries,
                        str(self.database),
                        str(stem),
                        context=ctx,
                        has_task_id=result.uses_global_sn,
                    )
                rows = result.ordered_rows
                groups = [rows]
                if protocol.version == 8 and len(result.instances) > 1:
                    import numpy as np

                    epochs = result.instance_by_row[rows]
                    groups = np.split(
                        rows, np.flatnonzero(epochs[1:] != epochs[:-1]) + 1
                    )
                for group in groups:
                    suffix = (
                        f"_epoch{int(result.instance_by_row[group[0]])}"
                        if len(groups) > 1
                        else ""
                    )
                    hci_log_handler(
                        frames.iter_views_with_context(
                            sources={Source.HCI}, rows=group
                        ),
                        sync,
                        Path(f"{stem}_hci_btsnoop{suffix}.log"),
                    )
                    ll_hci_log_handler(
                        frames.iter_views(sources={Source.LL_HCI}, rows=group),
                        sync,
                        self.chip,
                        None,
                        Path(f"{stem}_ll_hci_btsnoop{suffix}.log"),
                    )
        finally:
            result.close()
